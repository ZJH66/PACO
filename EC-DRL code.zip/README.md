### Introduction

This is the code of **Brain Effective Connectivity Learning with Deep Reinforcement Learning**. And the framework is based on the existing reinforcement learning techniques which you can find in [here](https://github.com/huawei-noah/trustworthyAI). 

### Dependencies

Code requires:

- castle==6.1.0
- matplotlib==3.6.1
- networkx==2.8.7
- numpy==1.23.3
- pandas==1.5.1
- scikit_learn==1.1.2
- scipy==1.9.3
- torch==1.12.1
- tqdm==4.64.1



### Run

```bash
python rl.py
```

Parameters can be adjusted in rl.py, my experiments is using the default parameters.