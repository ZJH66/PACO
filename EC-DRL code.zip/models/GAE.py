import torch
import torch.nn as nn
import torch.distributions as distr


class GAEncoder(nn.Module):

	def __init__(self, config):
		super().__init__()

		self.config = config
		self.layer1 = nn.Sequential(nn.Linear(config.input_dimension, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer2 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer3 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05),
		                            nn.Linear(config.hidden_dim, config.input_embed)).cuda(config.device_ids)
		self.layer4 = nn.Sequential(nn.Linear(config.input_embed, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer5 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer6 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05),
		                            nn.Linear(config.hidden_dim, config.input_embed)).cuda(config.device_ids)
		self.W = nn.Parameter(torch.Tensor(*(config.max_length, config.max_length)).cuda(config.device_ids))
		nn.init.xavier_uniform_(self.W)

	def forward(self, x):
		x = self.layer1(x)
		x = self.layer2(x)
		x = self.layer3(x)
		x = torch.einsum('ijk,jl->ilk', x, self.W)
		x = self.layer4(x)
		x = self.layer5(x)
		x = self.layer6(x)
		return x


class GADecoder(nn.Module):

	def __init__(self, config):
		super().__init__()

		self.config = config
		self.max_length = config.max_length
		self.layer1 = nn.Sequential(nn.Linear(config.input_embed, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer2 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05)).cuda(config.device_ids)
		self.layer3 = nn.Sequential(nn.Linear(config.hidden_dim, config.hidden_dim),
		                            nn.LeakyReLU(0.05),
		                            nn.Linear(config.hidden_dim, config.max_length)).cuda(config.device_ids)

	def forward(self, x):
		x = self.layer1(x)
		x = self.layer2(x)
		x = self.layer3(x)

		self.adj_prob = x

		self.mask = 0
		self.samples = []
		self.mask_scores = []
		self.entropy = []

		for i in range(self.max_length):
			position = torch.ones([x.shape[0]]) * i
			position = position.type(torch.LongTensor)
			# if self.config.device_type == 'gpu':
			#     position = position.cuda(self.config.device_ids)
			# Update mask
			self.mask = torch.zeros(x.shape[0], self.max_length).scatter_(1, position.view(
				x.shape[0], 1), 1)
			if self.config.device_type == 'gpu':
				self.mask = self.mask.cuda(self.config.device_ids)

			masked_score = self.adj_prob[:, i, :] - 100000000. * self.mask
			prob = distr.Bernoulli(logits=masked_score)  # probs input probability, logit input log_probability

			sampled_arr = prob.sample()  # Batch_size, seqlenght for just one node
			sampled_arr.requires_grad = True

			self.samples.append(sampled_arr)
			self.mask_scores.append(masked_score)
			self.entropy.append(prob.entropy())

		return self.samples, self.mask_scores, self.entropy
