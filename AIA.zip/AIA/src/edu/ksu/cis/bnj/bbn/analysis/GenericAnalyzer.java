/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.analysis;


import java.util.Vector;

import edu.ksu.cis.bnj.bbn.BBNGraph;

/**
 * An abstract class for Analyzer. The assumption of generic analyzer is that
 * the data is analyzed throughout the time, in series (as opposed to just one
 * point of time). The resultant data is stored in a vector and can be plotted
 * by PlotterPanel.
 * 
 * @author Roby Joehanes
 *
 */
public abstract class GenericAnalyzer extends Analyzer {
    protected BBNGraph goldGraph;
    protected Object goldResult;
    protected Vector results = new Vector();

    public GenericAnalyzer() {} // default stub
    public GenericAnalyzer(BBNGraph g) {
        setGoldStandardGraph(g);
    }

    public void setGoldStandardGraph(BBNGraph g) {
        assert g != null;
        goldResult = analyzeGoldGraph(g);
        assert goldResult != null;
        goldGraph = g;
        System.out.println("Gold standard result =\n"+goldResult);
    }

    public void analyze(BBNGraph g2) {
        Object result = evaluate(g2);
        if (result != null) results.add(result);
    }

    public void analyze(Object r2) {
        Object result = evaluate(r2);
        if (result != null) results.add(result);
    }

    public Object[] getResultsArray() {
        return results.toArray();
    }

    public Vector getResults() {
        return results;
    }

    public int getSize() {
        return results.size();
    }

    /**
     * Warning: Will throw a RuntimeException if the analyzer result is not in double!!
     * @return
     */
    public double[] getResultsInDoubles() {
        int size = results.size();
        double[] nd = new double[size];
        for (int i = 0; i < size; i++) {
            nd[i] = ((Double) results.get(i)).doubleValue();
        }
        return nd;
    }

    /**
     * Analyze the gold-standard graph.
     */
    protected abstract Object analyzeGoldGraph(BBNGraph gold);

    /**
     * Analyze. Return null if it's not analyzable
     */
    protected abstract Object evaluate(BBNGraph g);

    /**
     * Analyze the graph. Return null if it's not analyzable
     */
    protected abstract Object evaluate(Object result);

    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        StringBuffer buf = new StringBuffer();
        String ln = System.getProperty("line.separator"); //$NON-NLS-1$
        int size = results.size();
        for (int i = 0; i < size; i++) {
            buf.append(results.get(i)+ln);
        }
        return buf.toString();
    }
}
