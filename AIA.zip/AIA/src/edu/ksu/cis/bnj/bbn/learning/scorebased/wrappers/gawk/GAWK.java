/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.learning.scorebased.wrappers.gawk;



import java.util.ArrayList;
import java.util.LinkedList;
import java.util.StringTokenizer;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.learning.ScoreBasedLearner;
import edu.ksu.cis.bnj.bbn.learning.scorebased.k2.K2;
import edu.ksu.cis.kdd.data.Data;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.ga.EvolutionEvent;
import edu.ksu.cis.kdd.ga.EvolutionListener;
import edu.ksu.cis.kdd.ga.Fitness;
import edu.ksu.cis.kdd.ga.GAOp;
import edu.ksu.cis.kdd.ga.Population;
import edu.ksu.cis.kdd.ga.Subpopulation;
import edu.ksu.cis.kdd.ga.operators.ShuffleOp;
import edu.ksu.cis.kdd.util.Parameter;
import edu.ksu.cis.kdd.util.ParameterTable;
import edu.ksu.cis.kdd.util.gui.OptionGUI;

/**
 * @author Roby Joehanes
 */
public class GAWK extends ScoreBasedLearner implements EvolutionListener {

    public static final int defaultGenerations = 100;
    public static final int defaultPopulationSize = 10;
    public static final double defaultSurvivalRate = 0.2;

    protected Population pop;
    protected int populationSize = defaultPopulationSize;
    protected int generations = defaultGenerations;
    protected double survivalRate = defaultSurvivalRate;
    protected Fitness fitnessFunction = null;
    protected int attributeSize; 
    protected GAOp[] gaOps;

    { // Dynamic initializer
        gaOps = new GAOp[] { new ShuffleOp() };
        gaOps[0].setRate(1.0);
    }

    public GAWK(){}
	/**
	 * @param t
	 */
	public GAWK(Data t) {
		super(t);
	}

	/**
	 * @see edu.ksu.cis.bnj.bbn.learning.Learner#getGraph()
	 */
	public BBNGraph getGraph() {
        if (fitnessFunction == null) fitnessFunction = new GAWKFitness(this);
        attributeSize = data.getAttributes().size();

        pop = new Population();
        pop.subpop = new Subpopulation[1];
        pop.subpop[0] = new Subpopulation(populationSize, new GAWKChrom(attributeSize), fitnessFunction);
        pop.subpop[0].setSurvivalRate(survivalRate);

        int numOps = gaOps.length;
        for (int i = 0; i < numOps; i++) {
            pop.subpop[0].addOperator(gaOps[i]);
        }
        if (analyzer != null) pop.addEvolutionListener(this);

        pop.evolve(generations);

        GAWKChrom gc = (GAWKChrom) pop.getBestChromosome();

		return getGraph(gc);
	}

    protected BBNGraph getGraph(GAWKChrom gc) {
        LinkedList order = new LinkedList();
        System.out.print("Chromosome: ");
        for (int i = 0; i < attributeSize; i++) {
            order.add(gc.get(i));
            System.out.print(gc.get(i)+",");
        }
        System.out.println();

        K2 k2 = new K2(data); // make K2 not-escaping
        k2.setOrdering(order);
        k2.setParentLimit(parentLimit);
        BBNGraph g = k2.getGraph();
        k2 = null;
        return g;
    }

    public void evolutionPerformed(EvolutionEvent e) {
        BBNGraph g = getGraph((GAWKChrom) e.getBestChromosome());
        analyzer.analyze(g);
    }

    /**
     * @return the fitness function
     */
    public Fitness getFitnessFunction() {
        return fitnessFunction;
    }
    

    /**
     * @param fitness The fitness function
     */
    public void setFitnessFunction(GAWKFitness fitness) {
        fitnessFunction = fitness;
    }

	/**
	 * @see edu.ksu.cis.bnj.bbn.learning.Learner#getName()
	 */
	public String getName() {
		return "Genetic Algorithm Wrapper for K2";
	}

	/**
	 * @return int
	 */
	public int getPopulationSize() {
		return populationSize;
	}

	/**
	 * Sets the populationSize.
	 * @param populationSize The populationSize to set
	 */
	public void setPopulationSize(int populationSize) {
		this.populationSize = populationSize;
	}

    /**
     * @return int
     */
    public int getGenerations() {
        return generations;
    }

    /**
     * Sets the generations.
     * @param generations The generations to set
     */
    public void setGenerations(int generations) {
        this.generations = generations;
    }

    /**
     * @return Returns the elitePercentage.
     */
    public double getSurvivalRate() {
        return survivalRate;
    }
    /**
     * @param elitePercentage The elitePercentage to set.
     */
    public void setSurvivalRate(double elitePercentage) {
        this.survivalRate = elitePercentage;
    }

    public void setOperators(GAOp[] ops) {
        gaOps = ops;
    }

    public OptionGUI getOptionsDialog() {
        return new GAWKOptionGUI(this);
    }

    public void setGoldStandardGraph(BBNGraph g) {
        super.setGoldStandardGraph(g);
        fitnessFunction = new GAWKRMSEFitness(this);
    }

    public static void main(String[] args) {
        ParameterTable params = Parameter.process(args);
        String inputFile = params.getString("-i");
        String outputFormat = params.getString("-f");
        String outputFile = params.getString("-o");
        String goldFile = params.getString("-gn");
        String rmseFile = params.getString("-r");
        String operators = params.getString("-op");
        int maxParent = params.getInt("-k", defaultParentLimit);
        int maxGeneration = params.getInt("-g", defaultGenerations);
        int maxPopSize = params.getInt("-p", defaultPopulationSize);
        double survivalRate = params.getDouble("-sp", defaultSurvivalRate);
        boolean quiet = params.getBool("-q");

        if (inputFile == null) {
            System.out.println("Usage: edu.ksu.cis.bnj.bbn.learning.gawk.GAWK -i:inputfile [-o:outputfile] [-f:outputformat] [-gn:goldnetwork] [-r:rmseoutput] [-q] [-k:parentlimit] [-g:generations] [-p:populationsize] [-sp:survivalpercentage] [-op:operatorlist]");
			System.out.println("-o: file to which best network of final GA generation is serialized");		// ### ALWAYS DOCUMENT OUTPUT SPEC - WHH 20 Apr 2003
            System.out.println("-f: default=xml. Acceptable values are {xml, net, bif, xbn, dsc, dsl, ergo, libb}");
            System.out.println("-k: parent limit. Default="+defaultParentLimit);
            System.out.println("-g: number of generations. Default="+defaultGenerations);
            System.out.println("-p: population size. Default="+defaultPopulationSize);
            System.out.println("-sp: survival percentage (the best percentile of individuals that you decide to keep). Default="+defaultSurvivalRate);
            System.out.println("-gn: specify gold standard network (must be used with -r).");
            System.out.println("-r: the RMSE value plot against a gold standard network (must be used with -gn).");
            System.out.println("-q: quiet mode");
            System.out.println("-op: operator list. Default is ShuffleOp. Example:");
            System.out.println("-op:edu.ksu.cis.bnj.MyOp1,0.8;edu.ksu.cis.bnj.MyOp2,0.1;edu.ksu.cis.bnj.MyOp3,0.1");
            System.out.println("It means that we have 3 operators: MyOp1-3, with 0.8, 0.1, 0.1 probability of being chosen, respectively.");
            System.out.println("The operator class MUST BE IN THE CLASSPATH!");
            return;
        }
        System.out.println("Genetic Wrapper for K2 learning");

        try {
            Runtime r = Runtime.getRuntime();
            long origfreemem = r.freeMemory();
            long freemem;
            long origTime = System.currentTimeMillis();
            Table tuples = Table.load(inputFile);
            tuples.conserveMemory();
            System.gc();
            GAWK gawk = new GAWK(tuples);
            //gawk.setCalculateCPT(false);
            gawk.setParentLimit(maxParent);
            gawk.setPopulationSize(maxPopSize);
            gawk.setGenerations(maxGeneration);
            gawk.setSurvivalRate(survivalRate);

            // is there any operators?
            if (operators != null) {
                ArrayList ops = new ArrayList();
                for (StringTokenizer tok = new StringTokenizer(operators,";"); tok.hasMoreTokens(); ) { //$NON-NLS-1$
                    String token = tok.nextToken();
                    StringTokenizer paramTok = new StringTokenizer(token,","); //$NON-NLS-1$
                    String className = paramTok.nextToken();
                    if (!paramTok.hasMoreTokens())
                        throw new RuntimeException("Error: You must specify the probability for operator "+className);
                    String prob = paramTok.nextToken();
                    GAOp op = GAOp.loadOperator(className);
                    if (op == null)
                        throw new RuntimeException("Error in loading operator "+className);
                    try {
                        op.setRate(Double.parseDouble(prob));
                    } catch (Exception e) {
                        throw new RuntimeException("Error: The probability "+prob+" is not a number");
                    }
                    ops.add(op);
                }
                if (ops.size() < 1)
                    throw new RuntimeException("Error: Expecting operators");
                gawk.setOperators((GAOp[]) ops.toArray(new GAOp[0]));
            }

            System.gc();
            long afterLoadTime = System.currentTimeMillis();
            freemem = r.freeMemory() - origfreemem;

            if (!quiet) {
                System.out.println("Memory needed after loading tuples = "+freemem);
                System.out.println("Loading time = "+((afterLoadTime - origTime) / 1000.0));
            }

            if (goldFile != null) {
                if (rmseFile == null)
                    throw new RuntimeException("Error! Must set -r too!");
                gawk.setGoldStandardGraph(BBNGraph.load(goldFile));
            } else if (rmseFile != null) throw new RuntimeException("Error! Must set -gn too!");

            BBNGraph g = gawk.getGraph();
            long learnTime = System.currentTimeMillis();
            freemem = r.freeMemory() - origfreemem;

            if (!quiet) {
                System.out.println("Memory needed after learning Genetic Wrapper for K2 = "+freemem);
                System.out.println("Learning time = "+((learnTime - afterLoadTime) / 1000.0));
            }

            if (rmseFile != null) {
                gawk.getAnalyzer().dump(rmseFile);
            }

            if (outputFile != null) {
                if (outputFormat != null) {
                    g.save(outputFile, outputFormat);
                } else {
                    g.save(outputFile);
                }
            } 


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
