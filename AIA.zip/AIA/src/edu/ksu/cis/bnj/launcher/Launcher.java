/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

package edu.ksu.cis.bnj.launcher;

import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.LineNumberReader;

/**
 * <P>Java exe launcher. Must be compiled using GCJ to produce an executable.
 * Please DO NOT link or import or use any other BNJ libraries in any way!!
 * Otherwise GCJ will fail to compile!
 * 
 * <P>The Java runtime options is stored in runtime.opt. DO NOT put this to config.xml!
 * Because we don't want to give additional complexity for the inchoate GCJ!
 * Note: DO NOT run this class through Eclipse or normal Java invocation. This
 * class is meant to be run in the binary form. (refer to the build script) 
 *
 * <P>To compile: gcj --main=edu.ksu.cis.bnj.launcher.Launcher -mwindows --classpath . -Dmain.class=edu.ksu.cis.bnj.BNJ -o bnj.exe src/edu/ksu/cis/bnj/launcher/Launcher.java
 *
 * @author Roby Joehanes
 */
public class Launcher {
    private static byte[] buffer = new byte[65536]; // Allocate 64k buffers
    private static final String DEFAULT_OPTION = "javaw -ea -esa -Xmx1024M"; // $NON-NLS-1$
    private static Runtime runtime = Runtime.getRuntime();
    private static String osName = System.getProperty("os.name").toLowerCase(); // $NON-NLS-1$
    private static boolean isWindows = osName.indexOf("windows") != -1 || osName.indexOf("cygwin") != -1; // $NON-NLS-1$ // $NON-NLS-2$

    private static final String getCommandLine() {
        String cmd = DEFAULT_OPTION;
        File f = null;
        File parentDir = null;
        try {
            f = new File("runtime.opt"); // $NON-NLS-1$
            parentDir = new File(".");  // $NON-NLS-1$
        } catch (Exception e) {
        }

        if (f.exists()) {
            // If runtime.opt is there, then the path is bin/runtime.opt
            if (parentDir == null) parentDir = f.getParentFile().getParentFile();
            // Read the option
            LineNumberReader r = null;
            try {
            	r = new LineNumberReader(new FileReader(f));
                String s = null;
                do {
                    s = r.readLine();
                    if (s == null) break;
                    s = s.trim();
                    if (s.length() > 0 && !s.startsWith("#")) { // $NON-NLS-1$
                        cmd = s; break;
                    }
                } while (true);
            } catch (Exception e) {
                // whoops fails! In that case, use the default option
                cmd = DEFAULT_OPTION;
            } finally {
                if (r != null) try {r.close();} catch (Exception e) {};
            }
        }

        // Prepare the classpath
        cmd += " -classpath bin";  // $NON-NLS-1$

        // parentDir should all point to the BNJ installation dir here
        //System.out.println(parentDir.getAbsolutePath());
        //System.out.println(System.getProperty("os.name"));

        // Now look at lib dir
        File libDir = new File(parentDir.getAbsolutePath()+File.separator+"lib"); // $NON-NLS-1$
        // Sanity check
        if (!libDir.exists() || !libDir.isDirectory()) throw new RuntimeException("Libraries needed to run BNJ may be missing!");
        String[] libraryList = libDir.list();
        if (libraryList == null) throw new RuntimeException("Libraries needed to run BNJ may be missing!");

        int numLib = libraryList.length;

        String libdirString = "lib"; // $NON-NLS-1$
        String pathSeparator = isWindows ? ";" : File.pathSeparator; // $NON-NLS-1$
        // NOTE: Cygwin screws everything. path separator needs to be fixed!!

        /*
        
        // This is the thing I REALLY hate: absolute path doesn't work!
        
        String libdirString = libDir.getAbsolutePath();
        // Note: This is very simplistic. I do not take into account if the directory has some exotic characters
        // like & and so forth!
        if (libdirString.indexOf(' ') != -1) { // Contains a space?
            if (isWindows)
                // if it's windows, enclose it with quotes
                libdirString = "\""+libdirString + "\""; // $NON-NLS-1$ // $NON-NLS-2$
            else {
                // if it's not windows, assume UNIX-based -- Prepend every spaces with backslashes

                // Sheesh, GCJ doesn't like this!!
                // libdirString = libdirString.replaceAll(" ","\\ "); // $NON-NLS-1$ // $NON-NLS-2$
                StringBuffer b = new StringBuffer();
                for (StringTokenizer tok = new StringTokenizer(libdirString); tok.hasMoreTokens(); ) {
                    b.append(tok.nextToken());
                    if (tok.hasMoreElements()) b.append("\\ ");
                }
            }

        }
        */

        for (int i = 0; i < numLib; i++) {
            if (libraryList[i].toLowerCase().endsWith(".jar")) // $NON-NLS-1$
                cmd += pathSeparator+libdirString+File.separator+libraryList[i]; // $NON-NLS-1$
        }

        return cmd;
    }

    public static final void exec(String cmd) {
        try {
            Process p = runtime.exec(cmd);
            InputStream commandErr = p.getErrorStream();
            InputStream commandOut = p.getInputStream();
            //StringBuffer sb = new StringBuffer();
            int charsRead = 0; // chars read on read
            int charsAvail = 0; // chars available
            while (charsRead != -1) {
                if (commandErr.available() > 0) {
                    charsRead = commandErr.read(buffer);
                    //sb.append(new String(buffer, 0, charsRead));
                    System.out.println(new String(buffer, 0, charsRead));
                }
                charsRead = commandOut.read(buffer);
                if (charsRead > 0) {
                    //sb.append(new String(buffer, 0, charsRead));
                    System.out.println(new String(buffer, 0, charsRead));
                }
            }
            p.waitFor();
            //String result = sb.toString();
            //System.out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected static final void launch(String mainClassName, String[] args) {
        String cmd = getCommandLine()+" "+mainClassName; // $NON-NLS-1$
        //System.out.println(cmd);
        if (args != null) {
            for (int i = 0; i < args.length; i++)
                cmd += " "+args[i]; // $NON-NLS-1$
        }
        exec(cmd);
    }

    public static void main(String[] args) {
    	launch(System.getProperty("main.class"), args); // $NON-NLS-1$
    }
}

