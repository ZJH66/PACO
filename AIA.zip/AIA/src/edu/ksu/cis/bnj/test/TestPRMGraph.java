/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.test;

/*
 * This file is part of Bayesian Network for Java (BNJ).
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ksu.cis.bnj.bbn.datagen.ForwardSampling;
import edu.ksu.cis.bnj.bbn.prm.PRMClass;
import edu.ksu.cis.bnj.bbn.prm.PRMData;
import edu.ksu.cis.bnj.bbn.prm.PRMGraph;
import edu.ksu.cis.kdd.data.Attribute;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.data.Tuple;

/**
 * @author Prashanth Boddhireddy pbo8844
 *
 */
public class TestPRMGraph
{	
	
	public static void main(String[] args)
	{
			PRMGraph prmGraph = (PRMGraph) PRMGraph.load(args[0]);
			ForwardSampling dg = new ForwardSampling(prmGraph);
			int numIter = 10;
      Table tuples = dg.generateData(numIter);
      int numberOfClasses = prmGraph.getNumberOfClasses();
      Table tuplesArray [] = new Table[numberOfClasses];
      LinkedList newTuples[] = new LinkedList[numberOfClasses];
      LinkedList classAttributeList[] = new LinkedList[numberOfClasses];
      for (int i = 0; i <numberOfClasses; i++)
      {
      	tuplesArray[i] = (Table)tuples.clone();
      }
			int tupleIndex = 0;
			for (Iterator i = (prmGraph.getClassList()).iterator();i.hasNext(); tupleIndex++)
			{
				PRMClass prmclass = (PRMClass)i.next();
				String primaryKey = prmclass.getPrimaryKey();
				LinkedList attributeList = new LinkedList();
				attributeList.add(primaryKey);
				for (Iterator j = (prmclass.getAttributeList
								(PRMData.PRM_ATTRIBUTE).iterator());j.hasNext();){
					String nodeName = (String)j.next();									
					Attribute attribute = (Attribute)tuples.getAttribute(nodeName);										
					attributeList.add(attribute);
			  }	
			  classAttributeList[tupleIndex] = attributeList;
				tuplesArray[tupleIndex] = getTuples(tuples, attributeList);
				System.out.println(attributeList);
				System.out.println(tuplesArray[tupleIndex]);

				//System.out.println(classAttributeList[tupleIndex]);
			}
	}
	
	public static Table getTuples(Table tuples, LinkedList attributeList)
	{
		Tuple currentTuple;
		LinkedList newTuple;
		Table allTuples = new Table();
		String primaryKey;
		for (int i =0; i < tuples.size(); i++)
		{	
			newTuple = new LinkedList();
			currentTuple = tuples.getTuple(i);
			List values = currentTuple.getValues();
			for (int j = 0; j < attributeList.size(); j++)
			{
				if (j == 0)
				{
					primaryKey = (String)attributeList.get(j) + i;
					newTuple.add(primaryKey);	
				}
				else
				{
					int index = tuples.getAttributeIndex((Attribute)attributeList.get(j));
					newTuple.add(values.get(index));	
				}	
			}
			allTuples.addTuple(new Tuple(newTuple));
		}	
		return allTuples;
	}
}
