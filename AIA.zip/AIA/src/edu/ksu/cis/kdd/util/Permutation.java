/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package edu.ksu.cis.kdd.util;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/**
 * <P>Simple permutation generator.
 * <P>Usage: <BR>
 * <TT>Permutation perm = new Permutation(n);</tt><br>
 * <tt>List l = perm.generate();</tt><br>
 * 
 * <P>The list <tt>l</tt> will hold the result, which is a list of list.
 * 
 * @author Roby Joehanes
 * Last updated Thu 01 May 2003
 */
public class Permutation {

    protected LinkedList instance = new LinkedList();
    protected PermutationListener listener;

	public Permutation(int k) {
        for (int i = 0; i < k; i++) {
            instance.add(new Integer(i));
        }
	}

    public Permutation(Collection c) {
        instance.addAll(c);
    }

    public List generate() {
        return generateImpl(instance, new LinkedList(), new LinkedList());
    }

    protected List generateImpl(LinkedList permList, LinkedList curInst, List result) {
        int max = permList.size();
        for (int i = 0; i < max; i++) {
            Integer num = (Integer) permList.get(i);
            permList.remove(i);
            curInst.add(num);
            if (permList.size() == 0) {
                result.add(curInst.clone());
            } else {
                generateImpl(permList, curInst, result);
            }
            curInst.removeLast();
            permList.add(i, num); 
        }
        return result;
    }

    public void iterate(PermutationListener l) {
        assert(l != null && instance != null);
        listener = l;
        iterateImpl(instance, new LinkedList());
        listener = null;
    }

    protected void iterateImpl(LinkedList permList, LinkedList curInst) {
        int max = permList.size();
        for (int i = 0; i < max; i++) {
            Integer num = (Integer) permList.get(i);
            permList.remove(i);
            curInst.add(num);
            if (permList.size() == 0) {
                listener.callback(curInst);
            } else {
                iterateImpl(permList, curInst);
            }
            curInst.removeLast();
            permList.add(i, num); 
        }
    }

    /**
     * Shorthand for generating permutation of k integers [0..k-1]
     * @param k
     * @return the list of list of the permutation
     */
    public static List generate(int k) {
        return new Permutation(k).generate();
    }

    public static void main(String[] args) {
        Permutation perm = new Permutation(4);
        System.out.println(perm.generate().toString());
    }
}
