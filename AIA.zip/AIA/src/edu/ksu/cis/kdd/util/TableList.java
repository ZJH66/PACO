/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.util;

/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

// Table which value is list. By: Roby Joehanes
public class TableList implements Cloneable {
	protected Hashtable tbl = new Hashtable();

	public List get(Object key)
	{
		return (List) tbl.get(key);
	}

	public Set getSet(Object o)
	{
		List list = get(o);
		HashSet result = new HashSet();
		if (list != null) result.addAll(list);
		return result;
	}

	public Enumeration keys() { return tbl.keys(); }
    public Set keySet() { return tbl.keySet(); }

	public void put(Object key, Object item)
	{
		List l = (List) tbl.get(key);
		if (l == null) l = new LinkedList();
		l.add(item);
		tbl.put(key,l);
	}

    public void putAll(Object key, Collection item) {
        List l = (List) tbl.get(key);
        if (l == null) l = new LinkedList();
        l.addAll(item);
        tbl.put(key,l);
    }

    public void putAll(Object key, Object[] item) {
        List l = (List) tbl.get(key);
        if (l == null) l = new LinkedList();
        int max = item.length;
        for (int i = 0; i < max; i++)
            l.add(item[i]);
        tbl.put(key,l);
    }

    public void putAll(TableList t) {
        // You can't do tbl.putAll(t.tbl)
        // Because we unionize the colliding entries,
        // not replacing them.
        for (Iterator i = t.tbl.keySet().iterator(); i.hasNext(); ) {
            Object key = i.next();
            List l = (List) t.tbl.get(key);
            if (l != null) putAll(key, l);
        }
    }

	public void remove(Object key)
	{
		tbl.remove(key);
	}

    public void remove(Object key, Object item)
    {
        List l = (List) tbl.get(key);
        if (l == null) return;
        l.remove(item);
    }

    public String toString()
    {
        return tbl.toString();
    }

    public int hashCode()
    {
        return tbl.hashCode();
    }

    public boolean equals(Object o)
    {
        return (o instanceof TableList) && (tbl.equals(((TableList) o).tbl));
    }

    public int size() {
        return tbl.size();
    }

    public Object clone() {
        TableList newTbl = new TableList();
        for (Enumeration e = tbl.keys(); e.hasMoreElements(); ) {
            Object key = e.nextElement();
            LinkedList ll = (LinkedList) tbl.get(key);
            newTbl.tbl.put(key, ll.clone());
        }
        return newTbl;
    }
}
