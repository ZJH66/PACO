/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.kdd.classifier.validator;

/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

import edu.ksu.cis.kdd.classifier.ClassifierEngine;
import edu.ksu.cis.kdd.data.Table;

/**
 * @author Roby Joehanes
 *
 */
public class StandardValidator extends Validator {

    /**
     * The proportion to reserve as train data. Default 0.8
     * (It means that 0.8 portion of the train data will be
     * set apart as the test data ONLY IF the test data doesn't
     * exist)
     */
    protected double split = 0.8;
    protected Table train = null, test = null;

	/**
	 * Constructor for StandardValidator.
	 */
	public StandardValidator() {
		super();
	}

	/**
	 * Constructor for StandardValidator.
	 * @param o
	 */
	public StandardValidator(ClassifierEngine o) {
		super(o);
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#hasNext()
	 */
	public boolean hasNext() {
		return false; // We never split
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#next()
	 */
	public void next() {
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#getTrainData()
	 */
	public Table getTrainData() {
        assert train != null;
        return train;
	}

	/**
	 * @see edu.ksu.cis.kdd.data.validator.Validator#getTestData()
	 */
	public Table getTestData() {
        assert test != null;
        return test;
	}

    /**
     * @see edu.ksu.cis.kdd.data.validator.Validator#init()
     */
    public void init() {
        assert owner != null;
        Table train = owner.getTrainData();
        Table test = owner.getTestData();
        if (test != null)
        {
            this.train = train;
            this.test = test;
        } else
        {
            this.train = train.getFirst((int) Math.round(train.size()*split));
            this.test = train.getFirst((int) Math.round(train.size()*(1.0-split)));
        }
    }

	/**
	 * Returns the split.
	 * @return double
	 */
	public double getSplit() {
		return split;
	}

	/**
	 * Sets the split.
	 * @param split The split to set
	 */
	public void setSplit(double split) {
		this.split = split;
	}

}
