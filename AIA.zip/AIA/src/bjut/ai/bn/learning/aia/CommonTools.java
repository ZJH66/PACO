package bjut.ai.bn.learning.aia;
import java.io.*;

public class CommonTools {
	public CommonTools()
    {
    }

    public static PrintWriter getPrintWriter(String path, String filename)
    {
        PrintWriter pw = null;
        try
        {
            File filepath = new File(path);
            filepath.mkdirs();
            File file = new File(filepath,filename);
            pw = new PrintWriter(new FileWriter(file, false));
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        return pw;
    }
    public static PrintWriter getPrinWriter(String filename) throws IOException
   {
       File dir = new File("c:" + File.separator + "BayesianLog_Alarm");
       dir.mkdir();
       File file = new File(dir, filename+".csv");
       return new PrintWriter(new FileWriter(file, false));
   }

   public static void main(String[] args)
   {
       try
       {
           PrintWriter pw = CommonTools.getPrintWriter("c:\\zhang\\xun", "xun.tet");
           pw.print("fdsafds");
           pw.append("fdsa");
           pw.close();
           //PrintWriter pw1 = K2.getPrinWriter("zhang.txt");
           //pw1.print("fdsafds");
           //pw1.close();

       }
       catch (Exception ex)
       {
           ex.printStackTrace();
       }

    }
}
