package bjut.ai.bn.learning.aia;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;

//import bjut.ai.bn.AlarmReader;





import bjut.ai.bn.learning.aia.AlarmReader;
import bjut.ai.bn.learning.aia.CommonTools;
import bjut.ai.bn.learning.aia.SingleAnti;
import bjut.ai.bn.BNGraph; //import bjut.ai.bn.CommonTools;
import bjut.ai.bn.HillClimbing; //import bjut.ai.bn.converter;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;
import bjut.ai.bn.Neighborhood;

public class SingleAIA
{
	public double pclone;//ִ�п�¡ѡ��ĸ���
	public double pcross ;//ִ�н���ĸ���
	public double pmutation;//ִ�б���ĸ���
	public int vexnum;//�ڵ���
	public double memoryNum; //������С
	private final Random RANDOM;

	public static int bestOccur = 0;
	public static long[] bestOccurTime = new long[2000];
	private static int count = 0;
	private static int solutionCount = 0;
	public static BNGraph[] bestSolutions;
	public static int LogK2ScoreCount = 0;
	
	public Score score = null;
	public BNGraph BestSolution; //���Ž�

	private BNGraph gk2sn;
	private int tStep; //�ֲ��Ż�����
	private int tMaxStep; //��������
	private int Num;//��������

	private java.util.ArrayList<Double> BestScore; // ÿһ�������ŷ�ֵ
	private java.util.TreeSet<Integer> setOpted; // �Ѿ������Ż�������ֵ
	private int BestScoreIndex; // ��ǰ������ֵĿ������

	public SingleAnti Anti[];//���弯
	double InitHArray[][];
    double[] noParVexK2Value;
	
  
    public SingleAnti CloneAnti[];//��¡���弯
    public SingleAnti ClonedAnti[];//����¡���弯
    List<SingleAnti> mList = new ArrayList<>(); // ���俹���б�
    List<SingleAnti> rList = new ArrayList<>(); // ���������б�
    List<SingleAnti> aList = new ArrayList<>(); // ��ʼ�������б�
    List<SingleAnti> tList = new ArrayList<>(); // �ֲ��Ż������б�
    
    
	public SingleAIA(BNGraph gk2sn, double clone, double cross, double mutation,
			 int tStep, int tMaxStep, int memoryNum, int aNum, int vexnum, Score score) {
		// //���k2sn�Ľ� ��ʽ��
		RANDOM = new Random();
		this.score = score;
		this.gk2sn = gk2sn;
		this.InitHArray = new double[vexnum][vexnum];
		this.BestSolution = gk2sn;
		this.vexnum = vexnum;
		this.Num = aNum;
		this.tMaxStep = tMaxStep;
		this.tStep = tStep;
		this.pclone = clone;
		this.pcross = cross;
		this.pmutation= mutation;
		this.memoryNum= memoryNum;

		bestSolutions = new BNGraph[this.Num];		
		this.BestScore = new ArrayList<Double>();
		this.setOpted = new TreeSet<Integer>();
		this.noParVexK2Value = new double[this.vexnum];
		
		this.InitHArray= new double[this.vexnum][this.vexnum];//��ʼ��������Ϣ
		this.initheuristicInfo();	
	/*	for(int i=0;i<this.vexnum;i++){
			for(int j=0;j<this.vexnum;j++){
			System.out.println("������Ϣ");
			System.out.println(InitHArray[i][j]);
			}
			
		}*/				
	}

	public void setScoreMetric(Score s) {
		this.score = s;
	}


	public void initheuristicInfo()//��ʼ��������Ϣ����
    {
        BNGraph temp = new BNGraph(this.vexnum);
        ArrayList<Integer> anodelist = new ArrayList<Integer> (); //��ʱ
        for (int i = 0; i < this.vexnum; i++)
        {
            this.noParVexK2Value[i] = this.score.calcScore(i,anodelist);
            for (int j = 0; j < this.vexnum; j++)
            {
                if (i != j)
                {
                	anodelist.add(j);
                    this.InitHArray[i][j] = this.score.calcScore(temp.GetNode(i).GetNodeId(),anodelist)-this.noParVexK2Value[i];
                    anodelist.remove(0);
                }
                else
                    this.InitHArray[i][j] = Double.NEGATIVE_INFINITY;
            }
        }

    }
	

	public static void addToSolutionSet(BNGraph b) {
		SingleAIA.bestSolutions[SingleAIA.solutionCount] = b;
	}

	public static void addToSolutionSet(BNGraph b, int k) {
		SingleAIA.bestSolutions[k] = b;
	}

	public BNGraph getBestSolution() {
		Arrays.sort(SingleAIA.bestSolutions);
		return SingleAIA.bestSolutions[SingleAIA.bestSolutions.length - 1];
	}

	public BNGraph findBestBayesianNet2(double bestScore) {
		this.BestScore.clear();
		this.setOpted.clear();
			
		//1.��ʼ������
		Anti = new SingleAnti[Num];
		for(int i=0;i<this.Num;i++){
			Anti[i] = new SingleAnti(this.pclone, this.pcross, this.pmutation, vexnum, this.InitHArray, this.score, i);	
			Anti[i].setBNgraph(Anti[i].runRandom());
            System.out.println(Anti[i].getBNgraph().toDrawString());
            aList.add(Anti[i]);
           // System.out.print(Anti[i].runRandom().toDrawString());
            if (Anti[i].getBNgraph().K2Score > bestScore) {
				// �õĽ�
				this.BestSolution=Anti[i].getBNgraph();
				bestScore=Anti[i].getBNGraphScore();
				this.BestScoreIndex=i;

			}
             } 
        double noclone = this.pclone * Num;
        int nclone= (int) Math.round(noclone);
        System.out.println("��¡ѡ�����Ϊ:"+nclone);
       
        CloneAnti= new SingleAnti[nclone];
        ClonedAnti= new SingleAnti[nclone];
       
              
        //����ѭ�� Ѱ��  
 		for (int t = 0; t < tMaxStep; t++) {
 			
 			
			if (t==0)
			{
				rList.addAll(aList);
			}
			else
			{
				for(int i=0;i<(Num/8);i++){
					Anti[i] = new SingleAnti(this.pclone, this.pcross, this.pmutation, vexnum, this.InitHArray, this.score, i);	
					Anti[i].setBNgraph(Anti[i].runRandom());
		            aList.add(Anti[i]);
		            }
				rList.addAll(mList);
				mList.clear();
			}
			
  		   //���ԭ����÷�
            for (SingleAnti a : rList) {
    			System.out.println("���壺"+a.getNo()+"���÷�Ϊ��"+a.getBNGraphScore());
    		}
          //2. ����������÷�
            Collections.sort(rList,new Comparator<Object>(){
    			@Override
    			public int compare(Object o1, Object o2) {
    				return (int) (((SingleAnti) o2).getBNGraphScore() - ((SingleAnti) o1).getBNGraphScore());
    			}
    		});
            for (SingleAnti a : rList) {
    			System.out.println("���壺"+a.getNo()+"���÷�Ϊ��"+a.getBNGraphScore());
    		}      
            
            

         //3. ��¡ѡ��   
         
         for(int i=0;i<nclone;i++){        	 
        	 CloneAnti[i] = rList.get(i);
        	 ClonedAnti[i] = rList.get(i);
        	// System.out.println("��¡����Ԫ��Ϊ��"+CloneAnti[i].getNo()+"|"+CloneAnti[i].getBNGraphScore());
         }
         
         //4. ����    
         for(int i=0;i<nclone;i++){
        	Random random = new Random();
     		int pc = random.nextInt(99);
     		int crossed = random.nextInt(nclone);
     		if(pc>=0&&pc<100*pcross)
     		{
     		 if(crossed!=i)
        	 cross(CloneAnti[i], CloneAnti[crossed], i, crossed);   	
          	 System.out.println("tu"+CloneAnti[i].getBNgraph().toString());
     		}
         }
         
         //5. ����  
         for(int i=0;i<nclone;i++){
        	Random random = new Random();
      		int pm = random.nextInt(99);
      		if(pm>=0&&pm<100*pmutation)
      		{
      		 System.out.println("��"+CloneAnti[i].getNo()+"�����巢������");
      		 BNGraph a = mutation(CloneAnti[i].getBNgraph());
      		// System.out.println("tu"+CloneAnti[i].getBNgraph().toString());
        	 CloneAnti[i].setBNgraph(mutation(CloneAnti[i].getBNgraph()));       	 
      		}
         }
       
         for(int i=0;i<nclone;i++){
        	 mList.add(CloneAnti[i]);
        	 mList.add(ClonedAnti[i]);
         }
         
         //����¿��壨����+��¡���÷�
         for (SingleAnti b : mList) {
 			System.out.println("����+��¡���壺"+b.getNo()+"���÷�Ϊ��"+b.getBNGraphScore());
 		}
       //2. ����������÷�
         Collections.sort(aList,new Comparator<Object>(){
 			@Override
 			public int compare(Object o1, Object o2) {
 				return (int) (((SingleAnti) o2).getBNGraphScore() - ((SingleAnti) o1).getBNGraphScore());
 			}
 		});
        
         mList=mList.subList(0, Num-(Num/8));
         
		 for (SingleAnti b : mList) {
 			System.out.println("����⿹�壺"+b.getNo()+"���÷�Ϊ��"+b.getBNGraphScore());
 		}
		 
		// �ͷ�
		rList.clear();
		aList.clear();
		tList.clear();
		
		// ��ȡ��ǰ���Ž�
		 bestScore=mList.get(0).getBNGraphScore();
		 this.BestSolution = mList.get(0).getBNgraph();
		 
 	    // �����Ż� ���Ǳ��룩
 				if ((t % tStep) == 0 && (t != 0)) {

 					for (int i = 0; i < this.memoryNum; i++) {
 						tList.add(mList.get(i));
 						tList.get(i).setBNgraph(this.HillClimbing(tList.get(i).getBNgraph()));
 					}
 				

 				for (int k = 0; k < this.memoryNum; k++) {
 					if (tList.get(k).getBNGraphScore() > bestScore) {
 						// �õĽ�
 						bestScore = tList.get(k).getBNGraphScore();
 						this.BestSolution=tList.get(k).getBNgraph();
 					}
 				}

 				System.out.println("�Ż������Ž�÷�Ϊ��"+this.BestSolution);
 				}
 		}
 				
		System.out.println("���Ž���"+BestScoreIndex+"�Ÿ���,"+"K2����Ϊ:"+bestScore);
		return this.BestSolution;
	}
	
	public BNGraph mutation(BNGraph Antibody){
	Neighborhood neighbor = new Neighborhood(Antibody, this.score);
	return neighbor.NeighborEmployedBN1();}	
	

	public void cross(SingleAnti a1, SingleAnti a2, int Anti1, int Anti2){

		Neighborhood neighbor1 = new Neighborhood(a1.getBNgraph(), this.score);
		Neighborhood neighbor2 = new Neighborhood(a2.getBNgraph(), this.score);
		
		int [][]ai= a1.getBNgraph().GetArcArray();
		int [][]aj= a2.getBNgraph().GetArcArray();
		int [][]operation =new int[this.vexnum][this.vexnum];
        int from=0; int to=0;
		for(int i= 0 ;i <this.vexnum;i++){
		for(int j=0;j<this.vexnum;j++){
			if(ai[i][j]!=aj[i][j]){
				if(ai[i][j]==1){
					if(aj[j][i]==1){
						operation[i][j]=2;
					}else{
						operation[i][j]=-1;
					}
				}
				if(aj[i][j]==1){
					if(ai[j][i]==1){
						operation[j][i]=2;
					}else{
						operation[i][j]=1;
					}
				}
				
				from=i;
				to=j;
				break;
			}
		}
	}

		if(operation[from][to]==1){			
			a1.setBNgraph(neighbor1.NeighborEmployedBN1());
			}
		if(operation[from][to]==2){
			a2.setBNgraph(neighbor2.NeighborEmployedBN1());
		}	
		if(operation[from][to]==-1){
			a1.setBNgraph(neighbor1.NeighborEmployedBN1());
			a2.setBNgraph(neighbor2.NeighborEmployedBN1());
		}

	}

	
	static int MaxEqualStep = 50;

	private boolean canStop() {
		boolean stop = false;

		int current = this.BestScore.size(); // ��ǰ����

		if (current - this.bestOccur > this.MaxEqualStep) {
			System.err.println("stop at:" + current);
			stop = true;
		}
		/*
		 * if ((current - this.bestOccur >
		 * this.MaxEqualStep)||(this.BestSolution.K2Score>=-9717)) {
		 * System.err.println("stop at:" + current); stop = true; }
		 */
		return stop;
	}

	/**
	 * ��ɽ�Ż�
	 * 
	 * @param G_k
	 *            BNGraph
	 * @return BNGraph
	 */
	public BNGraph HillClimbing(BNGraph G_k) {
		HillClimbing hill = new HillClimbing(G_k, this.score);
			G_k = hill.OptimizeBN();
		return G_k;
	}

	public BNGraph Neighborhood2(BNGraph G_k, char c) {
		Neighborhood neighbor = new Neighborhood(G_k, this.score);
		G_k = neighbor.NeighborEmployedBN1();
		return G_k;
	}

	/**
	 * �ֲ��Ż�
	 */
	public void localOptimizate() {
		BNGraph temp = new BNGraph(this.vexnum);
		System.out.println("���ľֲ��Ż�");
		for (int i = 0; i < this.bestSolutions.length; i++) {
			this.bestSolutions[i] = this.HillClimbing(this.bestSolutions[i]);
		}
		temp = this.getBestSolution();
		if (temp.getScore() > this.BestSolution.getScore()) {
			this.BestSolution = temp;
		}

	}


	private static java.lang.StringBuilder sb;

	public static void main(String[] args) {
		sb = new java.lang.StringBuilder();
		try {
			// ���ݼ���Ϣ
			String DatasetFile = "E:\\Disdata\\Sim1-3.txt";
			int Vexnum = 5;//
			int capacity= 10000;
			int[] DatasetNum = { capacity };
			
			// ʵ������
			ArrayList<K2.TYPE> types = new ArrayList<K2.TYPE>();
			types.add(K2.TYPE.ORI);
			Iterator it = types.iterator();
			while (it.hasNext()) {
				K2.TYPE SearchType = (K2.TYPE) it.next();
				String type = SearchType.toString();// ORI3000
				for (int count = 0; count < DatasetNum.length; count++) {
					sb.append("\n" + type + DatasetNum[count]);

					AlarmReader ar = new AlarmReader(DatasetFile,
							DatasetNum[count], Vexnum);// 37);

					String[][] dataset = ar.GetDataSet();
					Score k2 = new K2(dataset);
					
					//���д���
					int executionNumber= 10;
					
					for (int i = 0; i < executionNumber; i++)// 10
					{
						System.out.println("�������п�ʼ����ǰ��"+i+"������");
						
						k2.clearCache();
						int Num=80;

						BNGraph gk2sn = new BNGraph(Vexnum);

						double bestScore = Double.NEGATIVE_INFINITY; // �ҳ���һ�������ŷ�


						System.out.println("��"+i+"������Ⱥ,"+"��Ⱥ�й���"+Num+"������");
						//������ͼ����¡ѡ����ʣ������ʣ������ʣ������Ż������������������������������Ⱥ��ģ���ڵ�������������
					    SingleAIA sa = new SingleAIA(gk2sn, 0.5, 0.6, 0.4,
								10, 150, 70, Num, Vexnum, k2);
						sb.append("\r\n");
						
						System.out.println("Ѱ�ҵ�ǰ���ſ���");
						gk2sn = sa.findBestBayesianNet2(bestScore);
						System.out.println(gk2sn.tograph());

				}
					
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
