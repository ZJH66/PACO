package bjut.ai.bn.learning.aia;

import java.util.ArrayList;
import java.util.Random;

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;

public class SingleAnti
{
    private double[][] m_heuristicInfo; //������Ϣ
    private int m_i, m_j;//i,j���� 
	private final Random RANDOM;//�����
    private K2.TYPE type;//��������
    private Score score = null;//����
    private int vexnum;// ������
    private BNGraph m_bnGraph;
    
    //�������Ӹ���
    private double p_clone;
    private double p_cross;
    private double p_mutation;
    private int No;
    
 
    /*
     * ��ʼ������
     */
    public SingleAnti(double clone, double cross,
                      double mutation, int VexNum, double[][] InitHArray, Score score, int no)
    {
    	p_clone=clone;
        p_cross=cross;
        p_mutation=mutation;
    	this.score = score;
    	this.vexnum = VexNum;
        m_i = -1;
        m_j = -1;  
        m_bnGraph = new BNGraph(VexNum);
        RANDOM = new Random();
        m_heuristicInfo = new double[VexNum][VexNum];
		No = no;
        
        this.setInitH(InitHArray);
    }
    
    public int getNo()
    {
    	return this.No;
    }
    
    public void setScore(Score s)
    {
    	this.score = s;
    }
    
    public void setInitH(double[][] array)
    {    ArrayList<Integer> anodelist = new ArrayList<Integer> (); //��ʱ
    	//System.out.println("������" + vexnum); //2013.11.21Ϊ������ٶ�ע�͵�
    	for (int m = 0; m < array.length; m ++)
        {  		   			
   
    	    System.arraycopy(array[m], 0, this.m_heuristicInfo[m], 0, vexnum);           
            this.m_bnGraph.GetNode(m).K2Score =this.score.calcScore(m,anodelist);
            
          // System.out.println(m_heuristicInfo[1][2]);
    	
        }
    	
    }
	public void setInitH1(double[][] array) {
		for (int m = 0; m < array.length; m++) {
			System.arraycopy(array[m], 0, this.m_heuristicInfo[m], 0, vexnum);
			//this.m_bnGraph.GetNode(m).K2Score = noParVexK2Value[m];	
			
			//System.out.println(m_heuristicInfo[1][2]);
		}
	}

    /**
     * ������
     */
    void eliminateCircle()
    {
        ArrayList<Integer> ancestorslist = null;
        ArrayList<Integer> descendbeeslist = null;

        ancestorslist = m_bnGraph.GetNode(m_j).GetAncestorNodesIndex();
        descendbeeslist = m_bnGraph.GetNode(m_i).GetDescendbeeNodesIndex();

        for (int i = 0, size1 = ancestorslist.size(); i < size1; i++)
        {
            for (int j = 0, size2 = descendbeeslist.size(); j < size2; j++)
            {
                m_heuristicInfo[ancestorslist.get(i).intValue()][descendbeeslist.get(j).intValue()] = Double.NEGATIVE_INFINITY;
            }
        }
    }

    /**
     * ����������Ϣ
     * @param ParentK2score double
     * @param parentlist ArrayList
     */
    private void updateHeuristicInfo(double ParentK2score, final ArrayList<Integer> parentlist)
    {
//        System.out.println("����������Ϣ");

        for (int k = 0; k < vexnum; k++)
        {
            if (m_heuristicInfo[m_i][k] > (Double.NEGATIVE_INFINITY))
            {
                double afterAddParentK2score = 0;
                parentlist.add(m_bnGraph.GetNode(k).GetNodeId());
                int index = parentlist.size();
                afterAddParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
                m_heuristicInfo[m_i][k] = afterAddParentK2score -ParentK2score;
//                System.out.println("������Ϣ����"+m_i+":"+m_heuristicInfo[m_i][k]);
                parentlist.remove(index - 1);
            }
        }
    }

    /**
     *
     * @param base double
     */
    public void CIConstrainByValue(double base)
    {
        K2.CITestByValue(base);
        for (int i = 0; i < vexnum; i++)
        {
            for (int j = 0; j < vexnum; j++)
            {
                if (K2.ChiSquare[i][j] == 0)
                {
                    this.m_heuristicInfo[i][j] = Double.NEGATIVE_INFINITY;
                }
            }
        }

    }


    
    public void runEmpty()
    {   ArrayList<Integer> parentlist = null;
    	this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
    }
    
    public void run()
    {
        ArrayList<Integer> parentlist = null;
        do
        {
            //����ACSת�ƹ���Ѱ����һ���ߣ�j-->i��
        	do
        	{
        	m_i=RANDOM.nextInt(vexnum);
        	m_j=RANDOM.nextInt(vexnum);
        	}while(m_i==m_j);

            if (m_heuristicInfo[m_i][m_j] > 0)
            {

                m_bnGraph.AddArc(m_j, m_i);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                double ParentK2score = this.score.calcScore(m_bnGraph.
                        GetNode(m_i).
                        GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                this.updateHeuristicInfo(ParentK2score, parentlist); 
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);

        SingleAIA.addToSolutionSet(this.m_bnGraph);

    }
    
    public BNGraph runRandom()
    {
        ArrayList<Integer> parentlist = null;

        do
        {
            //���Ѱ����һ���ߣ�j-->i�� 
        	do
        	{
        	m_i=RANDOM.nextInt(vexnum);
        	m_j=RANDOM.nextInt(vexnum);
        	}while(m_i==m_j);
        	//this.choose_ijRandom();//��� ���� ��ʼ ��  ԭ��Ϊchoose_ij();
        	//System.out.println(m_heuristicInfo[m_i][m_j]);
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                    this.updateHeuristicInfo(ParentK2score, parentlist);
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
        return this.m_bnGraph;
    }

    
    public void runRandomSolution2(int k)
    {
        ArrayList<Integer> parentlist = null;
        do
        {
        	//this.choose_ij();
            if (m_heuristicInfo[m_i][m_j] > 0)
            {
                //Pa(xi) = Pa(Xi)U{Xj}����ߣ�ͬʱ�Զ����븸�׽ڵ�
                m_bnGraph.AddArc(m_j, m_i);
                m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
                //ȡ�ø�ĸ�ڵ���б�
                parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
                //
                double ParentK2score = this.score.calcScore(m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
//                System.out.println("��ǰ�ڵ�"+m_i+" ��ĸ�ڵ�"+parentlist+" ����"+ParentK2score);
                this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
                //������
                this.eliminateCircle();
                //����������Ϣ
                    this.updateHeuristicInfo(ParentK2score, parentlist);
            }
        }
        while (!stopchoose());
        this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
        SingleAIA.addToSolutionSet(this.m_bnGraph,k);
    }
    
    
    private void findMax(final double[][] temp)
    {
        double max = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < temp.length; i++)
        {
            for (int j = 0; j < temp.length; j++)
            {
                if (temp[i][j] > max)
                {
                    m_i = i;
                    m_j = j;
                    max = temp[i][j];
                }
            }
        }
//        System.out.println(m_i+" "+m_j);
    }

    
    /**
     * stopchoose
     * �ж��Ƿ�ֹͣѡ·
     * @return boolean
     */
    protected boolean stopchoose()
    {
        for (int i = 0; i < vexnum; i++)
            for (int j = 0; j < vexnum; j++)
                if (m_heuristicInfo[i][j] > 0.0)
                {
                    return false;
                }
        return true;
    }


    public BNGraph getBNgraph()
    {
        return this.m_bnGraph;
    }

    public void setBNgraph(BNGraph g)
    {
        this.m_bnGraph=g;
    }

    public double getBNGraphScore()
    {
        return this.m_bnGraph.getScore();
    }

    public static double calcGraph(BNGraph g)
    {
        double k2score = 0;
        double temp = 0;
        java.text.DecimalFormat myformat = new java.text.DecimalFormat("#0.000");

        ArrayList al = new ArrayList();
        for (int i = 0; i < K2.VEXNUM; i++)
        {
            al = g.GetNode(i).GetParentNodesIndex();
            temp = K2.INSTANCE.calcScore(i, al);

////            System.out.println("��ǰ�ڵ㣺" + i + "  ���׽ڵ�" + al + "  ����" + temp);
            System.out.println(myformat.format(temp));
//            System.out.println(  K2.INSTANCE.NodeInfo[i].size()   );
           k2score = k2score + temp;
        }
        System.out.println("�����������" + k2score);
        return k2score;
    }

  
}
