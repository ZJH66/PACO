package bjut.ai.bn;

import java.io.File;
import java.util.Hashtable;

import bjut.ai.bn.score.K2;
//import bjut.ai.sem.EMMISmile;

import smile.Network;
import smile.learning.DataSet;
import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;

public class converter {
	public static void main(String[] args){

		// Network net = new Network();
		// net.readFile("data\\alarm.xdsl");
		//		
		// int node = net.getNode("Press");
		// String[] out = net.getOutcomeIds(node);
		//		
		// CommonTools.outArray(out);

//		converter.testTranSmiledataToBjutdata();
		converter.testTranStringDataToNumData();
//		DataSet ds = new DataSet();
//		ds.readFile("c:\\alarmmiss.txt");
//		ds.matchNetwork(net);
//		smile.learning.EM em = new smile.learning.EM();
//		em.learn(ds, net);
//		net.writeFile("c:\\xun.xdsl");
//		converter.test();
		
		
	}

	/**
	 * ��bjut dataset��String ��ʽת��Ϊ bjut dataset��num��ʽ ���ܴ���ȱʧ���
	 * 
	 * @param sdata
	 * @param ndata
	 */
	public static String[][] tranStringDataToNumData(String[][] sdata
			) {
		String[][] ndata = new String[sdata.length][sdata[0].length];
		Network net = new Network();
		net.readFile("data\\Alarm.xdsl");
		int varnum = net.getNodeCount();
		Hashtable index = new Hashtable<String, Hashtable>();
		for (int i = 0; i < varnum; i++) {
			String name = net.getNodeId(i);
			String[] outcoms = net.getOutcomeIds(i);
			Hashtable temp = new Hashtable<String, String>();
			for (int j = 0; j < outcoms.length; j++) {
				temp.put(outcoms[j], String.valueOf(j));
			}
			index.put(name, temp);
		}

		for (int j = 0; j < sdata[0].length; j++) {
			for (int i = 0; i < sdata.length; i++) {
				String curname = AlarmReader1.index2nodeName.get(j + 1);
				Hashtable curindex = (Hashtable) index.get(curname);
				String numvalue = (String) curindex.get(sdata[i][j]);
				ndata[i][j] = numvalue;
			}
		}
		return ndata;
	}
	
	public static void testTranStringDataToNumData(){
		AlarmReader1 ar = new AlarmReader1("data\\missdata.txt", 3000, 37);
		String[][] sdata = ar.GetDataSet();
		String[][] ndata = converter.tranStringDataToNumData(sdata);
		
		K2 k2 = new K2(ndata);
		double s2 =k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		System.out.println(s2);
		
	}
	
	
	/**
	 * ������� ��smile��datasetת����bjut��dataset
	 * 
	 * @param ds
	 * @param dataset
	 */
	public static String[][] tranSmiledataToBjutdata(DataSet ds) {
		// smile���ݼ�����������Ӧ�Ľڵ�˳��
		int DATANUM = ds.getRecordCount();
		int VARNUM = ds.getVariableCount();
		String[][] dest = new String[DATANUM][VARNUM];
		int[] order = { 18, 21, 22, 23, 15, 36, 35, 34, 33, 32, 3, 16, 17, 25,
				19, 20, 30, 11, 31, 10, 26, 28, 5, 4, 24, 0, 29, 27, 13, 6, 7,
				8, 2, 14, 9, 1, 12 };

		for (int i = 0; i < DATANUM; i++) {
			for (int j = 0; j < VARNUM; j++) {
				int cur = ds.getInt(j, i);
				if (cur == -1) {
					dest[i][order[j]] = "*";

				} else {
					dest[i][order[j]] = Integer.toString(ds.getInt(j, i));

				}
			}
		}
		return dest;
	}

	public static void testTranSmiledataToBjutdata() {
		DataSet ds = new DataSet();
		ds.readFile("c:\\Alarm.txt");
		String[][] dest = converter.tranSmiledataToBjutdata(ds);
		AlarmReader1 ar = new AlarmReader1();
		String[][] dest2 = ar.readGeNIeDataToBjutDatanum("c:\\Alarm.txt");
		CommonTools.outArray(dest2);

		K2 k2 = new K2(dest2);
		double score = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		k2.setRecord(dest);
		double score2 = k2.calcGraphScore(BNGraph.GetGraphStandAlarm());
		System.out.println(score + "  " + score2);
	}
	
	
	public static BBNGraph TranBNtoBBN(BNGraph g) {
		BBNGraph alarm = BBNGraph.load("data\\alarm.xml");
		BBNGraph bbng = new BBNGraph();
		bbng.setName("alarm(bjut->bnj)");
		// ��ʼ���ڵ�
		for(int i = 0; i < g.getVexNum(); i++)
		{
			String CurNodeName = (String)AlarmReader1.index2nodeName.get(i+1);
			BBNNode node = new BBNNode();
			BBNDiscreteValue values = (BBNDiscreteValue)((BBNNode)alarm.getNode(CurNodeName)).getValues();
			node.setValues(values);
			node.setName(CurNodeName);
			bbng.add(node);
		}
		// ���ñ�
		int[][] edges = g.GetArcArray();
		for (int i = 0; i < edges.length; i++) {
			for (int j = 0; j < edges[0].length; j++) {
				if (edges[i][j] == 1) {
					String srcName = (String)AlarmReader1.index2nodeName.get(i+1);
					String desName = (String)AlarmReader1.index2nodeName.get(j+1);
					BBNNode src = (BBNNode)bbng.getNode(srcName);
					BBNNode des = (BBNNode)bbng.getNode(desName);
					bbng.addEdge(src, des);					
				}
			}
		}
		return bbng;
	}
	
	
	
	
	public static Network tranBNJnetToSmilenet(BBNGraph bnjnet){
		String systemp = System.getenv("TEMP");	
		String temptype = "dsl";
		String tempfile = systemp+"\\temp2."+temptype;
		
		bnjnet.save(tempfile,temptype);
		
		Network net = new Network();
		net.readFile(tempfile);
		return net;
	}
	
	
	/**
	 * 
	 * @param bjut
	 * @param net
	 */
	public static Network transBjutNetToSmileNet(BNGraph bjut) {
		Network net = new Network();
		Network ssmile = new Network();
		ssmile.readFile("data\\Alarm.xdsl");
		String[] names = ssmile.getAllNodeIds();
		// add node
		for (int i = 0; i < names.length; i++) {
			net.addNode(Network.NodeType.Cpt, names[i]);
		}
		// net.writeFile("c:\\tran001.xdsl");
		names = net.getAllNodeIds();
		// add each node's outcomes
		for (int i = 0; i < names.length; i++) {
			String CurNodeName = names[i];
			String[] ids = ssmile.getOutcomeIds(CurNodeName);
		
			for (int j = 0; j < ids.length; j++) {
				net.addOutcome(CurNodeName, ids[j]);
			}
		}
		
		for (int i = 0; i < names.length; i++) {
			for (int m = 0; m < 2; m++) {
				net.deleteOutcome(names[i], 0);
			}
		}

		
		int[][] edges = bjut.GetArcArray();
		for (int i = 0; i < edges.length; i++) {
			for (int j = 0; j < edges[0].length; j++) {
				if (edges[i][j] == 1) {
					String from = (String) AlarmReader1.index2nodeName
							.get(i + 1);
					String to = (String) AlarmReader1.index2nodeName.get(j + 1);
					net.addArc(from, to);
				}
			}
		}
		// cpt not set!
		
		
		return net;
		
	}
	
	public static void test(){
		BNGraph g = BNGraph.GetGraphStandAlarm();
		Network net = new Network();
		net = converter.transBjutNetToSmileNet(g);
		net.writeFile("c:\\temp.xdsl");
		
		
	}
	
	
	public static BBNGraph tranSmilenetToBNJnet(Network net)
	{
//		BBNGraph bbng = new BBNGraph();
//		
//		int[] nodes = net.getAllNodes();//�ڵ���
//		String[] names = net.getAllNodeIds();//�ڵ�����
//				
//		bbng.setName("alarm(smile->bnj)");
//		// ��ʼ���ڵ�
//	
//		for(int i = 0; i < nodes.length; i++){
//			BBNNode node = new BBNNode(bbng, names[i]);
//			bbng.addNode(node);
//			BBNDiscreteValue v = new BBNDiscreteValue();
//			String[] outcomes = net.getOutcomeIds(nodes[i]);
//			for(int j = 0; j < outcomes.length; j++)
//				v.add(outcomes[j]);
//			node.setValues(v);
//		}
//		
//		// ���ñ�
//		for(int i = 0; i < nodes.length; i++){
//			String[] children = net.getChildIds(nodes[i]);
//			for(int j = 0; j < children.length; j++){
//				bbng.addEdge(bbng.getNode(names[i]),bbng.getNode(children[j]));
//			}
//		}
//		//����cpf��
//		for(int i = 0; i < nodes.length; i++){
//			BBNNode curnode = (BBNNode)bbng.getNode(names[i]);
//			double[] valuse = net.getNodeDefinition(nodes[i]);
//			String[] parent = net.getParentIds(nodes[i]);
//			
//			
//		}
		String systemp = System.getenv("TEMP");	
		File f =new  File(systemp);
		f.mkdir();
		String temptype = "net";
		String tempfile = systemp+"\\temp."+temptype;
		
		net.writeFile(tempfile);
		BBNGraph g = BBNGraph.load(tempfile);
		return g;
	}

}
