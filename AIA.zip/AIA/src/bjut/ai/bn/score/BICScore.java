package bjut.ai.bn.score;
import edu.ksu.cis.bnj.bbn.BBNGraph;

public class BICScore {
	public double calcExpectedBICScore(BBNGraph g, String[][] MissDataset)
	{
		double score = -1.0;
		
		return score;
	}
}
