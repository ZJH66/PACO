/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import oracle.jdbc.driver.OracleDriver;
public class DtbaseCon
{
	Connection con;
	Statement stmt;
	public DtbaseCon()throws SQLException, ClassNotFoundException
	{
		String tableNames[] = new String[4];
		tableNames[0] = "INSTRUCTOR1";
		tableNames[1] = "STUDENT1";
		tableNames[2] = "COURSE1";		
		tableNames[3] = "REGISTRATION1";	
		LinkedList attributeList[] = new LinkedList[4];
		
		
				
		String 
			userName = "pbo8844",
			password = "cis761",
			url = "jdbc:oracle:thin:@zaurak.cis.ksu.edu:1521:PROD",
			insertC = "insert into carsTable ";
			DriverManager.registerDriver(new OracleDriver());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con =  DriverManager.getConnection(url, userName , password);
			stmt = con.createStatement();
			int tableCount = tableNames.length;
			String selectQueryString = "Select * from ";
						
			for (int tableIndex = 0; tableIndex < tableCount; tableIndex++)
			{		
				attributeList[tableIndex] = new LinkedList();		
				System.out.println("------------------");
				System.out.println("TableName = " + tableNames[tableIndex]);
				String queryString = selectQueryString + tableNames[tableIndex];
				ResultSet rs = stmt.executeQuery(queryString);
				ResultSetMetaData instructorTable= rs.getMetaData();
				int numberOfColumns = instructorTable.getColumnCount();
				System.out.println("number Of Columns " + numberOfColumns);
				for (int i = 0; i < numberOfColumns; i++)
				{
						String columnName = instructorTable.getColumnName(i+1);
						attributeList[tableIndex].add(columnName);
				}
				System.out.println("attributList = " + attributeList[tableIndex]);									 
			}	
			for (int tableIndex = 0; tableIndex < tableCount; tableIndex++)
			{
				List attributes = attributeList[tableIndex];							
				String tableName = tableNames[tableIndex];
				for (int j = 0; j < attributes.size(); j++)
				{
					String attributeName = (String) attributes.get(j);
					String nextAttribute;					
					if ( j < attributes.size() - 2)
					{
							nextAttribute = 	(String) attributes.get(j+1);			
							attributeName += " , " + nextAttribute;
					}		
				/*	String SelectQuery = "SELECT " + attributeName + ", " +" COUNT(" + attributeName + ") ";
					SelectQuery += " FROM " + tableName; 
					SelectQuery += " GROUP BY " + attributeName;
					System.out.println( SelectQuery);
					ResultSet rs = stmt.executeQuery(SelectQuery);
					ResultSetMetaData instructorTable= rs.getMetaData();
					int numberOfColumns = instructorTable.getColumnCount();
					System.out.println("number Of Columns " + numberOfColumns);*/
				/*	while (rs.next())
					{
						for (int i = 0; i < numberOfColumns; i++)
						{
							System.out.print(rs.getString(i + 1) + " " );
						}
					}*/
			}	
					
					String sAttributeNames[] = new String[3];
					String sTableNames[] = new String[3];
					sAttributeNames[0] = "grade";
					sAttributeNames[1] = "intelligence";
					sAttributeNames[2] = "difficulty";
					sTableNames[0] = "registration1";
					sTableNames[1] = "student1";
					sTableNames[2] = "course1";
					getScore(sAttributeNames, sTableNames);					
				
			}
	}
	
	
	public void getScore(String attributeNames[], String tableNames[]) throws SQLException, ClassNotFoundException
	{
		String attributeQuery = preprocessArrayToString(attributeNames);
		String tableNameQuery = preprocessArrayToString(tableNames);
		String sqlQuery = "SELECT " ;
		sqlQuery += " COUNT(*) ";
		sqlQuery += "FROM " + tableNameQuery;
		sqlQuery += "GROUP BY " + attributeQuery;
		System.out.println(sqlQuery);
		ResultSet rs = stmt.executeQuery(sqlQuery);
		ResultSetMetaData instructorTable= rs.getMetaData();
		int numberOfColumns = instructorTable.getColumnCount();
		System.out.println("number Of Columns " + numberOfColumns);
		while (rs.next())
		{
				for (int i = 0; i < numberOfColumns; i++)
			{
						System.out.print(rs.getString(i + 1) + " " );
			}
		} 
		
		
	}
	
	
	public String preprocessArrayToString(String[] attributesNames)
	{
		String queryAttributes = " ";		
		int stringLength	= attributesNames.length;
		for (int i = 0; i < stringLength; i++)
		{
			if (i < stringLength - 1)
				queryAttributes += (attributesNames[i] + ", " );
			else 			
				queryAttributes += (attributesNames[i] + " ");
		}
		return queryAttributes;
	}
	public static void main(String args[])throws 
	SQLException,ClassNotFoundException
	{
		System.out.println("Opening the Table");
		DtbaseCon car = new DtbaseCon();
	}
}


	    
