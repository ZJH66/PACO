/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



package edu.ksu.cis.bnj.bbn.inference;



import java.util.Hashtable;
import java.util.Iterator;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.kdd.util.FileClassLoader;
import edu.ksu.cis.kdd.util.gui.OptionGUI;
import edu.ksu.cis.kdd.util.gui.Optionable;

/**
 * Abstract Inference class
 * 
 * @author robbyjo
 */
public abstract class Inference implements Optionable {
    public static final String inferenceClassName = "edu.ksu.cis.bnj.bbn.inference.Inference";
    public static final String OPT_RUN_TYPE = "inferenceType";
    public static final int MAP = 2;
    public static final int MPE = 1;
    public static final int MARGINALS = 0;

    protected Hashtable options = getDefaultOptions();
    protected InferenceResult marginalsResult;

    protected BBNGraph graph = null;

    public Inference() {
    }

    public Inference(BBNGraph g) {
        this();
        setGraph(g);
    }

	/**
	 * Returns the graph.
	 * @return BBNGraph
	 */
	public BBNGraph getGraph() {
		return graph;
	}

	/**
	 * Sets the graph.
	 * @param graph The graph to set
	 */
	public void setGraph(BBNGraph graph) {
		this.graph = graph;
	}

    /**
     * Getting the result of the marginals (i.e. the belief revision)
     * @return InferenceResult The marginals
     */
    public abstract InferenceResult getMarginals();

    public abstract String getName();

    /**
     * Get the Most Probable Explanation (MPE) values for each nodes.
     * @return Hashtable the MPE in the format of NodeName -> MostProbableValue
     */
    public Hashtable getMPE() {
        InferenceResult resultCache = getMarginals();
        Hashtable mpe = new Hashtable();

        for (Iterator i = resultCache.keySet().iterator(); i.hasNext(); ) {
            String nodeName = (String) i.next();
            Hashtable tbl = (Hashtable) resultCache.get(nodeName);
            String highestValue = null;
            double highestProb = 0.0;
            for (Iterator j = tbl.keySet().iterator(); j.hasNext(); ) {
                String value = (String) j.next();
                double p = ((Double) tbl.get(value)).doubleValue();
                if (p > highestProb) {
                    highestProb = p;
                    highestValue = value;
                }
            }
            mpe.put(nodeName, highestValue);
        }

        return mpe;
    }

    /**
     * Get the Maximum Aposteriori Probabilities (MAP)
     * @return Hashtable the MAP in the format of NodeName -> MostProbableValue
     */
    public Hashtable getMAP() {
        return null;
    }

    @Override
	public OptionGUI getOptionsDialog() {
        return null;
    }
    @Override
	public void setOptions(Hashtable optionTable){
        options = optionTable;
    }

    @Override
	public void setOption(String key, Object val) {
        options.put(key,val);
    }

    @Override
	public Hashtable getDefaultOptions() {
        return new Hashtable();
    }

    @Override
	public Hashtable getCurrentOptions() {
        return options;
    }

    public void setRunType(int type) {
        options.put(OPT_RUN_TYPE, new Integer(type));
    }

    public int getRunType() {
        Integer i = (Integer) options.get(OPT_RUN_TYPE);
        if (i == null) return MARGINALS;
        return i.intValue();
    }

    public void setOutputFile(String fn) {
        options.put(OPT_OUTPUT_FILE, fn);
    }

    public String getOutputFile() {
        return (String) options.get(OPT_OUTPUT_FILE);
    }

    public void execute() { // TODO: This is a hack. I hate it. Do it later
        // generic execute
        assert(graph != null);
        switch (getRunType()) {
            case MARGINALS:
                 marginalsResult = getMarginals();
                 String outputFile = getOutputFile();
                 if (outputFile == null) {
                     marginalsResult.save(outputFile);
                 }
                 break;
            case MPE:
            case MAP:
                 throw new RuntimeException("Not done yet");
        }
    }

    public InferenceResult getMarginalsResult() {
        return marginalsResult;
    }

    public static Inference load(String className, BBNGraph g) {
        try {
            Inference inf = (Inference) FileClassLoader.loadAndInstantiate(className, inferenceClassName, null,
                new Class[] { BBNGraph.class }, new Object[] {g});
            return inf; 
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }
}
