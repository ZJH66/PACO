/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */





package edu.ksu.cis.bnj.bbn.learning.scorebased.sparse;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.learning.LearnerScore;
import edu.ksu.cis.bnj.bbn.learning.ScoreBasedLearner;
import edu.ksu.cis.bnj.bbn.learning.score.ShieldScore;
import edu.ksu.cis.kdd.data.Data;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.util.Parameter;
import edu.ksu.cis.kdd.util.ParameterTable;
import edu.ksu.cis.kdd.util.graph.Clique;
import edu.ksu.cis.kdd.util.graph.CliqueTree;
import edu.ksu.cis.kdd.util.graph.StronglyConnectedComponents;

/**
 * <P>Sparse Candidate implementation.
 * 
 * <P>Friedman, N., Nachman, I., Peer, D., Learning Bayesian Network Structure
 * from Massive Datasets: The "Sparse Candidate" algorithm, 1999.
 * 
 * @author Roby Joehanes
 */
public class SparseCandidate extends ScoreBasedLearner {

    public static final double defaultScoreThreshold = Double.NEGATIVE_INFINITY;
    public static final int defaultIteration = 100;

    protected HashSet[] candidateTable;
    protected SubGraph curGraph;
    protected int maxIteration = defaultIteration;
    protected int maxNoImproveIteration = 10;
    protected double scoreThreshold = defaultScoreThreshold;
    protected int max;


    /**
     * Helper class for Sparse Candidate. Not visible to
     * other structures.
     * 
     * @author Roby Joehanes
     */
    class SubGraph implements Cloneable {
        HashSet[] graph;
        double score = Double.NEGATIVE_INFINITY;

        void union(SubGraph g) {
            if (g.graph != null) {
                int max = graph.length;
                for (int i = 0; i < max; i++) {
                    graph[i].addAll(g.graph[i]);
                }
            }
            score = Math.max(score, g.score);
        }

        @Override
		public Object clone() { // gotta be public otherwise Java would complain
            SubGraph newg = new SubGraph();
            if (graph != null) {
                int max = graph.length;
                newg.graph = new HashSet[max];
                for (int i = 0; i < max; i++) {
                    newg.graph[i] = (HashSet) graph[i].clone();
                }
            }
            newg.score = score;
            return newg;
        }
    }

    class Candidate implements Comparable {
        int node;
        double score;

        public Candidate (int n, double s) {
            node = n; score = s;
        }

		/**
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(Object o) {
            Candidate c = (Candidate) o;
            return score < c.score ? -1 : score == c.score ? 0 : 1;
		}

        @Override
		public String toString() {
            return node+"="+score;
        }
    }

    public SparseCandidate(){}

	/**
	 * @param t
	 */
	public SparseCandidate(Data t) {
		super(t);
	}

	/**
	 * @param t
	 * @param s
	 */
	public SparseCandidate(Data t, LearnerScore s) {
		super(t, s);
	}

    /**
     * @param t
     * @param s
     * @param s2
     */
    public SparseCandidate(Table t, LearnerScore s, LearnerScore s2) {
        super(t, s, s2);
    }

    /**
     * @see edu.ksu.cis.bnj.bbn.learning.Learning#initialize()
     */
    @Override
	public void initialize() {
    }

	/**
	 * @see edu.ksu.cis.bnj.bbn.learning.Learning#getGraph()
	 */
	@Override
	public BBNGraph getGraph() {
        // if no scorer module mentioned, default to K2 scorer
        if (candidateScorer == null) candidateScorer = new ShieldScore(this);
        //if (structureScorer == null) structureScorer = new BDEScore(this);

        candidateScorer.initialize();

        // Preparation
        BBNGraph graph = populateNodes();
        max = data.getAttributes().size();
        curGraph = new SubGraph();
        curGraph.graph = new HashSet[max];
        for (int i = 0; i < max; i++) {
            curGraph.graph[i] = new HashSet();
        }

        int iteration = 0;
        int noImproveIteration = 0;
        double delta;

        do {
            System.out.println();
            System.out.println("Iteration: "+iteration);
            delta = 0.0;
            candidateTable = restrict();
            System.out.println();
            SubGraph g = maximize();
            if (g.score > curGraph.score) {
                delta = g.score - curGraph.score;
                curGraph = g;
                noImproveIteration = 0;
            } else {
                noImproveIteration++;
            }
            iteration++;
        } while (iteration < maxIteration && noImproveIteration < maxNoImproveIteration);

        // Make sure everything is ok
        assert (curGraph != null && curGraph.graph != null);

        // Convert curGraph to BBNGraph
        // Construct the graph out of the adjacency list
        for (int i = 0; i < max; i++) {
            HashSet parents = curGraph.graph[i];
            if (parents == null) continue;
            for (Iterator j = parents.iterator(); j.hasNext(); ) {
                int parent = ((Integer) j.next()).intValue();
                graph.addEdge(bbnNodes[parent], bbnNodes[i]);
            }
        }

        computeCPT(graph);
        System.out.println("-----------------------");
        System.out.println("Graph is:");
        System.out.println(graph.toString());

        return graph;
	}

    /**
     * Restrict step: Return the candidate table (from a String denoting the current node
     * to its set of candidates). 
     */
    protected HashSet[] restrict() {
        HashSet[] result = new HashSet[max];

        for (int i = 0; i < max; i++) {
            System.out.println("For node "+bbnNodes[i]);
            result[i] = new HashSet();
            result[i].addAll(curGraph.graph[i]);
            if (result[i].size() >= parentLimit) continue; 

            TreeSet candidates = new TreeSet(); // Sorted set with log(n) performance guarantee
            double threshold = candidateScorer.getScore(i, i, curGraph.graph);
            if (threshold < scoreThreshold) threshold = scoreThreshold;

            for (int j = 0; j < max; j++) {
                Integer jCandidate = new Integer(j);
                if (i == j || result[i].contains(jCandidate)) continue;
                double score = candidateScorer.getScore(i, j, curGraph.graph);

                //System.out.println("Candidate "+bbnNodes[j]+ " has a score of "+score);              
                if (score >= threshold) {
                    Candidate candidate = new Candidate(j, score);
                    candidates.add(candidate);
                }
            }
			
            while ((result[i].size() < parentLimit) && (candidates.size() > 0)) {
                Candidate c = (Candidate) candidates.last();
                candidates.remove(c);
                // print: candidates in descending order of score - WHH
                // ### [WHH] also needed: adjacency matrix with false positives, negatives, correct candidates given gold standard network
                System.out.println("Candidate "+bbnNodes[c.node]+ " has a score of "+c.score);              

                result[i].add(new Integer(c.node));
            }
            System.out.println();
        }

        System.out.println("Node = [Parent candidates]");
        for (int i = 0; i < max; i++) {
            System.out.print(bbnNodes[i]+" = [");
            for (Iterator j = result[i].iterator(); j.hasNext(); ) {
                int ij = ((Integer) j.next()).intValue();
                System.out.print(bbnNodes[ij]+" ");
            }
            System.out.println("]");
        }

        return result;
    }

    protected SubGraph maximize() {
        return sccDecomposition(candidateTable);
    }

    protected SubGraph sccDecomposition(HashSet[] adjList) {
        StronglyConnectedComponents scc = new StronglyConnectedComponents(adjList);
        Set components = scc.getComponents();

        System.out.println("Strongly Connected Components");
        for (Iterator i = components.iterator(); i.hasNext(); ) {
            Set parentCluster = (Set) i.next();
            System.out.print("[");
            for (Iterator j = parentCluster.iterator(); j.hasNext(); ) {
                int nodeInt = ((Integer) j.next()).intValue();
                System.out.print(bbnNodes[nodeInt]+" ");
            }
            System.out.println("]");
        }

        Hashtable clusterTable = scc.getClusterTable();
        HashSet seenBefore = new HashSet();
        SubGraph result = null;
        for (Iterator i = components.iterator(); i.hasNext(); ) {
            Set parentCluster = (Set) i.next();
            if (seenBefore.contains(parentCluster)) continue;
            SubGraph g = dfsSccDecomposition(parentCluster, seenBefore, clusterTable, adjList);
            if (result == null) {
                result = g;
            } else {
                result.union(g);
            }
        }
        return result;
    }

    protected SubGraph dfsSccDecomposition(Set curCluster, Set seenBefore, Hashtable clusterTable, HashSet[] adjList) {
        seenBefore.add(curCluster);
        // Search U-subclusters here
        SubGraph g1 = clusterDecomposition(curCluster, adjList);

        for (Iterator j = curCluster.iterator(); j.hasNext(); ) {
            Integer node = (Integer) j.next();
            int nodeInt = node.intValue();
            Set nextNodes = adjList[nodeInt];
            if (nextNodes == null) continue;
            for (Iterator k = nextNodes.iterator(); k.hasNext(); ) {
                Object nextNode = k.next();
                // we're only considering nodes that belong to another cluster
                if (!curCluster.contains(nextNode)) {
                    Set clusterSet = (Set) clusterTable.get(nextNode);
                    if (!seenBefore.contains(clusterSet)) {
                        SubGraph g2 = dfsSccDecomposition(clusterSet, seenBefore, clusterTable, adjList);

                        // Then combine g1 and g2
                        g1.union(g2);
                    }
                }
            }
        }
        return g1;
    }

    protected SubGraph clusterDecomposition(Set curCluster, HashSet[] adjList) {
        CliqueTree tree = new CliqueTree(getAdjacencyList(curCluster, adjList));
        // Now we get the cluster tree
        List rootCliques = tree.getRoot();
        SubGraph result = null;

        if (rootCliques == null || rootCliques.size() == 0) {
            result = new SubGraph();
            result.graph = adjList;
        } else {
            HashSet seenBefore = new HashSet();
            for (Iterator i = rootCliques.iterator(); i.hasNext(); ) {
                Clique clique = (Clique) i.next();
                if (seenBefore.contains(clique)) continue;
                SubGraph g = dfsClusterDecomposition(clique, seenBefore, adjList);
                if (result == null) {
                    result = g;
                } else {
                    result.union(g);
                }
            }
        }
        return result;
    }

    protected SubGraph dfsClusterDecomposition(Clique curCluster, Set seenBefore, HashSet[] adjList) {
        seenBefore.add(curCluster);
        SubGraph result = new SubGraph();

        for (Iterator i = curCluster.getChildren().iterator(); i.hasNext(); ) {
            Clique child = (Clique) i.next();
            Set separator = curCluster.intersect(child);
            assert(separator.size() > 0);
            Set curClusterSet = curCluster.difference(separator);
            Set childClusterSet = child.difference(separator);

            // must check cyclicity on curClusterSet and childClusterSet
            // If any of them are cyclic, decompose further, otherwise compute score
            HashSet[] curSetAdjList = getAdjacencyList(curClusterSet, adjList);
            SubGraph g1 = null;
            if (isCyclic(curSetAdjList)) {
                g1 = clusterDecomposition(curClusterSet, curSetAdjList);
            } else {
                g1 = new SubGraph();
                g1.graph = curSetAdjList;
                g1.score = computeStructureScore(curSetAdjList);
            }

            HashSet[] childAdjList = getAdjacencyList(childClusterSet, adjList);
            SubGraph g2 = null;
            if (isCyclic(childAdjList)) {
                g2 = clusterDecomposition(childClusterSet, childAdjList);
            } else {
                g2 = new SubGraph();
                g2.graph = childAdjList;
                g2.score = computeStructureScore(childAdjList);
            }

            int max = curSetAdjList.length;
            HashSet[] combinedTable = new HashSet[max];
            for (int j = 0; j < max; j++) {
                combinedTable[j] = new HashSet();
                if (curSetAdjList[j] != null) combinedTable[j].addAll(curSetAdjList[j]);
                if (childAdjList[j] != null) combinedTable[j].addAll(childAdjList[j]);
            }

            // Then brute force separator enumeration ordering and combine the two
            // clusters

            if (separator.size() > 1) {
                LinkedList sepList = new LinkedList();
                sepList.addAll(separator);
                enumerateOrdering(sepList, new LinkedList(), combinedTable, result);
            } else {
                double score = computeStructureScore(combinedTable);
                if (result.graph == null) {
                    result.graph = combinedTable;
                    result.score = score;
                } else {
                    for (int j = 0; j < max; j++) {
                        if (result.graph[j] != null && combinedTable[j] != null) {
                            result.graph[j].addAll(combinedTable[j]);
                        }
                    }
                    //result.graph.putAll(combinedTable);
                    result.score = Math.max(result.score, score);
                }
            }
        }

        return result;
    }

    protected void enumerateOrdering(LinkedList order, LinkedList curOrder, HashSet[] adjList, SubGraph result) {
        int max = order.size();
        if (max == 0) {
            //System.out.println(curOrder.toString());
            // Assume curOrder_i -> curOrder_i+1
            max = adjList.length;
            Integer[] nodes = (Integer[]) curOrder.toArray(new Integer[0]);
            HashSet[] tempResult = new HashSet[max];
            for (int i = 0; i < max; i++) {
                tempResult[i] = new HashSet();
                if (adjList[i] != null) tempResult[i].addAll(adjList[i]);
            }
            max = nodes.length;
            for (int i = 1; i < max; i++) {
                tempResult[nodes[i].intValue()].add(nodes[i-1]);
            }

            double score = computeStructureScore(tempResult);
            if (score > result.score) {
                result.graph = tempResult;
                result.score = score;
            }

            return;
        }

        Object[] nodes = order.toArray();
        for (int i = 0; i < max; i++) {
            Object node = order.remove(i);
            curOrder.add(node);
            enumerateOrdering(order, curOrder, adjList, result);
            curOrder.remove(node);
            order.add(i,node);
        }
    }

    /**
     * Compute the graph (or subgraph) score using structure scorer
     * @param adjList
     * @return double
     */
    protected double computeStructureScore(Set[] adjList) {
        // not yet
        return structureScorer.getScore(0, LearnerScore.NO_CANDIDATES, adjList);
    }

    /**
     * Get the partial adjacency list of a cluster, only listing nodes that
     * is within the cluster.
     * 
     */
    protected HashSet[] getAdjacencyList(Set cluster, HashSet[] curAdjList) {
        HashSet[] tbl = new HashSet[max];
        for (Iterator i = cluster.iterator(); i.hasNext(); ) {
            Integer node = (Integer) i.next();
            int nodeInt = node.intValue();
            Set parents = curAdjList[nodeInt];
            if (parents != null) {
                for (Iterator j = parents.iterator(); j.hasNext(); ) {
                    Integer parent = (Integer) j.next();
                    if (cluster.contains(parent)) {
                        if (tbl[nodeInt] == null) tbl[nodeInt] = new HashSet();
                        tbl[nodeInt].add(parent);
                    } 
                }
            }
        }

        return tbl;
    }

    /**
     * To detect whether the given adjacency list is cyclic or not
     * @param adjList
     * @return boolean
     */
    protected boolean isCyclic(HashSet[] adjList) {
        int n = adjList.length;
        for (int i = 0; i < n; i++) {
            Set parents = adjList[i];
            if (parents == null) continue;
            for (Iterator j = parents.iterator(); j.hasNext(); ) {
                Integer parent = (Integer) j.next();
                int parentInt = parent.intValue();
                
                Set grandParents = adjList[parentInt];
                if (grandParents == null) continue;
                if (grandParents.contains(new Integer(i)))
                    return true; // Cycle
            }
        }

        return false;
    }

	/**
	 * @return int
	 */
	public int getMaxIteration() {
		return maxIteration;
	}

	/**
	 * Sets the maxIteration.
	 * @param maxIteration The maxIteration to set
	 */
	public void setMaxIteration(int maxIteration) {
		this.maxIteration = maxIteration;
	}

    /**
     * @return int
     */
    public int getMaxNoImproveIteration() {
        return maxNoImproveIteration;
    }

    /**
     * Sets the maxNoImproveIteration.
     * @param maxNoImproveIteration The maxNoImproveIteration to set
     */
    public void setMaxNoImproveIteration(int maxNoImproveIteration) {
        this.maxNoImproveIteration = maxNoImproveIteration;
    }

    public void setScoreThreshold(double t) {
        scoreThreshold = t;
    }

    @Override
	public void processParameters(String[] args) {
    }

    @Override
	public String getName() {
        return "Sparse Candidate";
    }

    public static void main(String[] args) {
        ParameterTable params = Parameter.process(args);
        String inputFile = params.getString("-i");
        String outputFormat = params.getString("-f");
        String outputFile = params.getString("-o");
        int maxParent = params.getInt("-k", defaultParentLimit);
        double threshold = params.getDouble("-t", defaultScoreThreshold);
        int iterations = params.getInt("-n", defaultIteration);
        boolean quiet = params.getBool("-q");

        if (inputFile == null) {
            System.out.println("Usage: edu.ksu.cis.bnj.bbn.learning.sparse.SparseCandidate -i:inputfile [-o:outputfile] [-f:outputformat] [-k:parentlimit] [-t:threshold] [-n:iteration] [-q]");
            System.out.println("-f: default=xml. Acceptable values are {xml, net, bif, xbn}");
            System.out.println("-k: parent limit. Default="+defaultParentLimit);
            System.out.println("-q: quiet mode");
            return;
        }
        System.out.println("Sparse Candidate learning");

        try {
            Runtime r = Runtime.getRuntime();
            long origfreemem = r.freeMemory();
            long freemem;
            long origTime = System.currentTimeMillis();
            Table tuples = Table.load(inputFile);
            SparseCandidate sc = new SparseCandidate(tuples);
            //sc.setCalculateCPT(false);
            sc.setParentLimit(maxParent);
            sc.setScoreThreshold(threshold);
            sc.setMaxIteration(iterations);

            System.gc();
            long afterLoadTime = System.currentTimeMillis();
            freemem = r.freeMemory() - origfreemem;

            if (!quiet) {
                System.out.println("Memory needed after loading tuples = "+freemem);
                System.out.println("Loading time = "+((afterLoadTime - origTime) / 1000.0));
            }

            BBNGraph g = sc.getGraph();
            long learnTime = System.currentTimeMillis();
            freemem = r.freeMemory() - origfreemem;

            if (!quiet) {
                System.out.println("Memory needed after learning Sparse Candidate = "+freemem);
                System.out.println("Learning time = "+((learnTime - afterLoadTime) / 1000.0));
            }

            if (outputFile != null) {
                if (outputFormat != null) {
                    g.save(outputFile, outputFormat);
                } else {
                    g.save(outputFile);
                }
            } 
            //if (k2 != null) // A dummy statement to prevent K2 being garbage collected
                //System.out.println(g.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
