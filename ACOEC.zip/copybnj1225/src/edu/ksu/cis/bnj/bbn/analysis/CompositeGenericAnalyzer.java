/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */




package edu.ksu.cis.bnj.bbn.analysis;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ksu.cis.bnj.bbn.BBNGraph;

/**
 * A broadcaster collection of analyzer (Composite pattern)
 * @author Roby Joehanes
 */
public class CompositeGenericAnalyzer extends GenericAnalyzer {
    protected List analyzers = new LinkedList();

    public void addAnalyzer(GenericAnalyzer a) {
        assert a != null;
        analyzers.add(a);
    }

    public void removeAnalyzer(GenericAnalyzer a) {
        assert a != null;
        analyzers.remove(a);
    }

    public boolean isAnalyzerRegistered(GenericAnalyzer a) {
        return analyzers.contains(a);
    }

    /**
	 * @see edu.ksu.cis.bnj.bbn.analysis.GenericAnalyzer#analyzeGoldGraph(edu.ksu.cis.bnj.bbn.BBNGraph)
	 */
	@Override
	protected Object analyzeGoldGraph(BBNGraph gold) {
        CompositeAnalyzerResult r = new CompositeAnalyzerResult();
        for (Iterator i = analyzers.iterator(); i.hasNext(); ) {
            GenericAnalyzer a = (GenericAnalyzer) i.next();
            r.add(a.analyzeGoldGraph(gold));
        }
		return r;
	}

    /**
	 * @see edu.ksu.cis.bnj.bbn.analysis.GenericAnalyzer#evaluate(edu.ksu.cis.bnj.bbn.BBNGraph)
	 */
	@Override
	protected Object evaluate(BBNGraph g) {
        CompositeAnalyzerResult r = new CompositeAnalyzerResult();
        for (Iterator i = analyzers.iterator(); i.hasNext(); ) {
            GenericAnalyzer a = (GenericAnalyzer) i.next();
            r.add(a.evaluate(g));
        }
        return r;
	}

    /**
	 * @see edu.ksu.cis.bnj.bbn.analysis.GenericAnalyzer#evaluate(java.lang.Object)
	 */
	@Override
	protected Object evaluate(Object result) {
        CompositeAnalyzerResult r = new CompositeAnalyzerResult();
        for (Iterator i = analyzers.iterator(); i.hasNext(); ) {
            GenericAnalyzer a = (GenericAnalyzer) i.next();
            r.add(a.evaluate(result));
        }
        return r;
	}
}
