/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */




package edu.ksu.cis.bnj.bbn.analysis;
import java.util.Iterator;

import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.inference.Inference;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;
import edu.ksu.cis.kdd.util.FileClassLoader;


/**
 * A convenience class to calculating RMSE
 *
 * @author Roby Joehanes
 */
public class RMSEAnalyzer extends GenericAnalyzer {
    protected static final String ln = System.getProperty("line.separator"); // $NON-NLS-1$
    protected double max = Double.MIN_VALUE;
    protected double min = Double.MAX_VALUE;
    protected Class inference = LS.class;
    protected static final Class inferenceClass = Inference.class;
    protected static final Class[] inferenceCtorParam = new Class[] { BBNGraph.class };

    public RMSEAnalyzer() { super(); }

    public RMSEAnalyzer(BBNGraph graph) {
        super(graph);
    }

    public void setInferenceClass(Class i) {
        if (i == null || !inferenceClass.isAssignableFrom(i)) {
            throw new RuntimeException("Error: the class should be an instance of Inference");
        }
        inference = i;
    }

    protected Inference instantiateInference(BBNGraph g) {
        try {
            return (Inference) FileClassLoader.loadAndInstantiate(inference.getName(), inferenceClass.getName(), null, inferenceCtorParam, new Object[] {g});
        } catch (Exception e) {
            return null;
        }
    }
    /**
     * Analyze the gold-standard graph.
     */
    @Override
	protected Object analyzeGoldGraph(BBNGraph gold) {
        Inference i = instantiateInference(gold);
        return i.getMarginals();
    }

    /**
     * Analyze the graph. Return null if it's not analyzable
     */
    @Override
	protected Object evaluate(BBNGraph g) {
        System.out.println("Debug graph:\n"+g.debugGetEdgePrintout());
        Inference i = instantiateInference(g);
        InferenceResult result = i.getMarginals();
        System.out.println("Debug result:\n"+result);
        return evaluate(result);
    }

    /**
     * @see edu.ksu.cis.bnj.bbn.analysis.GenericAnalyzer#analyzeGraph(edu.ksu.cis.bnj.bbn.BBNGraph, java.lang.Object, edu.ksu.cis.bnj.bbn.BBNGraph, java.lang.Object)
     */
    @Override
	protected Object evaluate(Object result) {
        assert result instanceof InferenceResult;
        double r = ((InferenceResult) goldResult).computeRMSE((InferenceResult) result);
        System.out.println("RMSE = "+r);
        if (r > max) max = r;
        if (r < min) min = r;
        return new Double(r);
    }

    public double getMax() { return max; }
    public double getMin() { return min; }

    @Override
	public String toString() {
        StringBuffer s = new StringBuffer();
        for (Iterator i = results.iterator(); i.hasNext(); ) {
            s.append(((Double) i.next()).doubleValue()+ln);
        }
        return s.toString();
    }

}
