/*
 * 
 * This file is part of "Bayesian Network tools in Java (BNJ)" 2.0
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * BNJ Version History
 * ---------------------------------------------
 * BN tools Jan 2000-May 2002
 *
 *  prealpha- January 200 - June 2001
 *	Benjamin Perry, Haipeng Guo, Laura Haverkamp
 *  Version 1- June 2001 - May 2002
 * 	Haipeng Guo, Benjamin Perry, Julie A. Thornton BNJ
 *
 * Bayesian Network for Java (BNJ).
 *  Version 1 - May 2002 - July 2003
 *  	release: v1.03a 29 July 2003
 * 	Infrastructure - Roby Joehanes, Haipeng Guo, Benjamin Perry, Julie A. Thornton
 *	Modules - Sonal S. Junnarkar
 *  Version 2 - August 2003 - July 2004
 *  	release: v2.03a 08 July 2004
 * 	Infrastructure - Roby Joehanes, Julie A. Thornton
 *	Modules - Siddharth Chandak, Prashanth Boddhireddy, Chris H. Meyer, Charlie L. Thornton, Bart Peinter
 * ---------------------------------------------
 */



/*
 * Created on Mar 12, 2003
 *
 * This file is part of Bayesian Network for Java (BNJ).
 *
 * BNJ is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BNJ is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BNJ in LICENSE.txt file; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package edu.ksu.cis.kdd.ga.operators;

import java.util.HashSet;
import java.util.Iterator;

import edu.ksu.cis.kdd.ga.Chromosome;
import edu.ksu.cis.kdd.ga.GAOp;

/**
 * Generic crossover operator
 * @author Roby Joehanes
 */
public class CrossOverOp extends GAOp {
	protected double crossOverRate = 0.2;

    /**
     * For this generic Crossover operator, we need two chromosomes. 
     */
    public CrossOverOp() {
        super(2);
    }

    protected int getMinChromosomeSize(final Chromosome[] ind) {
        int chromSize = ind[0].getSize();
        // take the shorter of the two
        if (chromSize > ind[1].getSize()) return ind[1].getSize();
        return chromSize;
    }

    /**
     * Randomly choose cross-over points over two individuals ind
     * @param ind
     * @return array of integers denoting the points
     */
    protected int[] getCrossOverPoints(final Chromosome[] ind) {
        HashSet array = new HashSet();
        int chromSize = getMinChromosomeSize(ind);
        int max = (int) Math.floor(random.nextDouble()*chromSize);
        for (int i = 0; i < max; i++) {
            array.add(new Integer((int) Math.floor(random.nextDouble()*chromSize)));
        }
        int length = array.size();
        int[] result = new int[length];
        int idx = 0;
        for (Iterator i = array.iterator(); i.hasNext(); idx++) {
            result[idx] = ((Integer) i.next()).intValue();
        }
        return result;
    }

    /**
     * Generic swap at one point
     * @param ind
     * @param point
     */
    protected void swap(Chromosome[] ind, int point) {
        Object temp = ind[0].get(point);
        ind[0].set(point, ind[1].get(point));
        ind[1].set(point,temp);
    }

    /**
     * Generic swap at several points
     * @param ind
     * @param points
     */
    protected void swap(Chromosome[] ind, int[] points) {
        Object temp;
        int length = points.length;
        for (int i = 0; i < length; i++) {
            temp = ind[0].get(points[i]);
            ind[0].set(i, ind[1].get(points[i]));
            ind[1].set(points[i],temp);
        }
    }

    /**
     * Convenience method to clone the individuals
     * @param ind
     * @return
     */
    protected Chromosome[] clone(Chromosome[] ind) {
        Chromosome[] newInd = new Chromosome[2];
        newInd[0] = (Chromosome) ind[0].clone();
        newInd[1] = (Chromosome) ind[1].clone();
        return newInd;
    }
    /**
     * @return Returns the crossOverRate.
     */
    public double getCrossOverRate() {
        return crossOverRate;
    }

    /**
     * @param crossOverRate The crossOverRate to set.
     */
    public void setCrossOverRate(double crossOverRate) {
        this.crossOverRate = crossOverRate;
    }

    /**
	 * @see edu.ksu.cis.kdd.ga.GAOp#apply(edu.ksu.cis.kdd.ga.Chromosome, edu.ksu.cis.kdd.ga.Chromosome, edu.ksu.cis.kdd.ga.Population)
	 */
	@Override
	public Chromosome[] apply(final Chromosome[] ind) {
        Chromosome[] newInd = clone(ind);
        swap(newInd, getCrossOverPoints(ind));
        return newInd;
	}
}
