package bjut.ai.sem;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import smile.Network;
import smile.learning.DataSet;

import bjut.ai.bn.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.converter;
import bjut.ai.bn.learning.acob.SingleACOB;
import bjut.ai.bn.score.EMDLScore;
import bjut.ai.bn.score.K2;
import edu.ksu.cis.bnj.bbn.BBNDiscreteValue;
import edu.ksu.cis.bnj.bbn.BBNGraph;
import edu.ksu.cis.bnj.bbn.BBNNode;
import edu.ksu.cis.bnj.bbn.BBNPDF;
import edu.ksu.cis.bnj.bbn.inference.InferenceResult;
import edu.ksu.cis.bnj.bbn.inference.approximate.sampling.ForwardSampling;
import edu.ksu.cis.bnj.bbn.inference.elimbel.ElimBel;
import edu.ksu.cis.bnj.bbn.inference.ls.LS;
import edu.ksu.cis.kdd.data.Table;
import edu.ksu.cis.kdd.util.graph.Edge;
import edu.ksu.cis.kdd.util.graph.Node;
public class mytest {
	public static void main(String[] args) {
		long start = System.currentTimeMillis();

		mytest.testElimate();
		
		long end = System.currentTimeMillis();
		mytest.log.close();
		System.out.println("\ntime:" + (end - start) / 1000);
	}
	
	public static void testSampleong() {
		EM em = new EM();
		Network net = new Network();
		// net.readFile("c:\\afterem 3.xdsl");
		net.readFile("c:\\Alarm.xdsl");
		String dspath = "c:\\Alarm1.txt";
		DataSet ds = new DataSet();
		ds.readFile(dspath);
		// ds.matchNetwork(net);
		
		String[] names = ds.getStateNames(0);
		// CommonTools.outArray(names);
		
		
		String[] names2 = net.getOutcomeIds(0);
		// double[] pros = net.getNodeValue("Anaphylaxis");
		double[] p = net.getNodeDefinition(0);
		CommonTools.outArray(names2);
		CommonTools.outArray(p);
		

		 AlarmReader ar = new AlarmReader(dspath, 8000, 37);
		String[][] data = ar.GetGeNIleDataset();
		
		Hashtable<String, Integer> t = new Hashtable<String, Integer>();
		t.put("True", 0);
		t.put("False", 0);
		for (int i = 0; i < 1000; i++) {
			String[] evi = { "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
					"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
					"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
					"*", "*", "*" };
			em.setEvidenceToSNet(net, evi);
			String[] sampleone = em.sampleOne(net, evi);

			int count = t.get(sampleone[26]);
			count++;
			t.put(sampleone[26], count);

		}
		System.out.println(t);
	
	}
	public static void setEviSnet() {
		EM em = new EM();
		Network net = new Network();
		net.readFile("data\\alarm.xdsl");
		String dspath = "c:\\Alarm1.txt";
		AlarmReader ar = new AlarmReader(dspath, 8000, 37);
		String[][] data = ar.GetGeNIleDataset();
		// String[] evi = { "Normal", "Normal", "False", "Low", "Low", "High",
		// "High", "High", "High", "Normal", "Low", "Normal", "Low",
		// "High", "Normal", "Normal", "False", "False", "False", "False",
		// "False", "OneSided", "False", "False", "Normal", "Normal",
		// "High", "False", "High", "False", "High", "Normal", "High",
		// "Low", "Normal", "Normal", "Normal" };
		String[] evi = { "Normal", "Normal", "False", "*", "*", "*", "*",
				"*",
				"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
				"*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*", "*",
				"*", "*", "*", "*", "*" };
		em.setEvidenceToSNet(net, evi);
		double pro = net.probEvidence();
		
		System.out.println(pro);
		// for (int i = 0; i < data.length; i++) {
		// if (!em.setEvidenceToSNet(net, data[i])) {
		// System.err.println("false" + i);
		// CommonTools.outArray(data[i]);
		// }
		// }
		
	}
	public static void testSmileMI(){
		String dspath = "c:\\Alarm.txt";
		AlarmReader ar = new AlarmReader(dspath,
				3000, 37);
		String[][] data = ar.GetGeNIleDataset();
		EM em = new EM();
		String[][] MissData = em.genMissDataSetMCAR(data,
				0.3);
		
		String[][] missnum = converter
				.tranStringDataToNumData(data);
		AlarmReader.copymiss(MissData, missnum);

		em.saveDataset(MissData, "c:\\Missdata.txt");
		Network net = new Network();
		net.readFile("c:\\afterem 2.xdsl");
		DataSet ds = new DataSet();
		ds.readFile("c:\\Alarm.txt");
		String[][] refineddata = em.MISmile(net, missnum, ds, 1);
		AlarmReader.saveDataset(missnum, "c:\\missnum.txt");

		AlarmReader.saveDataset(refineddata, "c:\\refineddata.txt");
	
	}

	public static PrintWriter log = CommonTools.getPrintWriter("c:\\mytest", "log.txt");
	
	public static void testSetSmileEvi() {
		Network net = new Network();
		net.readFile("c:\\Asia.xdsl");
		int[] nodes = net.getAllNodes();
		for (int i = 0; i < nodes.length; i++) {
			String cur = net.getNodeId(i);
			String[] values = net.getOutcomeIds(i);
			 if (!net.isPropagatedEvidence(cur))
				net.setEvidence(cur, values[0]);
		}
		 if (net.isPropagatedEvidence("Tuberculosis"))
			net.setEvidence("Tuberculosis", "Present");
		
		net.updateBeliefs();

		for (int i = 0; i < nodes.length; i++) {
			double[] pro = net.getNodeValue(i);
			CommonTools.outArray(pro);
		}
	}
	public static void testEMMI() {
		try {
			String basedir = "c:\\EMMI2\\";
			EMMI.timelog = CommonTools.getPrintWriter(basedir, "timelog.txt");
			EMMI.emtimelog = CommonTools.getPrintWriter(basedir,
					"emtimelog.txt");
			EMMI.emmilog = CommonTools.getPrintWriter(basedir, "!EMMIlog.txt");
			String data = "c:\\alarm3000.txt";
			
			DataSet ds = new DataSet();
			ds.readFile(data);
			DataSet miss = new DataSet();
			miss.readFile(data);
			EM em = new EM();
			em.genMissDatasetMCAR(miss, 0.1);
			EMMI emmi = new EMMI();
			// emmi.setIterNumer(10);
//			Network net = emmi.goEMMISmile2(miss, basedir, K2.TYPE.ORI, 1);
//			net.writeFile("c:\\EMMI2\\final.xdsl");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void testMISmile() {
		 EM em = new EM();
		Network net = new Network();
		net.readFile("c:\\temp.xdsl");

		AlarmReader ar = new AlarmReader("c:\\temp.txt", 1000, 37);
		String[][] miss = ar.GetDataSet();
		DataSet ds = new DataSet();
		ds.readFile("c:\\alarm1000.txt");
		String[][] refined = em.MISmile(net, miss, ds, 10);

		// CommonTools.outArray(miss);
		CommonTools.outArray(refined);
		AlarmReader.saveDataset(refined, "c:\\refined.txt");
	}
	public static void testCItest()
	{
		String path = "c:\\Alarm1.txt";
		int num = 1000;
		int nodenum = 37;
		AlarmReader ar = new AlarmReader(path,num,nodenum);
		String[][] data = ar.GetGeNIleDataset();
		String[][] numdata = converter.tranStringDataToNumData(data);
		K2 k2 = new K2(numdata);
		//SingleACOB.CIConstrain(k2.getRecord());
	}
	public static void testStandardAlarm()
	{

		BBNGraph g = BBNGraph.load("data\\alarm.xml");

		// Hashtable evidence = new Hashtable<String, String>();
		// evidence.put("VentLung", "Zero");
		// evidence.put("Intubation", "Normal");
		// evidence.put("VentAlv", "Zero");
		LS ls = new LS(g);
		InferenceResult ir = ls.getMarginals();
		
		
		System.out.println(ir);
		
	
	}
	
	public static void testEvidence() {
		
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("VentLung", "Zero");
		evidence.put("Intubation", "Normal");
		evidence.put("VentAlv", "Zero");
		g.setEvidenceNodes(evidence);
		g.saveEvidence("c:\\evidence.txt");

	    edu.ksu.cis.bnj.bbn.datagen.ForwardSampling dg = new edu.ksu.cis.bnj.bbn.datagen.ForwardSampling(
				g);
	    g.clearEvidenceNodes();
		g.setEvidenceNodes(evidence);
		Table tuples = dg.generateData(10);
		
		System.out.println(tuples.getAttributeIndex("VentLung"));
		System.out.println(tuples.getAttributeIndex("Intubation"));
		System.out.println(tuples.getAttributeIndex("VentAlv"));
		LinkedList names = (LinkedList) tuples.getAttributeNames();
		System.out.println(names);
		LinkedList<String> data = (LinkedList<String>) tuples.getTuple(0)
				.getValues();
		System.out.println(data);
	}

	public static void testK2()
	{
//		K2 k2 = new K2();
//		Database db = Database.load("c:\\alarmdata");
//		k2.setData(db);
//		
//		BBNGraph g = k2.getGraph();
//		g.save("c:\\alarmlearned.xml");
//		double score = k2.getNetworkScore();
//		
//		System.out.print(score);
		
	}
	
	public static void testAlarm()
	{

//    	K2.INSTANCE = K2.getK2("alarm_20071019.TXT", 3000, 37);
//        BNGraph g = BNGraph.GetGraphStandAlarm();
//        
//        EM em = new EM();
//        Map<String, Map<String, Double>> theta = em.genThetaSK(g);
//        
////        Set<String> keys = theta.keySet();
////        for(Iterator iter = keys.iterator();iter.hasNext();)
////        {
////        	String key = (String)iter.next();
////        	System.out.print(key+":"+theta.get(key)+"\n");
////        }
//    	BBNGraph bbng = em.TranBNtoBBN(g, theta);
//    	bbng.save("c:\\xalarm.xml");
//
//    	Hashtable evidence = new Hashtable<String, String>();
//		evidence.put("x0", "0");
//		evidence.put("x34", "1");
//		bbng.setEvidenceNodes(evidence);
//		
//		LS ls = new LS(bbng);
//		InferenceResult result = ls.getMarginals();
//		Set<String> names = bbng.getNodeNames();
//		Iterator<String> iter = names.iterator();
//		while(iter.hasNext())
//		{
//			Hashtable t = (Hashtable)result.get(iter.next());
//			System.out.println(t);
//		}
	}
	public static void testSimple()
	{
		BBNGraph g = new BBNGraph();
		g.setName("simple");
		
		BBNNode node1 = new BBNNode(g, "x1");
		BBNNode node2 = new BBNNode(g, "x2");
		BBNNode node3 = new BBNNode(g, "x3");
		
		g.add(node1);
		g.add(node2);
		g.add(node3);
		BBNDiscreteValue v = new BBNDiscreteValue();
		v.add("1");
		v.add("2");
		node1.setValues(v);
		node2.setValues(v);
		node3.setValues(v);

		g.addEdge(node1,node2);
		g.addEdge(node2,node3);
		
		Hashtable cpf1 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf11 = new Hashtable<String,String>();
		Hashtable cpf12 = new Hashtable<String,String>();

		cpf11.put("x1", "1");
		cpf12.put("x1", "2");
		cpf1.put(cpf11, new BBNPDF(0.5));
		cpf1.put(cpf12, new BBNPDF(0.5));
		node1.setCPF(cpf1);
		
		Hashtable cpf2 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf21 = new Hashtable<String, String>();
		Hashtable cpf22 = new Hashtable<String, String>();
		Hashtable cpf23 = new Hashtable<String, String>();
		Hashtable cpf24 = new Hashtable<String, String>();
		
		cpf21.put("x1", "1");
		cpf21.put("x2", "1");
		cpf2.put(cpf21, new BBNPDF(0.67));
	
		cpf22.put("x1", "1");
		cpf22.put("x2", "2");
		cpf2.put(cpf22, new BBNPDF(0.33));
		
		cpf23.put("x2", "1");
		cpf23.put("x1", "2");
		cpf2.put(cpf23, new BBNPDF(0.33));
		
		cpf24.put("x1", "2");

		cpf24.put("x2", "2");
		cpf2.put(cpf24, new BBNPDF(0.67));
		node2.setCPF(cpf2);
		
		Hashtable cpf3 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf31 = new Hashtable<String, String>();
		Hashtable cpf32 = new Hashtable<String, String>();
		Hashtable cpf33 = new Hashtable<String, String>();
		Hashtable cpf34 = new Hashtable<String, String>();

		cpf31.put("x3", "1");
		cpf31.put("x2", "1");
		cpf3.put(cpf31, new BBNPDF(0.67));
		
		cpf32.put("x3", "2");
		cpf32.put("x2", "1");
		cpf3.put(cpf32, new BBNPDF(0.33));
		
		cpf33.put("x3", "1");
		cpf33.put("x2", "2");
		cpf3.put(cpf33, new BBNPDF(0.33));
		
		cpf34.put("x3", "2");
		cpf34.put("x2", "2");
		cpf3.put(cpf34, new BBNPDF(0.67));
		node3.setCPF(cpf3);
		
		LS ls = new LS(g);
	
		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("x1", "1");
		g.setEvidenceNodes(evidence);
//		
		InferenceResult result = ls.getMarginals();
		
		System.out.println(result.get("x2"));
		

//		BBNNode node = (BBNNode)g.getNode("x2");
//		Hashtable t = new Hashtable<String, String>();
//		t.put("x2", 1);
//		t.put("x1", 1);
//		double rr = node.query(t);
//		System.out.print(rr);
	}
	
	public static void testSimpleEM() {
		BBNGraph g = new BBNGraph();
		g.setName("simple");

		BBNNode node1 = new BBNNode(g, "x1");
		BBNNode node2 = new BBNNode(g, "x2");
		BBNNode node3 = new BBNNode(g, "x3");

		g.add(node1);
		g.add(node2);
		g.add(node3);
		BBNDiscreteValue v = new BBNDiscreteValue();
		v.add("1");
		v.add("2");
		node1.setValues(v);
		node2.setValues(v);
		node3.setValues(v);

		g.addEdge(node1, node2);
		g.addEdge(node2, node3);

		Hashtable cpf1 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf11 = new Hashtable<String, String>();
		Hashtable cpf12 = new Hashtable<String, String>();

		cpf11.put("x1", "1");
		cpf12.put("x1", "2");
		cpf1.put(cpf11, new BBNPDF(0.5));
		cpf1.put(cpf12, new BBNPDF(0.5));
		node1.setCPF(cpf1);

		Hashtable cpf2 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf21 = new Hashtable<String, String>();
		Hashtable cpf22 = new Hashtable<String, String>();
		Hashtable cpf23 = new Hashtable<String, String>();
		Hashtable cpf24 = new Hashtable<String, String>();

		cpf21.put("x1", "1");
		cpf21.put("x2", "1");
		cpf2.put(cpf21, new BBNPDF(0.67));

		cpf22.put("x1", "1");
		cpf22.put("x2", "2");
		cpf2.put(cpf22, new BBNPDF(0.33));

		cpf23.put("x2", "1");
		cpf23.put("x1", "2");
		cpf2.put(cpf23, new BBNPDF(0.33));

		cpf24.put("x1", "2");

		cpf24.put("x2", "2");
		cpf2.put(cpf24, new BBNPDF(0.67));
		node2.setCPF(cpf2);

		Hashtable cpf3 = new Hashtable<Hashtable, BBNPDF>();
		Hashtable cpf31 = new Hashtable<String, String>();
		Hashtable cpf32 = new Hashtable<String, String>();
		Hashtable cpf33 = new Hashtable<String, String>();
		Hashtable cpf34 = new Hashtable<String, String>();

		cpf31.put("x3", "1");
		cpf31.put("x2", "1");
		cpf3.put(cpf31, new BBNPDF(0.67));

		cpf32.put("x3", "2");
		cpf32.put("x2", "1");
		cpf3.put(cpf32, new BBNPDF(0.33));

		cpf33.put("x3", "1");
		cpf33.put("x2", "2");
		cpf3.put(cpf33, new BBNPDF(0.33));

		cpf34.put("x3", "2");
		cpf34.put("x2", "2");
		cpf3.put(cpf34, new BBNPDF(0.67));
		node3.setCPF(cpf3);
		
		String[][] missdata = { { "1", "1", "1" }, { "2", "2", "2" },
				{ "1", "?", "1" }, { "2", "?", "2" } };
		
		EM em = new EM();

		// Hashtable AllMijk = em.getAllMijk(g, missdata);
		// System.out.println(AllMijk);
		
		
	}
	
	public static void testGenRandCPF()
	{
		EM em = new EM();
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
//		BBNNode node = (BBNNode)g.getNode("CVP");
//		List names0 = node.getParents();
//		List names = new LinkedList(names0);
//		names.add(node);
//		Hashtable cpfs = new Hashtable<Hashtable, Double>();
//		em.genRandCPFNode(cpfs, names, new Hashtable(),new LinkedList());
//		System.out.print(cpfs);
		
		Hashtable AllTheta = em.genRandCPF(g);
		em.setThetatoGraph(g, AllTheta);
		g.save("c:\\randGraph.xml");
		
		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("VentLung", "Zero");
		evidence.put("Intubation", "Normal");
		evidence.put("VentAlv", "Zero");
		LS ls = new LS(g);
		g.setEvidenceNodes(evidence);
		InferenceResult result = ls.getMarginals();
		System.out.print(result.get("CVP"));
		
	}
	
	
	
	public static void testEV()
	{
		BBNGraph asia = BBNGraph.load("c:\\asia.xml");
//		System.out.println(asia);
		
		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("Tuberculosis","Present");
		evidence.put("Cancer", "Absent");
		asia.setEvidenceNodes(evidence);

		ElimBel eb = new ElimBel(asia);
		InferenceResult result = eb.getMarginals();
		System.out.print(result);
	}

	public static void testAsia()
	{
		BBNGraph asia = BBNGraph.load("c:\\asia.xml");
		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("Tuberculosis","Present");
		evidence.put("Cancer", "Absent");
		asia.setEvidenceNodes(evidence);
		LS ls = new LS(asia);
		InferenceResult result = ls.getMarginals();
		
		System.out.println(result);
	}

	public static void testGetMijk()
	{
		EM em = new EM();
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		AlarmReader ar = new AlarmReader("data\\alarmstring.txt", 100, 37);
		String[][] data = ar.GetDataSet();
		String[][] missData = em.genMissDataSet(data, 0.1);

//		BBNNode node = (BBNNode)g.getNode("Press");
//		Hashtable re = em.getMijk(node, missData);
//		System.out.println(re);
		
		Hashtable t = em.getAllMijk(g, missData);
		Hashtable t2 = em.genRandCPF(g);
		em.setThetatoGraph(g, t2);
		Hashtable t1 = em.calcAllThetaijk(g, t);
		double result = em.calcLikeHood(g, t,t1);
		System.out.println(result);
	}
	public static void testTranBNtoBBN()
	{
		EM em = new EM();
		BNGraph bjutg = BNGraph.GetGraphStandAlarm();
		BBNGraph bnjg = em.TranBNtoBBN(bjutg);
		Hashtable cpfs = em.genRandCPF(bnjg);
		em.setThetatoGraph(bnjg, cpfs);
		 
		bnjg.save("C:\\tran.xml");
		String node = "History";
		System.out.println(bnjg.getNode(node).getParentNames());
	}
	
	public static void testGoEM()
	{
		EM em = new EM();
		em.setSeed(0);
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		AlarmReader ar = new AlarmReader("data\\alarmstring.txt", 3000, 37);
		String[][] data = ar.GetDataSet();
		 String[][] missData = em.genMissDataSetMCAR(data, 0.2);
//		em.saveDataset(missData, "c:\\missdata.txt");
		System.out.println("testGoEM");
		Hashtable cpfs = em.goEM(g, missData, 0.005, 15);
		em.setThetatoGraph(g, cpfs);
		LS ls = new LS(g);
		ls.getMarginals();
		System.out.print("OK");
	}


	public static void testGenRandValueFromDistri()
	{
		EM em = new EM();
		Hashtable dist = new Hashtable<String, Double>();
		dist.put("L", 0.3);
		dist.put("H", 0.5);
		dist.put("M", 0.2);
		Hashtable count = new Hashtable<String, Integer>();
		count.put("L", 0);
		count.put("H", 0);
		count.put("M", 0);

		for(int i = 0; i < 100; i++)
		{
			String value = em.genRandValueFromDistri("x1", dist); 
			Integer temp = (Integer)count.get(value);
			count.put(value, ++temp);
		}
		System.out.print(count);
		
	}
	public static void testMIDataset()
	{
		EM em = new EM();
//		em.setSeed(0);
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		AlarmReader ar = new AlarmReader("c:\\Alarm.txt", 3000, 37);
		String[][] dataset = ar.GetGeNIleDataset();
		String[][] missData = em.genMissDataSetMCAR(dataset, 0.1);
		AlarmReader.saveDataset(missData, "c:\\missdata.txt");
		
		String[][] complete = em.MIDataset(g, missData, 3);
		// String[][] complete = em.genInitData(missData);
		AlarmReader.saveDataset(complete, "c:\\complete.txt");
	}
	
	public static void testGoEMMI()
	{
		String basedir = "c:\\EMMI\\";
		EMMI.timelog = CommonTools.getPrintWriter(basedir, "timelog.txt");
		EMMI.emtimelog = CommonTools.getPrintWriter(basedir, "emtimelog.txt");
		EMMI.emmilog = CommonTools.getPrintWriter(basedir, "!EMMIlog.txt");
		long s = System.currentTimeMillis();
		EM em = new EM();
		AlarmReader ar = new AlarmReader("data\\alarmstring.txt", 3000, 37);
		String[][] data = ar.GetDataSet();
		
		double MissPercent = 0.4;
		String[][] MissData = em.genMissDataSetMCAR(data, MissPercent);
		EMMI.emmilog.println(System.getenv("USERDOMAIN"));
		EMMI.emmilog.println("data:" + data.length + " MissPercent:"
				+ MissPercent);
		em.saveDataset(MissData, "c:\\EMMI\\MissData.txt");
		EMMI emmi = new EMMI();
		// emmi.setIterNumer(10);
//		emmi.setSeed(0);
		BBNGraph g = emmi.goEMMI(MissData,"c:\\EMMI", 0,K2.TYPE.ORI);
		long e = System.currentTimeMillis();
		EMMI.emmilog.println("total time:" + (e - s) / 1000);
		EMMI.emmilog.close();
	}

	// public static void testGoEMMIAll()
	// {
	// int[] datasetnum = {1000,2000,3000};
	// double[] misspercent = {0.1, 0.2,0.3,0.4};
	//		
	// int curdatasetnum = 0;
	// double MissPercent = 0.0;
	// for(int i = 0; i < datasetnum.length; i++)
	// {
	// curdatasetnum = datasetnum[i];
	//
	// for(int j = 0; j < misspercent.length; j++)
	// {
	// MissPercent = misspercent[j];
	//
	// String basedir = "c:\\EMMI\\";
	// basedir +=
	// (Integer.toString(curdatasetnum)+"_"+Double.toString(MissPercent));
	//				
	// EMMI.timelog = CommonTools.getPrintWriter(basedir,
	// "timelog.txt");
	// EMMI.emtimelog = CommonTools.getPrintWriter(basedir,
	// "emtimelog.txt");
	// EMMI.emmilog = CommonTools.getPrintWriter(basedir,
	// "!EMMIlog.txt");
	//				
	// long s = System.currentTimeMillis();
	// EM em = new EM();
	// AlarmReader ar = new AlarmReader("data\\alarmstring.txt", curdatasetnum,
	// 37);
	// String[][] data = ar.GetDataSet();
	//				
	// String[][] MissData = em.genMissDataSetMCAR(data, MissPercent);
	// EMMI.emmilog.println(System.getenv("USERDOMAIN"));
	// EMMI.emmilog.println("data:" + data.length + " MissPercent:"
	// + MissPercent);
	// em.saveDataset(MissData, basedir+"\\Missdata.txt");
	// EMMI emmi = new EMMI();
	// emmi.setIterNumer(10);
	// emmi.setEMIterNum(10);
	// BBNGraph g = emmi.goEMMI(MissData,basedir);
	// long e = System.currentTimeMillis();
	//				
	// EMMI.emmilog.println("total time:" + (e - s) / 1000);
	// EMMI.emtimelog.close();
	// EMMI.timelog.close();
	// EMMI.emmilog.close();
	//				
	// }
	// }
	// }
	
	public static void testElimate(){
		EM em = new EM();

		AlarmReader ar = new AlarmReader("d:\\Alarm.txt", 4000, 37);
		String[][] s = ar.GetDataSet();
		String[][] ss = em.eliminateData(s);
		System.out.println(ss.length);
		
		
	}
	
	public static void testGenMCAR()
	{
		EM em = new EM();
		AlarmReader ar = new AlarmReader("data\\alarmstring.txt", 500, 37);
		String[][] data = ar.GetDataSet();
		
		String[][] MissData = em.genMissDataSetMCAR(data, 0.3);
		int count = 0;
		for(int i = 0; i < MissData.length; i++)
		{
			for(int j = 0; j < MissData[0].length; j++)
			{
				if(MissData[i][j].equals("?"))
					count++;
			}
		}
		double percent = (count/MissData.length*MissData[0].length);
		
		System.out.print("Miss percent:"+percent);

	}
	
	public static void testGoSEM()
	{
		AlarmReader ar = new AlarmReader("c:\\missdata.txt", 1000, 37);
		String[][] missdata = ar.GetDataSet();
		SEM sem = new SEM();
		BBNGraph g = sem.goSEM(missdata,10);
		g.save("c:\\mdlalarm.xml");
		

	}
	
	public static void testEMDLScore()
	{
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		AlarmReader ar = new AlarmReader("c:\\missdata.txt", 500, 37);
		String[][] missdata = ar.GetDataSet();
		EMDLScore emdl = new EMDLScore(g,missdata);
		double score = emdl.calcScore(1, new ArrayList());
		System.out.print(score);
	}
	
	public static void testCompareGraph()
	{
		EM em = new EM();
		BBNGraph g = BBNGraph.load("c:\\emalarm.xml");
		BBNGraph s = em.getStardardAlarm();
		String compare = em.compareGraph(em.getStardardAlarm(), g);
		System.out.print(compare);
		
		Node node1 = s.getNode("LVEDVolume");
		Node node2 = s.getNode("CVP");
		
		Edge e = new Edge(node1,node2);

	}
	public static void testInference()
	{
		BBNGraph g = BBNGraph.load("data\\alarm.xml");

		Hashtable evidence = new Hashtable<String, String>();
		evidence.put("VentLung", "Zero");
		evidence.put("Intubation", "Normal");
		evidence.put("VentAlv", "Zero");
		g.setEvidenceNodes(evidence);
		LS ls = new LS(g);
		System.out.println(ls.getMarginals());
		ForwardSampling fs = new ForwardSampling(g);
		System.out.println(fs.getMarginals());
	}
	public static void testCalcLogLoss()
	{
		PrintWriter log = CommonTools.getPrintWriter("c:\\", "loglos.csv");
		AlarmReader ar = new AlarmReader("c:\\Alarmlogloss.txt", 10000, 37);
		String[][] data = ar.GetGeNIleDataset();
		EM em = new EM();
		// standard
		BBNGraph g = BBNGraph.load("data\\alarm.xml");
		double slogloss = em.calcLogloss(g, data);
		System.out.println("��׼�������ݼ�����");
		System.out.println(slogloss + "," + data.length);

		log.append("��׼��,���ݼ�����\n");
		log.append(slogloss + "," + data.length + "\n");
		log.append("0.0,0.1,0.2,0.3");
		
		String basedir = "C:\\Documents and Settings\\zhanghx\\Desktop\\ʵ��ͼ\\EMMI";
		ArrayList filespath = new ArrayList<String>();
		CommonTools.getFiles(basedir, filespath, "xml");
		Collections.sort(filespath);

		for (int i = 0; i < filespath.size(); i++) {
			String filepath = (String) filespath.get(i);
			File f = new File(filepath);
				g = BBNGraph.load(f.getAbsolutePath());
				double logloss = em.calcLogloss(g, data);
				System.out.println(f.getAbsolutePath() + " " + logloss);
				if (i % 4 == 0) {
				log.append("\n");
			}
				log.append(logloss + ",");
		}
		
		log.close();
	}
	
	public static void calcGenileLogloss()
	{
		//stand   -13.487855026906676
		//-13.489165043407302 10000
		//-13.487874729592612 5w
		//-13.487851574746362 6w

//		Network net = new Network();
//		net.readFile("c:\\Alarm.xdsl");
//		DataSet ds = new DataSet();
//		ds.readFile("c:\\Alarmmiss.txt");
//	    smile.learning.EM sEM = new smile.learning.EM();
//	    sEM.setEqSampleSize(60000);
//	    ds.matchNetwork(net);
//	    sEM.learn(ds, net);
//		net.writeFile("c:\\Alarmem.net");
//		
		bjut.ai.sem.EM em = new bjut.ai.sem.EM();
//		BBNGraph g = em.tranSmilenetToBNJnet(net);
		BBNGraph g = null;
		g = BBNGraph.load("c:\\emalarm 4.xml");
		AlarmReader ar = new AlarmReader("c:\\Alarm.txt",10000,37);
		String[][] data = ar.GetGeNIleDataset();
		double logloss = em.calcLogloss(g, data);
		System.out.println(logloss);
		
		
	}
	
	
	
	
	public static void testGenInitData()
	{
		EM em = new EM();
		AlarmReader ar = new AlarmReader("data\\missdata.txt",1,37);
		String[][] data = ar.GetDataSet();
		String[][] cdata = em.genInitData(data);
		em.saveDataset(cdata, "c:\\cdata.txt");
	}
	public static void testGetAllMijk()
	{
		EM em = new EM();
		AlarmReader ar = new AlarmReader("c:\\genumdata.txt.txt", 10000, 37);
		String[][] data = ar.GetDataSet();
		BBNGraph alarm = BBNGraph.load("data\\alarm.xml");
		Hashtable AllMijk = em.getAllMijk(alarm, data);
		// System.out.println(AllMijk);
		Set names = AllMijk.keySet();
		Iterator iter = names.iterator();
		while (iter.hasNext()) {
			String curkey = (String) iter.next();
			Hashtable curval = (Hashtable) AllMijk.get(curkey);
			
			Set names2 = curval.keySet();
			Iterator iter2 = names2.iterator();
			while (iter2.hasNext()) {
				Hashtable curkey2 = (Hashtable) iter2.next();
				double curvalue2 = (Double) curval.get(curkey2);
					System.out.print(curvalue2 + ",");
			}
		}
	}
	public static void testCalcAllTheta() {
		AlarmReader ar = new AlarmReader("data\\alarmstring.txt", 1000, 37);
		String[][] data = ar.GetDataSet();
		EM em = new EM();
		BBNGraph alarm = BBNGraph.load("data\\alarm.xml");
		Hashtable AllMijk = em.getAllMijk(alarm, data);
		Hashtable AllTheta = em.calcAllThetaijk(alarm, AllMijk);
		Set names = AllTheta.keySet();
		Iterator iter = names.iterator();
		while (iter.hasNext()) {
			String curkey = (String) iter.next();
			Hashtable curval = (Hashtable) AllTheta.get(curkey);

			Set names2 = curval.keySet();
			Iterator iter2 = names2.iterator();
			System.out.print(curkey + " ");
			while (iter2.hasNext()) {
				Hashtable curkey2 = (Hashtable) iter2.next();
				BBNPDF curvalue2 = (BBNPDF) curval.get(curkey2);
				System.out.print(curvalue2.getValue() + ",");
			}
			System.out.println();
		}
		
	}

}

