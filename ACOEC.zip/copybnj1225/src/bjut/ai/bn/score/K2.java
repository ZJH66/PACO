//package bjut.ai.bn.score;
//
///**
// * <p>Title: K2</p>
// *
// * <p>Description: ����K2����</p>
// *
// * <p>Copyright: Copyright (c) 2007</p>
// *
// * <p>Company: </p>
// *
// * @author not attributable
// * @version 1.0
// */
//import java.io.File;
//import java.util.*;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Set;
//import java.util.TreeSet;
//
//import bjut.ai.bn.AlarmReader;
//import bjut.ai.bn.BNGraph;
//import bjut.ai.bn.CommonTools;
//
//public class K2 extends Score
//{
//	// ����Ϣ
//	public static double maxMI;
//	public static double minMI;
//	public static double[][] Inf;
//	public static int[][] ChiSquare;
//	// record ʵ������ indexs Ҫ��ѯ�Ľڵ����飬���ز�ѯ���ΪHashMap
//	public static PrintWriter out;
//	public static int VEXNUM = 37; // alarm 37, insurance 27,HailFinder 56
//									// ,child 20 ,barley 48
//	// public static final K2 INSTANCE = new K2("alarm_20071019.TXT", 3000,
//	// K2.VEXNUM);
//	public static K2 INSTANCE = null;
//	// public static final K2 INSTANCE = new K2("xuns.txt", 2000, K2.VEXNUM);
//	// public static final K2 INSTANCE = new K2("insurance_s10000.txt", 1000,
//	// K2.VEXNUM);
//	// public static final K2 INSTANCE = new K2("HailFinder_s10000.txt", 5000,
//	// K2.VEXNUM);
//	// public static final K2 INSTANCE = new K2("child_10000.txt", 3000,
//	// K2.VEXNUM);
//	// public static final K2 INSTANCE = new K2("barley_10000.txt", 3000,
//	// K2.VEXNUM);
//	// �������
//	public static int cacheCount = 0;// ����ĸ���
//	public static int count = 0;// ���ü������
//	public static int actualCalcCount = 0;
//
//	// public static TreeSet[] NodeInfo;
//
//	public static enum TYPE {
//		ORI, CI, CInew, HF, OP, AIO, SA
//	};
//
//	private String[][] Records;
//	private HashMap<String, Double> hm; // �м����
//	public HashMap<String, Double> cacheResult;
//	private int ri;
//
//	public static K2 getK2(String dir, int DatasetNum, int VexNum) {
//		K2.INSTANCE = new K2(dir, DatasetNum, VexNum);
//		K2.VEXNUM = VexNum;
//
//		return K2.INSTANCE;
//	}
//
//	public static K2 getK2(String[][] data, int VexNum) {
//		K2.INSTANCE = new K2(data);
//		K2.VEXNUM = VexNum;
//		return K2.INSTANCE;
//	}
//
//
//	public K2() {
//
//	}
//
//	public K2(String fileName, int size, int nodeNums) {
//		AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
//		this.Records = ar.GetDataSet();
//		// this.NodeInfo = ar.getColumnValue();
//		this.cacheResult = new HashMap<String, Double>();
//	}
//
//	public K2(String[][] data) {
//		this.Records = data;
//		this.cacheResult = new HashMap<String, Double>();
//		AlarmReader ar = new AlarmReader();
//		// this.NodeInfo = ar.getColumnValue(this.Records);
//	}
//
//	public void setRecord(String[][] data) {
//		this.Records = data;
//		AlarmReader ar = new AlarmReader();
//		// this.NodeInfo = ar.getColumnValue(this.Records);
//	}
//
//	public String[][] getRecord() {
//		return this.Records;
//	}
//
//	public void clearCache() {
//		System.out.println("�������");
//		K2.count = 0;
//		K2.cacheCount = 0;
//		K2.actualCalcCount = 0;
//		this.cacheResult = new HashMap<String, Double>();
//	}
//
//	/**
//	 * ����K2���ֺ��� calcK2(0,{1,2,3})û�л���
//	 * 
//	 * @param index
//	 *            int ��ǰ�ڵ�
//	 * @param parent
//	 *            int[] index�ĸ�ĸ�ڵ� �밴��Ȼ˳������
//	 * @return double �������ֺ���ֵ
//	 */
//	public double calcK2(int index, ArrayList<Integer> parent1) {
//		int[] parent = new int[parent1.size()];
//		int temp = 0;
//		while (temp < parent1.size()) {
//			parent[temp] = parent1.get(temp);
//			temp++;
//		}
//		// Arrays.sort(parent);
//		// ȡ�ò�ѯ���
//		int[] temp_parent = new int[parent.length + 1];
//		System.arraycopy(parent, 0, temp_parent, 1, parent.length);
//		temp_parent[0] = index;
//		// Arrays.sort(temp_parent);
//		// ri = NodeInfo[index].size();
//		ri = AlarmReader.AlarmNodeDef[index];
//		// ����ڶ�����
//		hm = K2.getCount(this.Records, temp_parent);
//		double ijk_result = this.calcPart2(hm);
//		// System.out.println("�ڶ�����=" + ijk_result);
//
//		// �����һ����
//		hm = this.getCount(Records, parent); // ȡ��Nij
//		double ij_result = this.calcPart1(hm);
//		// System.out.println(Arrays.asList(hm));
//		// System.out.println("��һ����=" + ij_result);
//		double result = ij_result + ijk_result;
//		return result;
//	}
//
//	/**
//	 * �����
//	 * 
//	 * @param index
//	 *            int
//	 * @param parent
//	 *            ArrayList
//	 * @return double
//	 * 
//	 *         ԭ��calcK2Cache
//	 */
//	public double calcK2Cache(int index, ArrayList<Integer> parent) {
//		double result = 0.0;
//		int[] indexArray = new int[parent.size() + 1];
//		for (int i = 0; i < parent.size(); i++) {
//			indexArray[i + 1] = parent.get(i);
//		}
//		Arrays.sort(indexArray);
//		indexArray[0] = index;
//		String indexString = this.convertToString(indexArray);
//		if (this.cacheResult.containsKey(indexString)) {
//			result = this.cacheResult.get(indexString);
//			K2.cacheCount++;
//		} else {
//			result = this.calcK2Tool(index, indexArray);
//			this.cacheResult.put(indexString, result);
//		}
//		return result;
//	}
//
//	/**
//	 * 
//	 * @param index
//	 *            int
//	 * @param al
//	 *            ArrayList
//	 * @return double
//	 */
//	private double calcK2Brutal(int index, ArrayList<Integer> al) {
//
//		// ȡ�ó�ʼ����
//		int qi = 1;
//		// int ri = NodeInfo[index].size();
//		int ri = AlarmReader.AlarmNodeDef[index];
//		double result = 0;
//
//		// ȡ�ò�ѯ����
//		int[] allNodes = new int[al.size() + 1];
//		for (int k = 0; k < al.size(); k++) {
//			allNodes[k + 1] = al.get(k);
//		}
//		allNodes[0] = index;
//		// ȡ�ò�ѯ���
//		int[] countResult = K2.getCountBrutal(this.Records, allNodes);
//		for (int count = 0; count < al.size(); count++) {
//			qi = qi * AlarmReader.AlarmNodeDef[index];
//		}
//		// ��ʼ����
//		int step = qi;
//		for (int i = 0; i < qi; i++) {
//			int Nij = 0;
//			int Nijk = 0;
//			// ����ڶ�����
//			double result2 = 0;
//			int point = 0;
//			for (int j = 0; j < ri; j++) {
//				Nijk = countResult[i + point];
//				result2 = result2 + K2.calcLog(Nijk);
//				Nij = Nij + Nijk;
//				point = point + step;
//			}
//			// �����һ����
//			double temp1 = K2.calcLog(ri - 1);
//			double temp2 = K2.calcLog(Nij + ri - 1);
//			double result1 = temp1 - temp2;
//			result = result + result1 + result2;
//		}
//
//		return result;
//	}
//
//	/**
//	 * ������Ϊ�˷������mdl ԭ��calcK2BrutalCache ����k2��ѡ����
//	 * 
//	 * @param index
//	 *            int
//	 * @param parent
//	 *            ArrayList
//	 * @return double
//	 */
//	public double calcK2BrutalCache(int index, ArrayList<Integer> parent) {
//		K2.count++;
//		double result = 0.0;
//		int[] indexArray = new int[parent.size() + 1];
//		for (int i = 0; i < parent.size(); i++) {
//			indexArray[i + 1] = parent.get(i);
//		}
//		Arrays.sort(indexArray);
//		indexArray[0] = index;
//
//		String indexString = this.convertToString(indexArray);
//		if (this.cacheResult.containsKey(indexString)) {
//			result = this.cacheResult.get(indexString);
//			K2.cacheCount++;
//		} else {
//			result = this.calcK2Brutal(index, parent);
//			this.cacheResult.put(indexString, result);
//			K2.actualCalcCount++;
//		}
//		return result;
//
//	}
//
//	/**
//	 * ת��int[]Ϊ�����ַ���
//	 * 
//	 * @param array
//	 *            int[]
//	 * @return String
//	 */
//	private String convertToString(int[] array) {
//		StringBuilder sb = new StringBuilder();
//		for (int k : array) {
//			sb.append(k);
//			sb.append(",");
//		}
//		return sb.toString();
//	}
//
//	public static PrintWriter getPrinWriter(String filename) throws IOException {
//		File dir = new File("c:" + File.separator + "BayesianLog_Alarm_mdl");
//		dir.mkdir();
//		File file = new File(dir, filename + ".csv");
//		return new PrintWriter(new FileWriter(file, false));
//	}
//
//	private String convertToString(ArrayList<Integer> al) {
//		StringBuilder sb = new StringBuilder();
//		for (int i = 0, size = al.size(); i < size; i++) {
//			sb.append(al.get(i));
//			sb.append(",");
//		}
//		return sb.toString();
//	}
//
//	private double calcPart1(HashMap h1) // ij
//	{
//		// System.out.println("�����һ����ʱ��getCount��ϣ��\n" + h1);
//		double ij_result = 0;
//		Collection c = h1.values();
//		Iterator it = c.iterator();
//		while (it.hasNext()) {
//			int Nij = (Integer) it.next();
//			double temp1 = this.calcLog(ri - 1);
//			double temp2 = this.calcLog(Nij + ri - 1);
//			double temp3 = temp1 - temp2;
//			ij_result = ij_result + temp3;
//		}
//		c = null;
//		it = null;
//		return ij_result;
//	}
//
//	private double calcPart2(HashMap h2) // ijk
//	{
//		// System.out.println("����ڶ�����ʱ��getCount��ϣ��\n" + h2);
//
//		double ijk_result = 0;
//		Collection c = h2.values();
//		Iterator it = c.iterator();
//		while (it.hasNext()) {
//			int temp_k = (Integer) it.next();
//			double temp_result = this.calcLog(temp_k);
//			ijk_result = ijk_result + temp_result;
//		}
//		c = null;
//		it = null;
//		return ijk_result;
//	}
//
//	/**
//	 * ����log(n!)
//	 * 
//	 * @param n
//	 *            int
//	 * @return double
//	 */
//	private static double calcLog(int n) {
//		double result = 0;
//		for (int i = 1; i <= n; i++) {
//			result = result + java.lang.Math.log10(i);
//		}
//		return result;
//	}
//
//	/**
//	 * log2
//	 * 
//	 * @param value
//	 *            double
//	 * @return double
//	 */
//	public static double log2(double value) {
//		return Math.log(value) / Math.log(2);
//
//	}
//
//	/**
//	 * �ڲ�ʹ��
//	 * 
//	 * @param index
//	 *            int
//	 * @param parentIJK
//	 *            int[]
//	 * @return double
//	 */
//	private double calcK2Tool(int index, int[] parentIJK) {
//		int[] parent = new int[parentIJK.length - 1];
//		System.arraycopy(parentIJK, 1, parent, 0, parent.length);
//
//		ri = AlarmReader.AlarmNodeDef[index];
//		// ����ڶ�����
//		hm = K2.getCount(this.Records, parentIJK);
//		double ijk_result = this.calcPart2(hm);
//		// System.out.println("�ڶ�����=" + ijk_result);
//
//		// �����һ����
//		hm = this.getCount(Records, parent); // ȡ��Nij
//		double ij_result = this.calcPart1(hm);
//		// System.out.println("��һ����=" + ij_result);
//		double result = ij_result + ijk_result;
//		return result;
//
//	}
//
//	/**
//	 * ������ѯ���У���ѯ������ϳ��ֵĴ���
//	 * 
//	 * @param record
//	 *            String[][] ���������
//	 * @param indexs
//	 *            int[] Ҫ��ѯ�Ľڵ�����
//	 * @return HashMap ��ѯ���
//	 */
//	private static HashMap getCount(String[][] record, int[] indexs) {
//		HashMap hm = new HashMap();
//		StringBuilder sb;
//		Object tempcount;
//		for (int i = 0; i < record.length; i++) {
//			sb = new StringBuilder();
//			for (int j = 0; j < indexs.length; j++) {
//
//				sb.append(record[i][indexs[j]]);
//				sb.append(";");
//			}
//			String temp = sb.toString();
//			int count = 0;
//			if ((tempcount = hm.get(temp)) != null) {
//				count = (Integer) tempcount;
//			}
//			hm.put(temp, ++count);
//		}
//		// System.out.println("��ѯ�ڵ�");
//		// for (int k : indexs)
//		// System.out.print(k + ",");
//		// System.out.println("");
//		// System.out.println(hm);
//		return hm;
//	}
//
//	/**
//	 * indexs ��ѯ�Ľڵ�����飬�������� ��������
//	 * 
//	 * @param record
//	 *            String[][]
//	 * @param indexs
//	 *            int[]
//	 * @return int[]
//	 */
//	public static int[] getCountBrutal(String[][] record, int[] indexs) {
//		// ��ʼ���������
//		int resultLength = 1;
//		for (int i = 0; i < indexs.length; i++) {
//		// int size = NodeInfo[indexs[i]].size();
//			int size = AlarmReader.AlarmNodeDef[indexs[i]];
//			resultLength = resultLength * size;
//		}
//		// System.out.println("\n��ѯ���鳤��"+resultLength);
//		int[] result = new int[resultLength];
//		for (int j = 0; j < record.length; j++) {
//			int[] temp = new int[indexs.length];
//			for (int k = 0; k < indexs.length; k++) {
//				temp[k] = Integer.parseInt(record[j][indexs[k]]);
//			}
//			int index = K2.calcStringToIndex(temp, indexs);
//			// System.out.println("����ֵ"+index);
//			// for(int c : temp)
//			// System.out.print(c+",");
//			result[index]++;
//		}
//		// for (int i : result)
//		// {
//		// if(i !=0)
//		// System.out.print(i + ",");
//		//
//		// }
//		return result;
//	}
//
//	/**
//	 * 
//	 * @param array
//	 *            int[]
//	 * @return int
//	 */
//	private static int calcStringToIndex(int[] array, int[] indexs) {
//		int index = 0;
//		for (int i = 0; i < array.length; i++) {
//			int temp = 1;
//			for (int j = i + 1; j < array.length; j++) {
//			// temp = temp * NodeInfo[indexs[j]].size();
//				temp = temp * AlarmReader.AlarmNodeDef[indexs[j]];
//			}
//			index = index + array[i] * temp;
//		}
//
//		return index;
//	}
//
//	/**
//	 * for test only
//	 */
//
//	public void testspeed() {
//		double[][] temp1 = new double[37][37];
//		ArrayList<Integer> anodelist = null; // ��ʱ
//		System.out.println("��ʼ��������Ϣ����");
//
//		long start = System.currentTimeMillis();
//		for (int i = 0; i < K2.VEXNUM; i++)
//			for (int j = 0; j < K2.VEXNUM; j++) {
//				if (i != j) {
//					anodelist = new ArrayList<Integer>();
//					anodelist.add(j);
//					temp1[i][j] = K2.INSTANCE.calcK2Brutal(i, anodelist)
//							- K2.INSTANCE.calcK2Brutal(i,
//									new java.util.ArrayList());
//				} else
//					temp1[i][j] = Double.NEGATIVE_INFINITY;
//			}
//		long end = System.currentTimeMillis();
//		CommonTools.outArray(temp1);
//		System.out.format("���,����[%d]����\n", end - start);
//	}
//
//	
//	// �����Բ��Բ���
//	/**
//	 * ���㻥��Ϣ
//	 * 
//	 */
//	public static void calcInf() {
//		System.out.println("���㻥��Ϣ");
//		K2.Inf = new double[K2.VEXNUM][K2.VEXNUM];
//		int row = 0;
//		int col = 0;
//		for (row = 0; row < K2.VEXNUM; row++) {
//			for (col = 0; col < K2.VEXNUM; col++) {
//				// ����������
//				if (row < col) {
//					//
//					Inf[row][col] = K2.calcInd(row, col);
//				} else {
//					Inf[row][col] = Inf[col][row];
//				}
//			}
//		}
//		K2.maxMI = K2.getMaxMI();
//		K2.minMI = K2.getMinMI();
//	}
//
//	/**
//	 * 
//	 * @param n
//	 *            int
//	 * @return double
//	 */
//	private static double getChiSquare(int n) {
//		// n ���ɶ� ����鿨������
//		// �� = 0.005
//
//		 double[] chi = { 7.879, 10.597, 12.838, 14.860, 16.750, 18.548, 20.278,
//				21.955, 23.589, 25.188, 26.757, 28.299, 29.819, 31.319, 32.801,
//				34.267, 35.718, 37.156, 38.582 };
//
//		// �� = 0.01;
//		// double[] chi =
//		// {
//		// 6.635, 9.210, 11.345, 13.277, 15.086, 16.812, 18.475, 20.090, 21.666,
//		// 23.209,
//		// 24.725,
//		// 26.217, 27.688, 29.141, 30.578, 32.000, 33.409, 34.805, 36.191,
//		// 37.566, 38.932,
//		// 40.289, 41.638, 42.980, 44.314, 45.642};
//
//		// �� = 0.05;
//		// double[] chi =
//		// {
//		// 3.841,5.991,7.815,9.488,11.071,12.592,14.067,15.507,16.919,18.307,
//		// 19.675,21.026,
//		//22.362,23.685,24.996,26.296,27.587,28.869,30.144,31.410,32.671,33.924,
//		// 35.172,36.415,37.652
//		// };
//		//
//		// �� = 0.1;
//		// double[] chi =
//		// {
//		//2.706,4.605,6.251,7.779,9.236,10.645,12.017,13.362,14.684,15.987,17.275
//		// ,
//		// 18.549,19.812,21.064,22.307,23.542,24.769,25.989,27.204,28.412
//		// };
//
//		// �� = 0.995;
//		// double[] chi =
//		// {
//		// 0, 0.010, 0.072, 0.207, 0.412, 0.676, 0.989, 1.344, 1.735, 2.156,
//		// 2.603, 3.074, 3.565,
//		// 4.075, 4.601, 5.142, 5.697, 6.265, 6.844, 7.434, 8.034
//		// };
//		//
//
//		// �� = 0.95;
//		// double[] chi =
//		// {
//		//0.004,0.103,0.352,0.711,1.145,1.635,2.167,2.733,3.325,3.940,4.575,5.226
//		// ,5.892,
//		// 6.571,7.261,7.962,8.672,9.390,10.117,10.851
//		// };
//
//		// �� = 0.75;
//		// double[] chi = { 0.102, 0.575, 1.213, 1.923, 2.675, 3.455, 4.255,
//		// 5.071, 5.899, 6.737, 7.584, 8.438, 9.299, 10.165, 11.037,
//		// 11.912, 12.792, 13.675, 14.562, 15.452 };
//		//
//
//		return chi[n - 1];
//
//	}
//
//	/**
//	 * �����Բ���
//	 */
//	public static void CITest() {
//		System.out.println("����X������");
//		K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
//		int arcToRemove = 0;
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			for (int j = 0; j < K2.VEXNUM; j++) {
//				if (i == j) {
//					continue;
//				}
//				double t = 2 * K2.INSTANCE.Records.length * K2.Inf[i][j];
//				int DegOfFreeDom = (AlarmReader.AlarmNodeDef[i] - 1)
//						* (AlarmReader.AlarmNodeDef[j] - 1);
//				double valueChi = K2.getChiSquare(DegOfFreeDom);
//				// valueChi = 0.17;
//				if (t > valueChi) {
//					K2.ChiSquare[i][j] = 1;
//				} else {
//					arcToRemove++;
//
//				}
//			}
//		}
//		System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
//		// BNGraph gstand= BNGraph.GetGraphStandInsurance();
//		BNGraph gstand = BNGraph.GetGraphStandAlarm();
//		// System.err.print(gstand);
//		int[][] arcarr = gstand.GetArcArray();
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			for (int j = 0; j < K2.VEXNUM; j++) {
//				if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
//					int tempn = (AlarmReader.AlarmNodeDef[i] - 1)
//							* (AlarmReader.AlarmNodeDef[j] - 1);
//					System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
//							* K2.INSTANCE.Records.length * K2.Inf[i][j]
//							+ "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
//					// K2.Inf[i][j]
//							);
//				}
//			}
//		}
//
//	}
//
//	public static void CITestByValue(double a) {
//		System.out.println("����X�����飬by value");
//		K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
//		int arcToRemove = 0;
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			for (int j = 0; j < K2.VEXNUM; j++) {
//				if (i == j) {
//					continue;
//				}
//				double t = 2 * K2.INSTANCE.Records.length * K2.Inf[i][j];
//				if (t > a) {
//					K2.ChiSquare[i][j] = 1;
//				} else {
//					arcToRemove++;
//
//				}
//
//			}
//		}
//
//		System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
//		// BNGraph gstand= BNGraph.GetGraphStandInsurance();
//		BNGraph gstand = BNGraph.GetGraphStandAlarm();
//		// System.err.print(gstand);
//		int[][] arcarr = gstand.GetArcArray();
//		for (int i = 0; i < K2.VEXNUM; i++) {
//			for (int j = 0; j < K2.VEXNUM; j++) {
//				if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
//					int tempn = (AlarmReader.AlarmNodeDef[i] - 1)
//							* (AlarmReader.AlarmNodeDef[j] - 1);
//					System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
//							* K2.INSTANCE.Records.length * K2.Inf[i][j]
//							+ "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
//							+ "base:" + a
//					// K2.Inf[i][j]
//							);
//				}
//			}
//		}
//
//	}
//
//	/**
//	 * ȡ�����Ļ���Ϣֵ
//	 * 
//	 * @return double
//	 */
//
//	public static double getMaxMI() {
//		double infMax = 0;
//		double[][] inf = K2.Inf;
//		for (int i = 0; i < inf.length; i++) {
//			for (int j = 0; j < inf.length; j++) {
//				// System.out.print(inf[i][j] + " ");
//				if (inf[i][j] > infMax) {
//					infMax = inf[i][j];
//				}
//			}
//			// System.out.print("\r\n ");
//		}
//		// System.out.print("\r\n�����Ϣ��" + infMax);
//		return infMax;
//
//	}
//
//	public static double getMinMI() {
//		double infMin = Double.POSITIVE_INFINITY;
//		double[][] inf = K2.Inf;
//		for (int i = 0; i < inf.length; i++) {
//			for (int j = 0; j < inf.length; j++) {
//				if ((inf[i][j] < infMin) && inf[i][j] != 0) {
//					infMin = inf[i][j];
//				}
//			}
//		}
//		return infMin;
//
//	}
//
//	public static double calcInd(int x, int y) {
//		double result = 0.0;
//		int[] query = { x, y };
//		int[] queryResult = K2.getCountBrutal(K2.INSTANCE.Records, query);
//		double[][] arrayProb = constructProbArray(x, y, queryResult);
//		double[] px = constructProbX(arrayProb);// ����
//		double[] py = constructProbY(arrayProb);// ����
//
//		for (int i = 0; i < arrayProb.length; i++) {
//			for (int j = 0; j < arrayProb[0].length; j++) {
//				if (arrayProb[i][j] != 0.0) {
//					double temp = Math.log10(arrayProb[i][j] / px[j] / py[i]);
//					temp *= arrayProb[i][j];
//					result += temp;
//				}
//			}
//		}
//		return result;
//	}
//
//	/**
//	 * ������ʾ���
//	 * 
//	 * @param x
//	 *            int
//	 * @param y
//	 *            int
//	 * @param result
//	 *            int[]
//	 * @return double[][]
//	 */
//	private static double[][] constructProbArray(int x, int y, int[] queryResult) {
//		int count = 0;
//		int jIndex = AlarmReader.AlarmNodeDef[x];
//		int iIndex = AlarmReader.AlarmNodeDef[y];
//		double num = (double) K2.INSTANCE.Records.length;
//		double[][] arrayProb = new double[iIndex][jIndex];
//		for (int j = 0; j < jIndex; j++) {
//			for (int i = 0; i < iIndex; i++) {
//				arrayProb[i][j] = queryResult[count++] / num;
//			}
//		}
//		return arrayProb;
//	}
//
//	private static double[] constructProbX(double[][] arrayProb) {
//		double[] px = new double[arrayProb[0].length];
//		for (int j = 0; j < arrayProb[0].length; j++) {
//			for (int i = 0; i < arrayProb.length; i++) {
//				px[j] += arrayProb[i][j];
//			}
//		}
//		return px;
//	}
//
//	private static double[] constructProbY(double[][] arrayProb) {
//		double[] py = new double[arrayProb.length];
//		for (int i = 0; i < arrayProb.length; i++) {
//			for (int j = 0; j < arrayProb[0].length; j++) {
//				py[i] += arrayProb[i][j];
//			}
//		}
//		return py;
//	}
//
//	/**
//	 * ע��
//	 * 
//	 * @param ori
//	 *            double
//	 * @return double
//	 */
//	// public static double getMIRadio(int i, int j)
//	// {
//	// double mother = calcSquarSum();
//	// System.out.println("��ĸ"+mother+"���ӣ�"+Inf[i][j]);
//	// double sum = Inf[i][j]/mother;
//	// return sum;
//	// }
//	public static double getRefect(double ori) {
//		return (ori - K2.minMI) / (K2.maxMI - K2.minMI);
//	}
//
//
//	public static BNGraph[] b = new BNGraph[2];
//
//	private double CalcMDLPart1(int index, ArrayList parent) {
//		double d = 0;
//		d = (K2.log2(this.Records.length) * 0.9) / 2;
//		// d = 5.85;
//		// d = Math.ceil(d);
//		int vi = AlarmReader.AlarmNodeDef[index];
//		double part1 = parent.size() * K2.log2(K2.VEXNUM);
//		// double part1 = parent.size() * K2.log2( this.Records.length );
//		// if(parent.size() > 0)
//		// {
//		// part1 = Math.pow(2,parent.size()) * K2.log2( K2.VEXNUM );
//		// }
//		double part2 = 0;
//		Iterator it = parent.iterator();
//		if (parent.size() > 0) {
//			part2 = 1.0;
//			while (it.hasNext()) {
//				int ParentNode = (Integer) it.next();
//				int vj = AlarmReader.AlarmNodeDef[ParentNode];
//				part2 *= (vj);
//			}
//		}
//
//		return d * vi * part2;
//		// return part1 + d *(vi-1) * part2;
//	}
//
//	private double CalcMDLPart2(int index, ArrayList<Integer> parent) {
//		// ȡ�ó�ʼ����
//		int qi = 1;
//		// int ri = NodeInfo[index].size();
//		double result2 = 0;
//
//		// ȡ�ò�ѯ����
//		int[] indexArray = new int[parent.size() + 1];
//		for (int i = 0; i < parent.size(); i++) {
//			indexArray[i + 1] = parent.get(i);
//		}
//		Arrays.sort(indexArray);
//		indexArray[0] = index;
//		// ȡ�ò�ѯ���
//		int[] countResult = K2.getCountBrutal(this.Records, indexArray);
//
//		// for(int i = 0; i < countResult.length; i++)
//		// System.out.print(countResult[i]+" ");
//		// System.out.println();
//
//		for (int count = 0; count < parent.size(); count++) {
//			qi = qi * AlarmReader.AlarmNodeDef[parent.get(count)];
//		}
//		double[] NijkArray = new double[qi];
//		// ���Nij
//		for (int i = 0; i < NijkArray.length; i++) {
//			int step = 0;
//			for (int j = 0; j < AlarmReader.AlarmNodeDef[index]; j++) {
//				NijkArray[i] += countResult[i + step];
//				step += qi;
//			}
//		}
//		double[] NijArray = new double[AlarmReader.AlarmNodeDef[index] * qi];
//		int pos1 = 0;
//		int pos2 = 0;
//		for (int i = 0; i < AlarmReader.AlarmNodeDef[index]; i++) {
//			System.arraycopy(NijkArray, pos1, NijArray, pos2, NijkArray.length);
//			pos2 += qi;
//		}
//		// System.out.println(countResult.length);
//		for (int i = 0; i < countResult.length; i++) {
//			if (countResult[i] != 0) {
//				double para = NijArray[i] / countResult[i];
//				// System.out.println(para);
//				double TempLog = K2.log2(para);
//				double TempResult = countResult[i] * TempLog;
//				// System.out.println(TempResult);
//				result2 += TempResult;
//			}
//			// System.out.println(result2);
//		}
//		return result2;
//	}
//
//	/**
//	 * ����MDL���֣�Ӧ�������ѯ��
//	 * 
//	 * @param index
//	 *            int
//	 * @param parent
//	 *            ArrayList
//	 * @return double
//	 */
//	public double calcMDLUseArray(int index, ArrayList<Integer> parent) {
//		double part1 = this.CalcMDLPart1(index, parent);
//		double part2 = this.CalcMDLPart2(index, parent);
//		double result = -(part2 + part1);
//		// System.out.println(" " +part1+" , " + part2 + " = " + result);
//		// System.out.println( part2 );
//		return result;
//	}
//
//	// PrintWriter pw = CommonTools.getPrintWriter("c:\\cache","cache.log");
//
//	public double calcMDLuseHMCache(int index, ArrayList<Integer> parent) {
//		K2.count++;
//		double result = 0.0;
//		int[] indexArray = new int[parent.size() + 1];
//		for (int i = 0; i < parent.size(); i++) {
//			indexArray[i + 1] = parent.get(i);
//		}
//		Arrays.sort(indexArray);
//		indexArray[0] = index;
//		String indexString = this.convertToString(indexArray);
//		if (this.cacheResult.containsKey(indexString)) {
//			result = this.cacheResult.get(indexString);
//			K2.cacheCount++;
//		} else {
//			result = this.calcMDLuseHM(index, parent);
//			this.cacheResult.put(indexString, result);
//			K2.actualCalcCount++;
//		}
//		return result;
//
//	}
//
//	public double calcMDLUseArrayCache(int index, ArrayList<Integer> parent) {
//
//		K2.count++;
//		double result = 0.0;
//		int[] indexArray = new int[parent.size() + 1];
//		for (int i = 0; i < parent.size(); i++) {
//			indexArray[i + 1] = parent.get(i);
//		}
//		Arrays.sort(indexArray);
//		indexArray[0] = index;
//		String indexString = this.convertToString(indexArray);
//		if (this.cacheResult.containsKey(indexString)) {
//			result = this.cacheResult.get(indexString);
//			// pw.println("����"+index+","+parent+","+result+","+indexString);
//			K2.cacheCount++;
//		} else {
//			result = this.calcMDLUseArray(index, parent);
//			this.cacheResult.put(indexString, result);
//			// pw.println("����"+index+","+parent+","+result+","+indexString);
//
//			K2.actualCalcCount++;
//		}
//		// pw.flush();
//		return result;
//
//	}
//
//	/**
//	 * ����mdlֵ����HM calcK2BrutalCache calcMDLuseHM
//	 * 
//	 * @param index
//	 *            int
//	 * @param parent
//	 *            ArrayList
//	 * @return double
//	 */
//	public double calcMDLuseHM(int index, ArrayList<Integer> parent) {
//		double result = 0.0;
//		double part1 = 0;// ��һ���ֽ��
//		double d = 0;
//
//		d = (K2.log2(this.Records.length) * 0.9) / 2;
//
//		if (parent.size() > 0) {
//			part1 = 1;
//			for (int i = 0; i < parent.size(); i++) {
//				int node = parent.get(i);
//				part1 *= AlarmReader.AlarmNodeDef[node];
//			}
//		}
//		// part1 *= d * (NodeInfo[index].size()-1);
//		// part1 += parent.size() * K2.log2(K2.VEXNUM);
//		part1 *= d * AlarmReader.AlarmNodeDef[index];
//
//		// ������ѯ����
//		int[] parentArray = new int[parent.size()];
//		int[] allArray = new int[parent.size() + 1];
//
//		for (int i = 0; i < parent.size(); i++) {
//			parentArray[i] = parent.get(i);
//		}
//		Arrays.sort(parentArray);
//		System.arraycopy(parentArray, 0, allArray, 1, parentArray.length);
//		allArray[0] = index;
//		// ȡ�ò�ѯ���
//		HashMap parentResult = this.getCount(this.Records, parentArray);
//		HashMap allResult = this.getCount(this.Records, allArray);
//
//		// System.out.println(parentResult);
//		// System.out.println(allResult);
//
//		Set allKey = allResult.keySet();
//		// System.out.println(allKey);
//		Iterator it = allKey.iterator();
//		double part2 = 0.0;
//		while (it.hasNext()) {
//			String key = (String) it.next();
//			String pareKey = this.getPareKey(key);
//			double allValue = (Integer) allResult.get(key);
//			double paraValue = (Integer) parentResult.get(pareKey);
//			double temp1 = paraValue / allValue;
//			double temp = allValue * K2.log2(temp1);
//			// System.out.println("temp"+temp);
//			part2 += temp;
//		}
//		result = -(part1 + part2);
//		// System.out.println("HM:part1="+part1+",part2="+part2);
//		return result;
//	}
//
//	/**
//	 * �������Ĳ�ѯ����У�ȡ�õ�ǰ��ѯ����ĸ�ĸ�ڵ��key��
//	 */
//	public String getPareKey(String key) {
//		int pos = key.indexOf(";");
//		String parentKey = key.substring(pos + 1, key.length());
//		return parentKey;
//	}
//
//	public boolean isDataMiss(String[] data, ArrayList<Integer> index) {
//		boolean tag = false;
//		for (int i = 0; i < index.size(); i++) {
//			if (data[i].equals("?"))
//				tag = true;
//		}
//		return tag;
//	}
//
//	public double calcGraphScore(BNGraph g) {
//		double score = 0.0;
//		double size = g.getVexNum();
//		for (int i = 0; i < size; i++) {
//			ArrayList parent = g.GetNode(i).GetParentNodesIndex();
//			double nodescore = this.calcScore(i, parent);
//			score += nodescore;
//		}
//
//		return score;
//
//	}
//
//	/**
//	 * �����������֣�K2��mdl ��Ϊ�ӿ��ð�
//	 * 
//	 * @param index
//	 *            int
//	 * @param parent
//	 *            ArrayList
//	 * @return double
//	 */
//	public double calcScore(int index, ArrayList<Integer> parent) {
//		// return this.calcMDLuseHM(index,parent);//HashMap��
//		// return this.calcK2BrutalCache(index, parent);
//		// return this.calcK2Brutal(index, parent);
//		return this.calcK2(index, parent);
//		// return this.calcK2Cache(index, parent);
//		// return this.calcMDLuseHMCache(index,parent);
//		// return this.calcMDLUseArrayCache(index,parent);//Array��
//		// return this.calcMDLUseArray(index,parent);
//	}
//	public Hashtable calcTheta(BNGraph g) {
//		Hashtable result = new Hashtable();
//		for (int i = 0; i < this.VEXNUM; i++) {
//			ArrayList parent = g.GetNode(i).GetParentNodesIndex();
//			int[] parent_array = new int[parent.size()];
//			int[] parent_all = new int[parent.size() + 1];
//
//			for (int j = 0; j < parent_array.length; j++) {
//				parent_array[j] = (Integer) parent.get(j);
//				parent_all[j + 1] = (Integer) parent.get(j);
//			}
//			parent_all[0] = i;
//			int[] rparent = this.getCountBrutal(this.Records, parent_array);
//			int[] rparentall = this.getCountBrutal(this.Records, parent_all);
//
//			double[] theta_all = new double[rparentall.length];
//
//			for (int j = 0; j < theta_all.length; j++) {
//				double temp1 = (double) rparentall[j];
//				double temp2 = (double) rparent[j % rparent.length];
//				if (temp1 != 0.0)
//					theta_all[j] = temp1 / temp2;
//				else {
//					double ri = new Double(AlarmReader.AlarmNodeDef[i]);
//					theta_all[j] = 1 / ri;
//				}
//			}
//			result.put(i, theta_all);
//		}
//		return result;
//	}
//
//	/**
//	 * ����likehood���
//	 * 
//	 * @param g
//	 * @return
//	 */
//	public double calcLogLoss(BNGraph g) {
//		double result = 0.0;
//		Hashtable thetall = this.calcTheta(g);
//		for (int i = 0; i < g.getVexNum(); i++) {
//			ArrayList parent = g.GetNode(i).GetParentNodesIndex();
//			int[] parent_all = new int[parent.size() + 1];
//
//			for (int j = 0; j < parent_all.length - 1; j++) {
//				parent_all[j + 1] = (Integer) parent.get(j);
//			}
//			parent_all[0] = i;
//			int[] rparentall = this.getCountBrutal(this.Records, parent_all);
//			double[] theta = (double[]) thetall.get(i);
//			for (int j = 0; j < theta.length; j++) {
//				double theta1 = Math.log10(theta[j]);
//				result += rparentall[j] * theta1;
//			}
//		}
//		return result / this.Records.length;
//	}
//
//	/**
//	 * ������
//	 * 
//	 * @param args
//	 *            String[]
//	 */
//	public static void main(String[] args) {
//		try {
//			// alarm-bnpc-10000.txt
//			// alarm_5000_mlwong.txt
//			// AlarmReader ar = new AlarmReader("c:\\bnjalarm.txt", 3000,
//			// 37);
//			AlarmReader ar = new AlarmReader("data\\alarmacob.txt", 3000, 37);
//			BNGraph g = BNGraph.GetGraphStandAlarm();
//
//			String[][] data = ar.GetDataSet();
//			K2 k2 = new K2(data);
//			System.out.println(k2.calcGraphScore(g));
//
//			// double logloss = k2.calcLogLoss(g);
//			// System.out.println(logloss);
//
//			// Hashtable thetall = k2.calcTheta(g);
//			// for (int i = 0; i < thetall.size(); i++) {
//			// double[] result = (double[]) thetall.get(i);
//			// System.out.print(AlarmReader.index2nodeName.get(i + 1) + " ");
//			// CommonTools.outArray(result);
//			//				
//			// }
//			// BNGraph g = BNGraph.GetGraphStandAlarm();
//			// double score = g.calcTotalK2Score();
//			//			
//			// System.out.print(score);
//
//			// Score k2 = new K2("data\\alarmstring.txt", 3000, 37);
//			// BNGraph g = BNGraph.GetGraphStandAlarm();
//			// double score = k2.calcGraphScore(g);
//			// System.out.print(score);
//			
//
//			// K2.INSTANCE = K2.getK2("alarm_5000_mlwong.txt",5000,37);
//			// K2.INSTANCE = K2.getK2("alarm-bnpc-10000.txt",10000,37);
//			// K2.calcInf();
//			// System.out.println(K2.maxMI*5000);
//			// System.out.println(K2.minMI*5000);
//
//			// BNGraph s = BNGraph.GetGraphStandAlarm_mlwong();
//
//			// BNGraph s = new BNGraph(37);
//			// ArrayList al = new ArrayList();
//			// System.out.println( K2.INSTANCE.calcScore(18, al) );
//
//			// long start = System.currentTimeMillis();
//			//
//			// BNGraph s = BNGraph.GetGraphStandAlarm();
//			// System.out.println(s.toString());
//			// long end = System.currentTimeMillis();
//			//
//			// System.out.println(SingleAntB.calcGraph(s));
//			// System.out.println("time:"+(end-start));
//
//			// ArrayList al = new ArrayList();
//			// al.add(24);
//			// double temp = K2.INSTANCE.calcScore(0, al);
//			// System.out.println(temp);
//
//			// long end = System.currentTimeMillis();
//			// System.out.println(end - start);
//			//
//			// for(int i = 0; i < NodeInfo.length; i++)
//			// {
//			// System.out.print(NodeInfo[i].size()+",");
//			// }
//			// System.err.println("log"+k2.log2(100000000));
//			// ����
//			// ArrayList<Integer> al = new ArrayList<Integer> ();
//			// al.add(1);
//			// System.out.println(k2.calcMDLuseHM(0,al));
//			// System.out.println(k2.calcMDLUseArray(0,al));
//			// System.out.println(k2.calcMDLUseArrayCache(16,al));
//			// System.out.println(k2.calcK2Brutal(16,al));
//			// //
//			// //��������
//			// BNGraph g = new BNGraph(3);
//			// g.AddArc(0,1);
//			// g.AddArc(1,2);
//			// System.out.println(SingleAntB.calcGraph(g));
//			// BNGraph g1 = new BNGraph(3);
//			// g1.AddArc(0,1);
//			// g1.AddArc(0,2);
//			// System.out.println(SingleAntB.calcGraph(g1));
//
//			// �����²�ѯ��ͨ��
//			// int[] inquery = {0,1,2};
//			// int[] result = k2.getCountBrutal(k2.Records,inquery);
//			// for(int i : result)
//			// System.out.print(i+" ");
//			//
//			// System.out.println("\n"+k2.getCount(k2.Records,inquery));
//			// HashMap hm = new HashMap();
//
//			// ����ͼ
//			// BNGraph bn = new BNGraph(3);
//			// bn.AddArc(2,1);
//			// bn.AddArc(0,1);
//			// bn.GetNode(0).K2Score = 1.0;
//			// bn.GetNode(1).K2Score = 2.0;
//			// System.out.println(bn.GetNode(1).GetDescendantNodesIndex();
//			// HashMap<String,Integer> hm = new HashMap<String,Integer>();
//			// String s1 = "2,";
//			// StringBuilder sb = new StringBuilder();
//			// sb.append(2);
//			// sb.append(",");
//			// hm.put(s1,1);
//			// String s2 = sb.toString();
//			// System.out.println(hm.get(s2));
//			// k2.testspeed();
//			// int[] a = {1,0,5};
//			// k2.getCountBrutal(k2.Records,a);
//			// System.out.println(k2.getCount(k2.Records,a));
//			// mdl 34287.9
//			// String key = "HIGH;LOW;TRUE;=3";
//			// System.out.println(k2.getPareKey(key));
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//
//	}
//}
//
package bjut.ai.bn.score;

/**
 * <p>Title: K2</p>
 *
 * <p>Description: ����K2����</p>
 *
 * <p>Copyright: Copyright (c) 2007</p>
 *
 * <p>Company: </p>
 *
 * @author not attributable
 * @version 1.0
 */
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
public class K2 extends Score
{
	// ����Ϣ
	public static double maxMI;
	public static double minMI;
	public static double[][] Inf;
	public static int[][] ChiSquare;
	// record ʵ������ indexs Ҫ��ѯ�Ľڵ����飬���ز�ѯ���ΪHashMap
	public static PrintWriter out;
//	public static int VEXNUM = 37; // alarm 37, insurance 27,HailFinder 56
									// ,child 20 ,barley 48
	// public static final K2 INSTANCE = new K2("alarm_20071019.TXT", 3000,
	// K2.VEXNUM);
	
	public static int VEXNUM = 5;//��Ҫ��
  //  public static int VEXNUM = 12;//��Ҫ��
	
	
	public static K2 INSTANCE = null;
	// public static final K2 INSTANCE = new K2("xuns.txt", 2000, K2.VEXNUM);
	// public static final K2 INSTANCE = new K2("insurance_s10000.txt", 1000,
	// K2.VEXNUM);
	// public static final K2 INSTANCE = new K2("HailFinder_s10000.txt", 5000,
	// K2.VEXNUM);
	// public static final K2 INSTANCE = new K2("child_10000.txt", 3000,
	// K2.VEXNUM);
	// public static final K2 INSTANCE = new K2("barley_10000.txt", 3000,
	// K2.VEXNUM);
	// �������
	public static int cacheCount = 0;// ����ĸ���
	public static int count = 0;// ���ü������
	public static int actualCalcCount = 0;
	public static TreeSet[] NodeInfo;

	public static enum TYPE {
		ORI, CI, CInew, HF, OP, AIO, SA
	};

	private String[][] Records;
	private HashMap<String, Double> hm; // �м����
	public HashMap<String, Double> cacheResult;
	private int ri;

	public static K2 getK2(String dir, int DatasetNum, int VexNum) {
	K2.INSTANCE = new K2(dir, DatasetNum, VexNum);
	K2.VEXNUM = VexNum;
	
	return K2.INSTANCE;
	 }


	 public K2(String fileName, int size, int nodeNums) {
	 AlarmReader ar = new AlarmReader(fileName, size, nodeNums);
	 this.Records = ar.GetDataSet();
	 K2.NodeInfo = ar.getColumnValue();
	 this.cacheResult = new HashMap<String, Double>();
	 }

	
	public String[][] getRecord() {
		return this.Records;
	}
	
	@Override
	public void clearCache() {
		System.out.println("�������");
		K2.count = 0;
		K2.cacheCount = 0;
		K2.actualCalcCount = 0;
		this.cacheResult = new HashMap<String, Double>();
	}

	/**
	 * ����K2���ֺ��� calcK2(0,{1,2,3})û�л���
	 * 
	 * @param index
	 *            int ��ǰ�ڵ�
	 * @param parent
	 *            int[] index�ĸ�ĸ�ڵ� �밴��Ȼ˳������
	 * @return double �������ֺ���ֵ
	 */
	public double calcK2(int index, ArrayList<Integer> parent1) {
		int[] parent = new int[parent1.size()];
		int temp = 0;
		while (temp < parent1.size()) {
			parent[temp] = parent1.get(temp);
			temp++;
		}
		// Arrays.sort(parent);
		// ȡ�ò�ѯ���
		int[] temp_parent = new int[parent.length + 1];
		System.arraycopy(parent, 0, temp_parent, 1, parent.length);
		temp_parent[0] = index;
		// Arrays.sort(temp_parent);
		ri = NodeInfo[index].size();
		// ����ڶ�����
		hm = K2.getCount(this.Records, temp_parent);
		double ijk_result = this.calcPart2(hm);
		// System.out.println("�ڶ�����=" + ijk_result);

		// �����һ����
		hm = K2.getCount(Records, parent); // ȡ��Nij
		double ij_result = this.calcPart1(hm);
		// System.out.println(Arrays.asList(hm));
		// System.out.println("��һ����=" + ij_result);
		double result = ij_result + ijk_result;
		return result;
	}

	
	/**
	 * �����
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 * 
	 *         ԭ��calcK2Cache
	 */
	public double calcK2Cache(int index, ArrayList<Integer> parent) {
		double result = 0.0;
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		String indexString = this.convertToString(indexArray);
		if (this.cacheResult.containsKey(indexString)) {
			result = this.cacheResult.get(indexString);
			K2.cacheCount++;
		} else {
			result = this.calcK2Tool(index, indexArray);
			this.cacheResult.put(indexString, result);
		}
		return result;
	}

	/**
	 * 
	 * @param index
	 *            int
	 * @param al
	 *            ArrayList
	 * @return double
	 */
	private double calcK2Brutal(int index, ArrayList<Integer> al) {

		// ȡ�ó�ʼ����
		int qi = 1;
		int ri = NodeInfo[index].size();
		double result = 0;

		// ȡ�ò�ѯ����
		int[] allNodes = new int[al.size() + 1];
		for (int k = 0; k < al.size(); k++) {
			allNodes[k + 1] = al.get(k);
		}
		allNodes[0] = index;
		// ȡ�ò�ѯ���
		int[] countResult = K2.getCountBrutal(this.Records, allNodes);
		for (int count = 0; count < al.size(); count++) {
			qi = qi * NodeInfo[al.get(count)].size();
		}
		// ��ʼ����
		int step = qi;
		for (int i = 0; i < qi; i++) {
			int Nij = 0;
			int Nijk = 0;
			// ����ڶ�����
			double result2 = 0;
			int point = 0;
			for (int j = 0; j < ri; j++) {
				Nijk = countResult[i + point];
				result2 = result2 + K2.calcLog(Nijk);
				Nij = Nij + Nijk;
				point = point + step;
			}
			// �����һ����
			double temp1 = K2.calcLog(ri - 1);
			double temp2 = K2.calcLog(Nij + ri - 1);
			double result1 = temp1 - temp2;
			result = result + result1 + result2;
		}

		return result;
	}

	/**
	 * ������Ϊ�˷������mdl ԭ��calcK2BrutalCache ����k2��ѡ����
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 */
	public double calcK2BrutalCache(int index, ArrayList<Integer> parent) {
		K2.count++;
		double result = 0.0;
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;

		String indexString = this.convertToString(indexArray);
		if (this.cacheResult.containsKey(indexString)) {
			result = this.cacheResult.get(indexString);
			K2.cacheCount++;
		} else {
			result = this.calcK2Brutal(index, parent);
			this.cacheResult.put(indexString, result);
			K2.actualCalcCount++;
		}
		return result;

	}

	/**
	 * ת��int[]Ϊ�����ַ���
	 * 
	 * @param array
	 *            int[]
	 * @return String
	 */
	private String convertToString(int[] array) {
		StringBuilder sb = new StringBuilder();
		for (int k : array) {
			sb.append(k);
			sb.append(",");
		}
		return sb.toString();
	}

	public static PrintWriter getPrinWriter(String filename) throws IOException {
		File dir = new File("c:" + File.separator + "BayesianLog_Alarm_mdl");
		dir.mkdir();
		File file = new File(dir, filename + ".csv");
		return new PrintWriter(new FileWriter(file, false));
	}

	private String convertToString(ArrayList<Integer> al) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0, size = al.size(); i < size; i++) {
			sb.append(al.get(i));
			sb.append(",");
		}
		return sb.toString();
	}

	private double calcPart1(HashMap h1) // ij
	{
		// System.out.println("�����һ����ʱ��getCount��ϣ��\n" + h1);
		double ij_result = 0;
		Collection c = h1.values();
		Iterator it = c.iterator();
		while (it.hasNext()) {
			int Nij = (Integer) it.next();
			double temp1 = K2.calcLog(ri - 1);
			double temp2 = K2.calcLog(Nij + ri - 1);
			double temp3 = temp1 - temp2;
			ij_result = ij_result + temp3;
		}
		c = null;
		it = null;
		return ij_result;
	}

	private double calcPart2(HashMap h2) // ijk
	{
		// System.out.println("����ڶ�����ʱ��getCount��ϣ��\n" + h2);

		double ijk_result = 0;
		Collection c = h2.values();
		Iterator it = c.iterator();
		while (it.hasNext()) {
			int temp_k = (Integer) it.next();
			double temp_result = K2.calcLog(temp_k);
			ijk_result = ijk_result + temp_result;
		}
		c = null;
		it = null;
		return ijk_result;
	}

	/**
	 * ����log(n!)
	 * 
	 * @param n
	 *            int
	 * @return double
	 */
	private static double calcLog(int n) {
		double result = 0;
		for (int i = 1; i <= n; i++) {
			result = result + java.lang.Math.log10(i);
		}
		return result;
	}

	/**
	 * log2
	 * 
	 * @param value
	 *            double
	 * @return double
	 */
	public static double log2(double value) {
		return Math.log(value) / Math.log(2);

	}

	/**
	 * �ڲ�ʹ��
	 * 
	 * @param index
	 *            int
	 * @param parentIJK
	 *            int[]
	 * @return double
	 */
	private double calcK2Tool(int index, int[] parentIJK) {
		int[] parent = new int[parentIJK.length - 1];
		System.arraycopy(parentIJK, 1, parent, 0, parent.length);

		ri = NodeInfo[index].size();
		// ����ڶ�����
		hm = K2.getCount(this.Records, parentIJK);
		double ijk_result = this.calcPart2(hm);
		// System.out.println("�ڶ�����=" + ijk_result);

		// �����һ����
		hm = K2.getCount(Records, parent); // ȡ��Nij
		double ij_result = this.calcPart1(hm);
		// System.out.println("��һ����=" + ij_result);
		double result = ij_result + ijk_result;
		return result;

	}

	/**
	 * ������ѯ���У���ѯ������ϳ��ֵĴ���
	 * 
	 * @param record
	 *            String[][] ���������
	 * @param indexs
	 *            int[] Ҫ��ѯ�Ľڵ�����
	 * @return HashMap ��ѯ���
	 */
	private static HashMap getCount(String[][] record, int[] indexs) {
		HashMap hm = new HashMap();
		StringBuilder sb;
		Object tempcount;
		for (int i = 0; i < record.length; i++) {
			sb = new StringBuilder();
			for (int j = 0; j < indexs.length; j++) {

				sb.append(record[i][indexs[j]]);
				sb.append(";");
			}
			String temp = sb.toString();
			int count = 0;
			if ((tempcount = hm.get(temp)) != null) {
				count = (Integer) tempcount;
			}
			hm.put(temp, ++count);
		}
		// System.out.println("��ѯ�ڵ�");
		// for (int k : indexs)
		// System.out.print(k + ",");
		// System.out.println("");
		// System.out.println(hm);
		return hm;
	}

	/**
	 * indexs ��ѯ�Ľڵ�����飬�������� ��������
	 * 
	 * @param record
	 *            String[][]
	 * @param indexs
	 *            int[]
	 * @return int[]
	 */
	public static int[] getCountBrutal(String[][] record, int[] indexs) {
		// ��ʼ���������
		int resultLength = 1;
		for (int i = 0; i < indexs.length; i++) {
			int size = NodeInfo[indexs[i]].size();
			resultLength = resultLength * size;
		}
		// System.out.println("\n��ѯ���鳤��"+resultLength);
		int[] result = new int[resultLength];
		for (int j = 0; j < record.length; j++) {
			int[] temp = new int[indexs.length];
			for (int k = 0; k < indexs.length; k++) {
				temp[k] = Integer.parseInt(record[j][indexs[k]]);
			}
			int index = K2.calcStringToIndex(temp, indexs);
			// System.out.println("����ֵ"+index);
			// for(int c : temp)
			// System.out.print(c+",");
			result[index]++;
		}
		// for (int i : result)
		// {
		// if(i !=0)
		// System.out.print(i + ",");
		//
		// }
		return result;
	}

	/**
	 * 
	 * @param array
	 *            int[]
	 * @return int
	 */
	private static int calcStringToIndex(int[] array, int[] indexs) {
		int index = 0;
		for (int i = 0; i < array.length; i++) {
			int temp = 1;
			for (int j = i + 1; j < array.length; j++) {
				temp = temp * NodeInfo[indexs[j]].size();
			}
			index = index + array[i] * temp;
		}

		return index;
	}

	/**
	 * for test only
	 */

	public void testspeed() {
		double[][] temp1 = new double[37][37];
		ArrayList<Integer> anodelist = null; // ��ʱ
		System.out.println("��ʼ��������Ϣ����");

		long start = System.currentTimeMillis();
		for (int i = 0; i < K2.VEXNUM; i++)
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (i != j) {
					anodelist = new ArrayList<Integer>();
					anodelist.add(j);
					temp1[i][j] = K2.INSTANCE.calcK2Brutal(i, anodelist)
							- K2.INSTANCE.calcK2Brutal(i,
									new java.util.ArrayList());
				} else
					temp1[i][j] = Double.NEGATIVE_INFINITY;
			}
		long end = System.currentTimeMillis();
		CommonTools.outArray(temp1);
		System.out.format("���,����[%d]����\n", end - start);
	}

	
	// �����Բ��Բ���
	/**
	 * ���㻥��Ϣ
	 * 
	 */
	public static void calcInf(String[][] data) {
		System.out.println("���㻥��Ϣ");
		K2.Inf = new double[K2.VEXNUM][K2.VEXNUM];
		int row = 0;
		int col = 0;
		for (row = 0; row < K2.VEXNUM; row++) {
			for (col = 0; col < K2.VEXNUM; col++) {
				// ����������
				if (row < col) {
					//
					Inf[row][col] = K2.calcInd(row, col, data);
				} else {
					Inf[row][col] = Inf[col][row];
				}
			}
		}
		K2.maxMI = K2.getMaxMI();
		K2.minMI = K2.getMinMI();
	}

	/**
	 * 
	 * @param n
	 *            int
	 * @return double
	 */
	private static double getChiSquare(int n) {
		// n ���ɶ� ����鿨������
		// �� = 0.005

		 double[] chi = { 7.879, 10.597, 12.838, 14.860, 16.750, 18.548, 20.278,
				21.955, 23.589, 25.188, 26.757, 28.299, 29.819, 31.319, 32.801,
				34.267, 35.718, 37.156, 38.582 };

		// �� = 0.01;
		// double[] chi =
		// {
		// 6.635, 9.210, 11.345, 13.277, 15.086, 16.812, 18.475, 20.090, 21.666,
		// 23.209,
		// 24.725,
		// 26.217, 27.688, 29.141, 30.578, 32.000, 33.409, 34.805, 36.191,
		// 37.566, 38.932,
		// 40.289, 41.638, 42.980, 44.314, 45.642};

		// �� = 0.05;
		// double[] chi =
		// {
		// 3.841,5.991,7.815,9.488,11.071,12.592,14.067,15.507,16.919,18.307,
		// 19.675,21.026,
		//22.362,23.685,24.996,26.296,27.587,28.869,30.144,31.410,32.671,33.924,
		// 35.172,36.415,37.652
		// };
		//
		// �� = 0.1;
		// double[] chi =
		// {
		//2.706,4.605,6.251,7.779,9.236,10.645,12.017,13.362,14.684,15.987,17.275
		// ,
		// 18.549,19.812,21.064,22.307,23.542,24.769,25.989,27.204,28.412
		// };

		// �� = 0.995;
		// double[] chi =
		// {
		// 0, 0.010, 0.072, 0.207, 0.412, 0.676, 0.989, 1.344, 1.735, 2.156,
		// 2.603, 3.074, 3.565,
		// 4.075, 4.601, 5.142, 5.697, 6.265, 6.844, 7.434, 8.034
		// };
		//

		// �� = 0.95;
		// double[] chi =
		// {
		//0.004,0.103,0.352,0.711,1.145,1.635,2.167,2.733,3.325,3.940,4.575,5.226
		// ,5.892,
		// 6.571,7.261,7.962,8.672,9.390,10.117,10.851
		// };

		// �� = 0.75;
		// double[] chi = { 0.102, 0.575, 1.213, 1.923, 2.675, 3.455, 4.255,
		// 5.071, 5.899, 6.737, 7.584, 8.438, 9.299, 10.165, 11.037,
		// 11.912, 12.792, 13.675, 14.562, 15.452 };
		//
		 
		return chi[n - 1];

	}

	/**
	 * �����Բ���
	 */
	public static void CITest(String[][] data) {
		System.out.println("����X������");
		K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
		int arcToRemove = 0;
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (i == j) {
					continue;
				}
				double t = 2 * data.length * K2.Inf[i][j];
				int DegOfFreeDom = (K2.NodeInfo[i].size() - 1)
						* (K2.NodeInfo[j].size() - 1);
				double valueChi = K2.getChiSquare(DegOfFreeDom);
				// valueChi = 0.17;
				if (t > valueChi) {
					K2.ChiSquare[i][j] = 1;
				} else {
					arcToRemove++;

				}
			}
		}
		System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
		// BNGraph gstand= BNGraph.GetGraphStandInsurance();
		BNGraph gstand = BNGraph.GetGraphStandAlarm();
		// System.err.print(gstand);
		int[][] arcarr = gstand.GetArcArray();
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
					int tempn = (K2.NodeInfo[i].size() - 1)
							* (K2.NodeInfo[j].size() - 1);
					System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
							* data.length * K2.Inf[i][j]
							+ "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
					// K2.Inf[i][j]
							);
				}
			}
		}

	}

	public static void CITestByValue(double a) {
		System.out.println("����X�����飬by value");
		K2.ChiSquare = new int[K2.VEXNUM][K2.VEXNUM];
		int arcToRemove = 0;
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (i == j) {
					continue;
				}
				double t = 2 * K2.INSTANCE.Records.length * K2.Inf[i][j];
				if (t > a) {
					K2.ChiSquare[i][j] = 1;
				} else {
					arcToRemove++;

				}

			}
		}

		System.err.println("******�����˱ߣ�" + arcToRemove + "��...");
		// BNGraph gstand= BNGraph.GetGraphStandInsurance();
		BNGraph gstand = BNGraph.GetGraphStandAlarm();
		// System.err.print(gstand);
		int[][] arcarr = gstand.GetArcArray();
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (K2.ChiSquare[i][j] == 0 && arcarr[i][j] == 1) {
					int tempn = (K2.NodeInfo[i].size() - 1)
							* (K2.NodeInfo[j].size() - 1);
					System.err.println("����ɾ���˱� i=" + i + " j=" + j + "����Ϣ��" + 2
							* K2.INSTANCE.Records.length * K2.Inf[i][j]
							+ "���ɶȣ�" + tempn + "����ֵ:" + K2.getChiSquare(tempn)
							+ "base:" + a
					// K2.Inf[i][j]
							);
				}
			}
		}

	}

	/**
	 * ȡ�����Ļ���Ϣֵ
	 * 
	 * @return double
	 */

	public static double getMaxMI() {
		double infMax = 0;
		double[][] inf = K2.Inf;
		for (int i = 0; i < inf.length; i++) {
			for (int j = 0; j < inf.length; j++) {
				// System.out.print(inf[i][j] + " ");
				if (inf[i][j] > infMax) {
					infMax = inf[i][j];
				}
			}
			// System.out.print("\r\n ");
		}
		// System.out.print("\r\n�����Ϣ��" + infMax);
		return infMax;

	}

	public static double getMinMI() {
		double infMin = Double.POSITIVE_INFINITY;
		double[][] inf = K2.Inf;
		for (int i = 0; i < inf.length; i++) {
			for (int j = 0; j < inf.length; j++) {
				if ((inf[i][j] < infMin) && inf[i][j] != 0) {
					infMin = inf[i][j];
				}
			}
		}
		return infMin;

	}

	public static double calcInd(int x, int y, String[][] data) {
		double result = 0.0;
		int[] query = { x, y };
		int[] queryResult = K2.getCountBrutal(data, query);
		double[][] arrayProb = constructProbArray(x, y, queryResult, data);
		double[] px = constructProbX(arrayProb);// ����
		double[] py = constructProbY(arrayProb);// ����

		for (int i = 0; i < arrayProb.length; i++) {
			for (int j = 0; j < arrayProb[0].length; j++) {
				if (arrayProb[i][j] != 0.0) {
					double temp = Math.log10(arrayProb[i][j] / px[j] / py[i]);
					temp *= arrayProb[i][j];
					result += temp;
				}
			}
		}
		return result;
	}

	/**
	 * ������ʾ���
	 * 
	 * @param x
	 *            int
	 * @param y
	 *            int
	 * @param result
	 *            int[]
	 * @return double[][]
	 */
	private static double[][] constructProbArray(int x, int y,
			int[] queryResult, String[][] data) {
		int count = 0;
		int jIndex = K2.NodeInfo[x].size();
		int iIndex = K2.NodeInfo[y].size();
		double num = data.length;
		double[][] arrayProb = new double[iIndex][jIndex];
		for (int j = 0; j < jIndex; j++) {
			for (int i = 0; i < iIndex; i++) {
				arrayProb[i][j] = queryResult[count++] / num;
			}
		}
		return arrayProb;
	}

	private static double[] constructProbX(double[][] arrayProb) {
		double[] px = new double[arrayProb[0].length];
		for (int j = 0; j < arrayProb[0].length; j++) {
			for (int i = 0; i < arrayProb.length; i++) {
				px[j] += arrayProb[i][j];
			}
		}
		return px;
	}

	private static double[] constructProbY(double[][] arrayProb) {
		double[] py = new double[arrayProb.length];
		for (int i = 0; i < arrayProb.length; i++) {
			for (int j = 0; j < arrayProb[0].length; j++) {
				py[i] += arrayProb[i][j];
			}
		}
		return py;
	}

	/**
	 * ע��
	 * 
	 * @param ori
	 *            double
	 * @return double
	 */
	// public static double getMIRadio(int i, int j)
	// {
	// double mother = calcSquarSum();
	// System.out.println("��ĸ"+mother+"���ӣ�"+Inf[i][j]);
	// double sum = Inf[i][j]/mother;
	// return sum;
	// }
	public static double getRefect(double ori) {
		return (ori - K2.minMI) / (K2.maxMI - K2.minMI);
	}


	public static BNGraph[] b = new BNGraph[2];

	private double CalcMDLPart1(int index, ArrayList parent) {
		double d = 0;
		d = (K2.log2(this.Records.length) * 0.9) / 2;
		// d = 5.85;
		// d = Math.ceil(d);
		int vi = NodeInfo[index].size();
		double part1 = parent.size() * K2.log2(K2.VEXNUM);
		// double part1 = parent.size() * K2.log2( this.Records.length );
		// if(parent.size() > 0)
		// {
		// part1 = Math.pow(2,parent.size()) * K2.log2( K2.VEXNUM );
		// }
		double part2 = 0;
		Iterator it = parent.iterator();
		if (parent.size() > 0) {
			part2 = 1.0;
			while (it.hasNext()) {
				int ParentNode = (Integer) it.next();
				int vj = NodeInfo[ParentNode].size();
				part2 *= (vj);
			}
		}

		return d * vi * part2;
		// return part1 + d *(vi-1) * part2;
	}

	private double CalcMDLPart2(int index, ArrayList<Integer> parent) {
		// ȡ�ó�ʼ����
		int qi = 1;
		// int ri = NodeInfo[index].size();
		double result2 = 0;

		// ȡ�ò�ѯ����
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		// ȡ�ò�ѯ���
		int[] countResult = K2.getCountBrutal(this.Records, indexArray);

		// for(int i = 0; i < countResult.length; i++)
		// System.out.print(countResult[i]+" ");
		// System.out.println();

		for (int count = 0; count < parent.size(); count++) {
			qi = qi * NodeInfo[parent.get(count)].size();
		}
		double[] NijkArray = new double[qi];
		// ���Nij
		for (int i = 0; i < NijkArray.length; i++) {
			int step = 0;
			for (int j = 0; j < NodeInfo[index].size(); j++) {
				NijkArray[i] += countResult[i + step];
				step += qi;
			}
		}
		double[] NijArray = new double[NodeInfo[index].size() * qi];
		int pos1 = 0;
		int pos2 = 0;
		for (int i = 0; i < NodeInfo[index].size(); i++) {
			System.arraycopy(NijkArray, pos1, NijArray, pos2, NijkArray.length);
			pos2 += qi;
		}
		// System.out.println(countResult.length);
		for (int i = 0; i < countResult.length; i++) {
			if (countResult[i] != 0) {
				double para = NijArray[i] / countResult[i];
				// System.out.println(para);
				double TempLog = K2.log2(para);
				double TempResult = countResult[i] * TempLog;
				// System.out.println(TempResult);
				result2 += TempResult;
			}
			// System.out.println(result2);
		}
		return result2;
	}

	/**
	 * ����MDL���֣�Ӧ�������ѯ��
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 */
	public double calcMDLUseArray(int index, ArrayList<Integer> parent) {
		double part1 = this.CalcMDLPart1(index, parent);
		double part2 = this.CalcMDLPart2(index, parent);
		double result = -(part2 + part1);
		// System.out.println(" " +part1+" , " + part2 + " = " + result);
		// System.out.println( part2 );
		return result;
	}

	// PrintWriter pw = CommonTools.getPrintWriter("c:\\cache","cache.log");

	public double calcMDLuseHMCache(int index, ArrayList<Integer> parent) {
		K2.count++;
		double result = 0.0;
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		String indexString = this.convertToString(indexArray);
		if (this.cacheResult.containsKey(indexString)) {
			result = this.cacheResult.get(indexString);
			K2.cacheCount++;
		} else {
			result = this.calcMDLuseHM(index, parent);
			this.cacheResult.put(indexString, result);
			K2.actualCalcCount++;
		}
		return result;

	}

	public double calcMDLUseArrayCache(int index, ArrayList<Integer> parent) {

		K2.count++;
		double result = 0.0;
		int[] indexArray = new int[parent.size() + 1];
		for (int i = 0; i < parent.size(); i++) {
			indexArray[i + 1] = parent.get(i);
		}
		Arrays.sort(indexArray);
		indexArray[0] = index;
		String indexString = this.convertToString(indexArray);
		if (this.cacheResult.containsKey(indexString)) {
			result = this.cacheResult.get(indexString);
			// pw.println("����"+index+","+parent+","+result+","+indexString);
			K2.cacheCount++;
		} else {
			result = this.calcMDLUseArray(index, parent);
			this.cacheResult.put(indexString, result);
			// pw.println("����"+index+","+parent+","+result+","+indexString);

			K2.actualCalcCount++;
		}
		// pw.flush();
		return result;

	}

	/**
	 * ����mdlֵ����HM calcK2BrutalCache calcMDLuseHM
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 */
	public double calcMDLuseHM(int index, ArrayList<Integer> parent) {
		double result = 0.0;
		double part1 = 0;// ��һ���ֽ��
		double d = 0;

		d = (K2.log2(this.Records.length) * 0.9) / 2;

		if (parent.size() > 0) {
			part1 = 1;
			for (int i = 0; i < parent.size(); i++) {
				int node = parent.get(i);
				part1 *= NodeInfo[node].size();
			}
		}
		// part1 *= d * (NodeInfo[index].size()-1);
		// part1 += parent.size() * K2.log2(K2.VEXNUM);
		part1 *= d * NodeInfo[index].size();

		// ������ѯ����
		int[] parentArray = new int[parent.size()];
		int[] allArray = new int[parent.size() + 1];

		for (int i = 0; i < parent.size(); i++) {
			parentArray[i] = parent.get(i);
		}
		Arrays.sort(parentArray);
		System.arraycopy(parentArray, 0, allArray, 1, parentArray.length);
		allArray[0] = index;
		// ȡ�ò�ѯ���
		HashMap parentResult = K2.getCount(this.Records, parentArray);
		HashMap allResult = K2.getCount(this.Records, allArray);

		// System.out.println(parentResult);
		// System.out.println(allResult);

		Set allKey = allResult.keySet();
		// System.out.println(allKey);
		Iterator it = allKey.iterator();
		double part2 = 0.0;
		while (it.hasNext()) {
			String key = (String) it.next();
			String pareKey = this.getPareKey(key);
			double allValue = (Integer) allResult.get(key);
			double paraValue = (Integer) parentResult.get(pareKey);
			double temp1 = paraValue / allValue;
			double temp = allValue * K2.log2(temp1);
			// System.out.println("temp"+temp);
			part2 += temp;
		}
		result = -(part1 + part2);
		// System.out.println("HM:part1="+part1+",part2="+part2);
		return result;
	}

	/**
	 * �������Ĳ�ѯ����У�ȡ�õ�ǰ��ѯ����ĸ�ĸ�ڵ��key��
	 */
	public String getPareKey(String key) {
		int pos = key.indexOf(";");
		String parentKey = key.substring(pos + 1, key.length());
		return parentKey;
	}

	public boolean isDataMiss(String[] data, ArrayList<Integer> index) {
		boolean tag = false;
		for (int i = 0; i < index.size(); i++) {
			if (data[i].equals("?"))
				tag = true;
		}
		return tag;
	}
	
	@Override
	public double calcGraphScore(BNGraph g) {
		double score = 0.0;
		double size = g.getVexNum();
		for (int i = 0; i < size; i++) {
			ArrayList parent = g.GetNode(i).GetParentNodesIndex();
			double nodescore = this.calcScore(i, parent);
			score += nodescore;
		}
		
		return score;
		
	}

	/**
	 * �����������֣�K2��mdl ��Ϊ�ӿ��ð�
	 * 
	 * @param index
	 *            int
	 * @param parent
	 *            ArrayList
	 * @return double
	 */
	@Override
	public double calcScore(int index, ArrayList<Integer> parent) {

		// return this.calcK2BrutalCache(index, parent);
		return this.calcK2Cache(index, parent);

	
	}

	/**
	 * ������
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String[] args) {
		try {
			// alarm-bnpc-10000.txt
			// alarm_5000_mlwong.txt
			// AlarmReader ar = new AlarmReader("c:\\bnjalarm.txt", 3000,
			// 37);
			//AlarmReader ar = new AlarmReader("data\\alarmacob.txt", 1000, 37);
			
	//		AlarmReader ar1 = new AlarmReader("F:\\sim1.txt", 2000, 5);
			
			BNGraph g = BNGraph.GetGraphStandAlarm();

		//	String[][] data = ar1.GetDataSet();
			//K2 k2 = new K2(data);
		    //System.out.println(k2.calcGraphScore(g));
			
			Score k2 = new K2("F:\\sim1.txt", 2000, 5);
			// Score k2 = new K2("data\\alarmstring.txt", 3000, 37);
			double score = k2.calcGraphScore(g);
		    System.out.print(score);

		  /*  
			String DatasetFile = "F:\\sim1-3.txt";//��Ҫ��
				int Vexnum = 5;//��Ҫ��		
				int[] DatasetNum = { 10000};//��Ҫ��	
		   K2 k=new K2("F:\\sim1.txt", 2000, 5);
		   AlarmReader ar = new AlarmReader(DatasetFile,				
					DatasetNum[count], 5);//��Ҫ��					
		 String[][] dataset1 = ar.GetDataSet();
		   K2.calcInf(dataset1);
	*/
		   
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
