package bjut.ai.bn.learning.acob.multithreads;
import java.io.PrintWriter;
import java.util.*;

import bjut.ai.bn.learning.acob.AlarmReader;
import bjut.ai.bn.BNGraph;
import bjut.ai.bn.CommonTools;
import bjut.ai.bn.HillClimbing;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;

/**
 * ���⣺1ͼ����ȡ�����Ƚڵ� 2ͼʵ��Compareble�ӿڶ����ֺ���ֵ
 * <p>
 * Title:
 * </p>
 * 
 * <p>
 * Description:
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * 
 * <p>
 * Company:
 * </p>
 * 
 * @author not attributable
 * @version 1.0
 */
public class ACOB {

	public double[][] tempH = null;
	public double[] noParVexK2Value = new double[K2.VEXNUM];
	// ȫ����Ϣ�ؾ���
	public double GlobalPheromoneMatrix[][] = new double[K2.VEXNUM][K2.VEXNUM];

	public int bestOccur = 0;
	public long[] bestOccurTime = new long[200];
	private static int solutionCount = 0;
	public ArrayList<BNGraph> BestSolutions;
	public static int LogK2ScoreCount = 0;
	/*
	 * public SingleAntB(double[][] apheromone, double analpha, double abeta,
	 * double arou, double aq0, double atao0, int aVexNum,int ID)
	 */
	public int vexnum;
	public Score score = null;
	public BNGraph BestSolution;

	private BNGraph gk2sn;
	private int tStep;
	private int tMaxStep;
	private int antNum;
	private double alpha;
	private double beta;
	private double rou;
	private double q0;
	private double tao0; // ��ʼ��Ϣ��

	private K2.TYPE type;

	private double[][] allPh;// ȫ�ֶ��������Ϣ��

	private java.util.ArrayList<Double> BestScore; // ÿһ�������ŷ�ֵ
	private java.util.TreeSet<Integer> setOpted; // �Ѿ������Ż�������ֵ
	private java.util.Random AnnealRandom = new Random();


	/**
	 * tStep�����Ż��Ĵ��� tMaxStep����������
	 * 
	 * @param tStep
	 *            int
	 * @param tMaxStep
	 *            int
	 */
	public ACOB(BNGraph gk2sn, double alpha, double beta, double rou,
			double q0, int tStep, int tMaxStep, int antNum, K2.TYPE type1,
			Score score) {
		// //���k2sn�Ľ� ��ʽ��
		this.score = score;

		this.gk2sn = gk2sn;
		this.vexnum = gk2sn.getVexNum();
		this.tempH = new double[vexnum][vexnum];
		this.tao0 = 1 / (vexnum * Math.abs(this.score
				.calcGraphScore(this.gk2sn)));
		this.BestSolution = gk2sn;
		// ��ʱ
		this.antNum = antNum;
		this.tMaxStep = tMaxStep;
		this.tStep = tStep;
		this.alpha = alpha;
		this.beta = beta;
		this.rou = rou;
		this.q0 = q0;
		this.BestSolutions = new ArrayList<BNGraph>();
		this.type = type1;
		switch (type) {
		case ORI:
			System.err.println("ԭʼ");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			break;
		case SA:
			System.err.println("ģ���˻��Ż�");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();
			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			break;

		case CI:
			System.err.println("CI����");
			this.BestScore = new ArrayList<Double>();
			this.setOpted = new TreeSet<Integer>();

			this.initheuristicInfo();
			this.initalGlobalPheromene(this.tao0);
			CIConstrain(((K2) score).getRecord());
			break;
		// case CInew:
		// System.err.println("��CI����,ע������base��foot");
		// this.initheuristicInfo();
		// ACOB.initalGlobalPheromene(this.tao0);
		// K2.calcInf();
		// break;
		// case HF:
		// System.err.println("����������");
		// ACOB.initHeuristicInfoWithMI();
		// ACOB.initalGlobalPheromene(this.tao0);
		// break;
		// case OP:
		// System.out.println("���Ż�-����");
		// K2.calcInf();
		// K2.CITest();
		// this.initheuristicInfo();
		// ACOB.initalGlobalPheromene(this.tao0);
		// break;
		// case AIO:
		// System.out.println("All In One");
		// ACOB.initHeuristicInfoWithMI();
		// ACOB.initalGlobalPheromene(this.tao0);
		// ACOB.CIConstrain();
		// break;
		}
		// �Ż���
		// K2.calcInf();
		// K2.CITest();
		// ACOB.initHeuristicInfoWithMI();
		// ACOB.initheuristicInfo();
		// ACOB.initialPheromene(this.tao0);
		// ����CI����
		// ACOB.CIConstrain();
	}

	public void setScoreMetric(Score s) {
		this.score = s;
	}

	public void initalGlobalPheromene(double tao0) {
		for (int i = 0; i < this.GlobalPheromoneMatrix.length; i++) {
			for (int j = 0; j < this.GlobalPheromoneMatrix[i].length; j++) {
				if (i != j) {
					this.GlobalPheromoneMatrix[i][j] = tao0;
				} else {
					this.GlobalPheromoneMatrix[i][j] = Double.NEGATIVE_INFINITY;
				}

			}
		}
	}

	public void initheuristicInfo() {
		BNGraph temp = new BNGraph(this.vexnum);
		ArrayList<Integer> anodelist = new ArrayList<Integer>(); // ��ʱ
		System.out.println("��ʼ��������Ϣ����");
		long start = System.currentTimeMillis();
		for (int i = 0; i < this.vexnum; i++) {
			noParVexK2Value[i] = this.score.calcScore(i, anodelist);

			for (int j = 0; j < this.vexnum; j++) {
				if (i != j) {
					anodelist.add(j);
					this.tempH[i][j] = this.score.calcScore(temp.GetNode(i)
							.GetNodeId(), anodelist)
							- noParVexK2Value[i];
					anodelist.remove(0);
				} else
					this.tempH[i][j] = Double.NEGATIVE_INFINITY;
			}
		}

		long end = System.currentTimeMillis();
		System.out.format("���,����[%d]����\n", end - start);
		// System.out.println("24-0��ֵ" + ACOB.tempH[24][0]);
		// System.out.println("0-24��ֵ" + ACOB.tempH[0][24]);
	}

	/**
	 * ��ʼ��������Ϣ��Ӧ�û���Ϣ
	 */
	// public static void initHeuristicInfoWithMI()
	// {
	// K2.calcInf();
	// BNGraph temp = new BNGraph(K2.VEXNUM);
	// ArrayList<Integer> anodelist = new ArrayList<Integer> (); //��ʱ
	// System.out.println("��ʼ��������Ϣ����,Ӧ���˻���Ϣ");
	// long start = System.currentTimeMillis();
	// for (int i = 0; i < K2.VEXNUM; i++)
	// {
	// ACOB.noParVexK2Value[i] = K2.INSTANCE.calcScore(i,
	// anodelist);
	// for (int j = 0; j < K2.VEXNUM; j++)
	// {
	// if (i != j)
	// {
	// anodelist.add(j);
	// this.tempH[i][j] = K2.INSTANCE.calcScore(temp.GetNode(i).
	// GetNodeId(), anodelist) - ACOB.noParVexK2Value[i];
	// this.tempH[i][j] *= (1 + K2.getRefect(K2.Inf[i][j]));
	// // System.out.println(factor);
	// anodelist.remove(0);
	// }
	// else
	// this.tempH[i][j] = Double.NEGATIVE_INFINITY;
	// }
	// }
	//
	// long end = System.currentTimeMillis();
	// System.out.format("���,����[%d]����\n", end - start);
	// // System.out.println("24-0��ֵ" + ACOB.tempH[24][0]);
	// // System.out.println("0-24��ֵ" + ACOB.tempH[0][24]);
	// }
	/**
	 * ����CI����
	 */
	public void CIConstrain(String[][] data) {
		K2.calcInf(data);
		K2.CITest(data);
		System.out.println("CIѹ��");
		for (int i = 0; i < K2.VEXNUM; i++) {
			for (int j = 0; j < K2.VEXNUM; j++) {
				if (K2.ChiSquare[i][j] == 0) {
					this.tempH[i][j] = Double.NEGATIVE_INFINITY;
				}
			}
		}
	}


	public BNGraph getBestSolution() {
		Collections.sort(this.BestSolutions);
		return this.BestSolutions.get(this.BestSolutions.size() - 1);
	}

	/**
	 * ����ȫ����Ϣ��
	 * 
	 * @param g
	 *            BNGraph
	 */
	private void updateGlobalPheromone(final BNGraph g) {
		// System.out.println("ȫ����Ϣ�ظ���");
		double bestSolutionCost = Math.abs(1 / g.calcTotalK2Score(this.score));
		ArrayList al = new ArrayList();
		for (int i = 0; i < K2.VEXNUM; i++) {
			al = g.GetNode(i).GetParentNodesIndex();
			for (int j = 0; j < al.size(); j++) {
				this.GlobalPheromoneMatrix[i][(Integer) al.get(j)] = (1 - this.rou)
						* this.GlobalPheromoneMatrix[i][(Integer) al.get(j)]
						+ this.rou * bestSolutionCost;
			}
		}
	}

	// public static void CIConstrainByValue(double base)
	// {
	// K2.CITestByValue(base);
	// for (int i = 0; i < K2.VEXNUM; i++)
	// {
	// for (int j = 0; j < K2.VEXNUM; j++)
	// {
	// if (K2.ChiSquare[i][j] == 0)
	// {
	// this.tempH[i][j] = Double.NEGATIVE_INFINITY;
	// }
	// }
	// }
	//
	// }
	/**
	 * ��Ϣ�ص���ʾ
	 */
	private void printPheromone2(int m_i, int m_j) {
	//�������ֵ��Сֵ 
				
		//���
		for(int i=0;i<m_i;i++)
		{
		for(int j=0;j<m_j;j++)
		   {
			System.out.print(GlobalPheromoneMatrix[j][i]);
			System.out.print(" ");
			}
		System.out.print("\n");
		}
		
	}
	
	private void printPheromone(int m_i, int m_j, double sdMatrix[][]) {
		//�������ֵ��Сֵ 
		        double sum=0.0;
				double min=0.0;
                int count=0;
                double f=0.0;
                double deta=0.0;
			 
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				if(GlobalPheromoneMatrix[j][i]>=0)
				{
			       sum+=GlobalPheromoneMatrix[j][i];
			       count++;
				}
				
			   }
			       
			}
			min=sum/count;
			
			//System.out.print(min);
			
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				if(GlobalPheromoneMatrix[j][i]>=0)
				{
					f += Math.sqrt((GlobalPheromoneMatrix[j][i] -min) *(GlobalPheromoneMatrix[j][i] -min));
			     	
					}
				
			   }
			       
			}
			deta=f/ Math.sqrt(count);
			//��һ��
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				GlobalPheromoneMatrix[j][i]=(GlobalPheromoneMatrix[j][i]-min)/(deta);
			   }
			}		
					
			//���
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				sdMatrix[j][i]+=GlobalPheromoneMatrix[j][i];
				System.out.print(GlobalPheromoneMatrix[j][i]);
				System.out.print(" ");
				}
			System.out.print("\n");
			}
			
			//���
			for(int i=0;i<m_i;i++)
			{
			for(int j=0;j<m_j;j++)
			   {
				System.out.print(sdMatrix[j][i]/100);
				System.out.print(" ");
				}
			System.out.print("\n");
			}
			
		}
	
	/**
	 * ����BayesianNet
	 * 
	 * @return BNGraph
	 */
	public BNGraph findBestBayesianNet() {
		long start = System.currentTimeMillis();
		BNGraph G_b;
		this.BestScore.clear();
		this.setOpted.clear();
		for (int t = 0; t < tMaxStep; t++) {
			ACOB.solutionCount = 0;
			for (int k = 0; k < antNum; k++) {
				// System.out.format("���ɵ�[%d]ֻ����\n", count);
				AntB temp = new AntB(this.alpha, this.beta,
						this.rou, this.q0,
						this.tao0, K2.VEXNUM, k,
						this.type, this.tempH,
						this.score, this.GlobalPheromoneMatrix,
						this.noParVexK2Value, this.BestSolutions);
				temp.run();
				this.allPh=this.GlobalPheromoneMatrix;
				
				ACOB.solutionCount++;
				// System.out.println("��������⻨����" + (end - start) + "ms");
			}

			// System.out.println("(����)�⼯�ϵ�����" + ACOB.bestSolution.length);
			if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
				// ����Ӧ�Ż�
				// AdaptHillClimbing();
				// ģ���˻��Ż�
				if ((t % tStep) == 0 && t != 0) {
					System.out.println("����ģ���˻��Ż�..δ��ɵ�");
				}
			} else {
				// �����Ż�
				if ((t % tStep) == 0 && t != 0) {
				//	System.out.println("�����Ż�" + t);
					for (int i = 0; i < this.BestSolutions.size(); i++) {
						this.BestSolutions.set(i, this
								.HillClimbing(this.BestSolutions.get(i)));						
					}

				}
			}
			G_b = this.getBestSolution();
			long end = System.currentTimeMillis();
			long interTime = end - start;
			bestOccurTime[t] = interTime;
			if (G_b.K2Score > this.BestSolution.K2Score) {
				this.BestSolution = G_b;
				bestOccur = t;
			}

			this.updateGlobalPheromone(this.BestSolution);
			// LogOut4.println(this.BestSolution.K2Score);
			// LogOut4.close();
			// sb.append(this.BestSolution.K2Score + ",");

			// �ж��Ƿ��˳�
			if (this.canStop()) {
				break;
			}
		}
		// ����Ż�
		if (this.type == K2.TYPE.OP || this.type == K2.TYPE.SA) {
		} else {
			this.localOptimizate();
		}
		// System.err.format("\n������������Ⱥ��������,���Ž������[%f]����������",
		// BestSolution.K2Score);
		// System.out.println(this.BestSolution);
		// System.err.println("�������" + K2.count);
		return this.BestSolution;
	}

	static int MaxEqualStep = 10;

	private boolean canStop() {
		boolean stop = false;

		int current = this.BestScore.size(); // ��ǰ����
		if (current - this.bestOccur > ACOB.MaxEqualStep) {
			System.err.println("stop at:" + current);
			stop = true;
		}

		return stop;
	}

	/**
	 * ��ɽ�Ż�
	 * 
	 * @param G_k
	 *            BNGraph
	 * @return BNGraph
	 */

	public BNGraph HillClimbing(BNGraph G_k) {
		HillClimbing hill = new HillClimbing(G_k, this.score);
		if (this.type == K2.TYPE.OP) {
			G_k = hill.OptimizeBN_CI();
		} else {
			G_k = hill.OptimizeBN();
		}
		return G_k;
	}

	/**
	 * �ֲ��Ż�
	 */
	public void localOptimizate() {
		BNGraph temp = new BNGraph(this.vexnum);
		//System.out.println("���ľֲ��Ż�");
		for (int i = 0; i < this.BestSolutions.size(); i++) {
			this.BestSolutions.set(i, this.HillClimbing(this.BestSolutions
					.get(i)));						
		}
		temp = this.getBestSolution();
		if (temp.getScore() > this.BestSolution.getScore()) {
			this.BestSolution = temp;
		}

	}
	public static int[][] doge(double[][] arr, int slice) {
        int columnNum = arr[0].length;
        int rowNum = arr.length;
        int[][] res = new int[rowNum][columnNum];
        for (int i = 0; i < res.length; i++) {
            Arrays.fill(res[i], -1);
        }

        for (int j = 0; j < columnNum; j++) {
            double[] tmp = new double[rowNum];
            int step = 1;
            for (int i = 0; i < rowNum; i++) {
                tmp[i] = arr[i][j];
            }
            int fillNum = 0;
            Arrays.sort(tmp);
            for (int i = 0; i < slice - 1; i++) {
                double val = percentile(tmp, 1.0 * step / slice);
                for (int m = 0; m < rowNum; m++) {
                    if (arr[m][j] < val && res[m][j] == -1) {
                        res[m][j] = fillNum;
                    }
                }
                fillNum++;
                step++;
            }
            for (int m = 0; m < rowNum; m++) {
                if (res[m][j] == -1) {
                    res[m][j] = fillNum;
                }
            }
        }
        return res;
    }

    private static double percentile(double[] data, double p) {
        int n = data.length;
        Arrays.sort(data);
        double px = p * (n - 1);
        int i = (int) java.lang.Math.floor(px);
        double g = px - i;
        if (g == 0) {
            return data[i];
        } else {
            return (1 - g) * data[i] + g * data[i + 1];
        }
    }
  //���ַ�������ת��double����
    public static double[][] strtodouble(String[][] str) {
        int a, b;
        a = str.length;
        b = str[0].length;
        double result[][] = new double[a][b];
        for (int i = 0; i < a; ++i) {
            for (int j = 0; j < b; ++j) {

                result[i][j] = Double.parseDouble(str[i][j]);
            }
        }
        return result;
    }

	private static java.lang.StringBuilder sb;

	public static void main(String[] args) {
		sb = new java.lang.StringBuilder();
		try {
			
		    double sdMatrix[][] = new double[K2.VEXNUM][K2.VEXNUM];
			// ���ݼ���Ϣ	
		//	String DatasetFile = "F:\\data-b\\cte\\s10-3.txt";
			String DatasetFile = "F:\\data-b\\cte\\sim5-3.txt";
		//	String DatasetFile = "F:\\Data\\data\\TaskData_Rhyming\\dis9task.txt";
		//	String DatasetFile1 = "F:\\ICDMsy\\Data3\\dissim22-10.txt";
			
     		int Vexnum = 5;//��Ҫ��
     		//int DNum =  10000;//��Ҫ��HC
     		// int DNum =  10000;//��Ҫ��mci
      		int DNum =  200;//��Ҫ��mci
     		
			//int[] DatasetNum = {50000};//��Ҫ��MCI
			int[] DatasetNum = {1000};//��Ҫ��MCI
         
			// ��־��Ŀ¼
			String LogDirRoot = "F:\\Bayes\\ACOB\\";
			// ʵ������
			ArrayList<K2.TYPE> types = new ArrayList<K2.TYPE>();
			types.add(K2.TYPE.ORI);

			Iterator it = types.iterator();
			while (it.hasNext()) {
				K2.TYPE SearchType = (K2.TYPE) it.next();
				String type = SearchType.toString();
				for (int count = 0; count < DatasetNum.length; count++) {
					sb.append("\n" + type + DatasetNum[count]);


					AlarmReader ar = new AlarmReader(DatasetFile,				
				DatasetNum[count], 5);//��Ҫ��		
					
				/*	
					String[][] dataset1 = ar.GetDataSet();
					double [][] aaa=strtodouble(dataset1);
					int aa=1;
                     int bb=aa;
					int[][] res = doge(strtodouble(dataset1), 3);
					for (int i = 0; i < res.length; i++) {
			            for (int j = 0; j < res[0].length; j++) {
			                System.out.print(res[i][j] + " ");
			            }
			            System.out.println();
			        }
				*/	
					
					Score k2 = new K2(DatasetFile, 200, 5);
					String dir1 = LogDirRoot + "\\" + type
							+ Integer.toString(DatasetNum[count]);
					System.out.println(dir1);

					for (int i = 0; i < 10; i++) {
						k2.clearCache();
						// ����־
						PrintWriter SoluLogWriter = CommonTools.getPrintWriter(
								dir1, Integer.toString(i) + ".csv");

						BNGraph gk2sn = new BNGraph(Vexnum);
						long start = System.currentTimeMillis();
						ACOB sa = new ACOB(gk2sn, 1.0, 2.0, 0.2, 0.8, 10, 100,
								10, SearchType, k2);
						sb.append("\r\n");
						
						//Ѱ�����ű�Ҷ˹��
						gk2sn = sa.findBestBayesianNet();
						
						//���ȫ����Ϣ�ؾ���
						//sa.printPheromone(10, 10, sdMatrix);
						
					//	sa.printPheromone2(12, 12);
						
						
						//gk2sn.toString();						
						//	 System.out.println(sa.B estSolution);
						
						gk2sn.tograph();
						
						 System.out.println(gk2sn.tograph());
					
						
						/*
						long end = System.currentTimeMillis();

						// System.err.println("��Ⱥ�ܹ�����ʱ�䣺" + (start - end) +
						// "ms");
						// System.err.format("\n������������Ⱥ��������,���Ž������[%f]����������",
						// sa.BestSolution.K2Score);
						// System.out.println(sa.BestSolution);

						SoluLogWriter.println(sa.BestSolution);
						// ȡ�ñ�׼ͼ
						*/
				//	BNGraph stardard = BNGraph.GetGraphStandAlarm();
					//	System.err.println("��׼ͼ"+SingleAntB.calcGraph(stardard
					//	 ) );

				//	System.out.println(BNGraph.CompareGraph(stardard,
				//			gk2sn));
						

						
					}
					
					
					
					/*
					PrintWriter LogscoreNew = CommonTools.getPrintWriter(dir1,
							"i_score.csv");
					LogscoreNew.print(sb);
					LogscoreNew.close();
					StatisticsWriter.close();*/
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}
}
