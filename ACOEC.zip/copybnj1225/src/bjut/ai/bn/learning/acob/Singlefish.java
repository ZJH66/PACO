package bjut.ai.bn.learning.acob;

import java.util.ArrayList;

import java.util.Random;

import bjut.ai.bn.BNGraph;
import bjut.ai.bn.score.K2;
import bjut.ai.bn.score.Score;

public class Singlefish {

	private BNGraph m_bnGraph; // ͼ
	private int m_i, m_j; // �ӽڵ㣬���ڵ��
	private final Random RANDOM; // �����
	private K2.TYPE type; // k2
	private double base; // ci���Ե���ֵ

	private Score score = null;
	private double[][] m_heuristicInfo; // ������Ϣ

	// ����
	private int vexnum;// ��Ⱥ������������
	private int try_number; // ���Դ���
	private double step; // �˹����ƶ��Ĳ���
	private int visual; // ��Ұ
	private double delta; // ӵ��������
	private int k;// ��������
	public int code;//���

	public ArrayList<Integer> list = new ArrayList<Integer>(); // �洢���˳�������

	public Singlefish(int vexnum1, int try_number1, double step1,
			double delta1, int visual1, int k1, K2.TYPE type1,
			double[][] InitHArray, Score score) {
		this.score = score;
		vexnum = vexnum1;
		try_number = try_number1;
		step = step1;
		delta = delta1;
		visual = visual1;
		k = k1;
		m_i = -1;
		m_j = -1;
		m_bnGraph = new BNGraph(vexnum1);
		RANDOM = new Random();
		m_heuristicInfo = new double[vexnum1][vexnum1];
		this.type = type1;
		this.setInitH(InitHArray);
	}

	public void setScore(Score s) {
		this.score = s;
	}

	public void setInitH(double[][] array) {
		for (int m = 0; m < array.length; m++) {
			System.arraycopy(array[m], 0, this.m_heuristicInfo[m], 0, vexnum);
			this.m_bnGraph.GetNode(m).K2Score = SingleAFSA.noParVexK2Value[m];
		}
	}

	public void runRandomSolution2(int k) {
		ArrayList<Integer> parentlist = null;
		// ��ʼ��������Ϣ
          code=k;
		if (this.type.toString() == "CInew")
			this.CIConstrainByValue(this.base);
		do {
			// ���Ѱ����һ���ߣ�j-->i��
			do {
				m_i = RANDOM.nextInt(vexnum);
				m_j = RANDOM.nextInt(vexnum);
			} while (m_i == m_j);
			if (m_heuristicInfo[m_i][m_j] > 0) {
				m_bnGraph.AddArc(m_j, m_i);
				// ��¼���˳��
				if (!list.contains(m_i)) {
					list.add(m_i);
				}
				if (!list.contains(m_j)) {
					list.add(m_j);
				}

				// System.out.format("���ѡ��i��j[%d %d]\n", m_i, m_j);
				m_heuristicInfo[m_i][m_j] = Double.NEGATIVE_INFINITY;
				// ȡ�ø�ĸ�ڵ���б�
				parentlist = m_bnGraph.GetNode(m_i).GetParentNodesIndex();
				//
				double ParentK2score = this.score.calcScore(
						m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
				this.m_bnGraph.GetNode(m_i).K2Score = ParentK2score;
				// ������
				this.eliminateCircle();
				// ����������Ϣ
				if (this.type == K2.TYPE.AIO || this.type == K2.TYPE.HF)
					this.updateHInfoWithMI(ParentK2score, parentlist); //
				else
					this.updateHeuristicInfo(ParentK2score, parentlist);

			}
		} while (!stopchoose());
		// ��ӡ���˳�򣨲����ظ��ڵ㣩
		/*
		 * System.out.format("���˳��"); for(int i=0;i<list.size();i++) {
		 * System.out.format("[%d ] ",list.get(i)); } System.out.format("\n");
		 */
		this.m_bnGraph.K2Score = this.m_bnGraph.calcTotalK2Score(this.score);
		SingleAFSA.addToSolutionSet(this.m_bnGraph);
	}

	protected boolean stopchoose() {
		for (int i = 0; i < vexnum; i++)
			for (int j = 0; j < vexnum; j++)
				if (m_heuristicInfo[i][j] > 0.0) {
					return false;
				}
		return true;
	}

	private void eliminateCircle() {
		ArrayList<Integer> ancestorslist = null;
		ArrayList<Integer> descendantslist = null;

		ancestorslist = m_bnGraph.GetNode(m_j).GetAncestorNodesIndex();
		descendantslist = m_bnGraph.GetNode(m_i).GetDescendantNodesIndex();

		for (int i = 0, size1 = ancestorslist.size(); i < size1; i++) {
			for (int j = 0, size2 = descendantslist.size(); j < size2; j++) {
				m_heuristicInfo[ancestorslist.get(i).intValue()][descendantslist
						.get(j).intValue()] = Double.NEGATIVE_INFINITY;
			}
		}
	}

	/**
	 * ����������Ϣ
	 * 
	 * @param ParentK2score
	 *            double
	 * @param parentlist
	 *            ArrayList
	 */
	private void updateHeuristicInfo(double ParentK2score,
			final ArrayList<Integer> parentlist) {
		// System.out.println("����������Ϣ");

		for (int k = 0; k < vexnum; k++) {
			if (m_heuristicInfo[m_i][k] > (Double.NEGATIVE_INFINITY)) {
				double afterAddParentK2score = 0;
				parentlist.add(m_bnGraph.GetNode(k).GetNodeId());
				int index = parentlist.size();
				afterAddParentK2score = this.score.calcScore(
						m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
				m_heuristicInfo[m_i][k] = afterAddParentK2score - ParentK2score;
				// System.out.println("������Ϣ����"+m_i+":"+m_heuristicInfo[m_i][k]);
				parentlist.remove(index - 1);
			}
		}
	}

	/**
	 * ����������Ϣ��Ӧ���˻���Ϣ
	 * 
	 * @param ParentK2score
	 *            double
	 * @param parentlist
	 *            ArrayList
	 */
	private void updateHInfoWithMI(double ParentK2score,
			final ArrayList<Integer> parentlist) {
		// System.out.println("����������Ϣ�����˻���Ϣ");
		for (int k = 0; k < vexnum; k++) {
			if (m_heuristicInfo[m_i][k] > (Double.NEGATIVE_INFINITY)) {
				double afterAddParentK2score = 0;
				parentlist.add(m_bnGraph.GetNode(k).GetNodeId());
				int index = parentlist.size();
				afterAddParentK2score = this.score.calcScore(
						m_bnGraph.GetNode(m_i).GetNodeId(), parentlist);
				m_heuristicInfo[m_i][k] = afterAddParentK2score - ParentK2score;
				m_heuristicInfo[m_i][k] *= (1 + K2.getRefect(K2.Inf[m_i][k])); // ���뻥��Ϣ
				parentlist.remove(index - 1);
			}
		}
	}

	public void CIConstrainByValue(double base) {
		K2.CITestByValue(base);
		for (int i = 0; i < vexnum; i++) {
			for (int j = 0; j < vexnum; j++) {
				if (K2.ChiSquare[i][j] == 0) {
					this.m_heuristicInfo[i][j] = Double.NEGATIVE_INFINITY;
				}
			}
		}

	}

	public BNGraph getBNgraph()// �õ�ͼ
	{
		return this.m_bnGraph;
	}

	public double getBNGraphScore()// �õ�ͼ����
	{
		return this.m_bnGraph.getScore();
	}

	public static double calcGraph(BNGraph g)// ����ͼ������
	{
		double k2score = 0;
		double temp = 0;
		java.text.DecimalFormat myformat = new java.text.DecimalFormat("#0.000");

		ArrayList al = new ArrayList();
		for (int i = 0; i < K2.VEXNUM; i++) {
			al = g.GetNode(i).GetParentNodesIndex();
			temp = K2.INSTANCE.calcScore(i, al);
			// // System.out.println("��ǰ�ڵ㣺" + i + "  ���׽ڵ�" + al + "  ����" +
			// temp);
			System.out.println(myformat.format(temp));
			k2score = k2score + temp;
		}
		System.out.println("�����������" + k2score);
		return k2score;
	}

	public void setBNgraph(BNGraph mi) {
		// TODO Auto-generated method stub
		this.m_bnGraph=mi;
	}

}
