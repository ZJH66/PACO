package bjut.ai.bn.learning.tabu;

public class OperRecord implements Comparable
{
  public TBN.tag tag;
  public double score;//������=k2����+�ͷ�
  private double K2Score;//k2����
  public int from;
  public int to;
  public OperRecord(double K2Score,int from, int to, TBN.tag tag)
  {
    this.K2Score = K2Score;
    this.from = from;
    this.to = to;
    this.tag = tag;
    this.setScore(K2Score);
  }


  private void setScore(double K2Score)
  {
    this.score =  TBN.punishScore[this.to][this.from] + K2Score;
  }

  @Override
public int compareTo(Object o) {
     return Math.abs(this.score) > Math.abs(((OperRecord) o).score) ? 1 :
         (Math.abs(this.score) == Math.abs(((OperRecord) o).score) ? 0 : -1);
   }
   @Override
public String toString()
   {
     StringBuilder sb = new StringBuilder() ;
     sb.append("���� "+this.score+";");
     sb.append(this.from+" -> "+this.to+";");
     sb.append("��������"+this.tag);
     return sb.toString();
   }

  public static void main(String[] args)
  {

  }
}
