package bjut.ai.bn.learning.tabu;
import java.util.HashMap;

public class AspirationList
{
  public HashMap hm;
  public AspirationList()
  {
    this.hm = new HashMap();
  }

  public void add(OperRecord oper)
  {
    String key = this.genKey(oper);
    hm.put(key,oper.score);
//    System.err.println("key"+key+" ����"+oper.score);

  }
  @Override
public String toString()
  {
    return this.hm.toString();
  }
  public boolean isAspirate(OperRecord oper)
  {
    boolean tag = false;
    String key = this.genKey(oper);
//    System.out.println("key"+key+oper.score);

    double aspirationScore = 0;

    if(this.hm.containsKey(key))
    {
      aspirationScore =(Double)hm.get(key);
      if(oper.score > aspirationScore)
      tag = true;
    }
    else
    {
//      this.hm.put(key,oper.score);
//      tag = true;
    }
    return tag;
  }

  private String genKey(OperRecord oper)
  {
    StringBuilder sb = new StringBuilder();
    sb.append(oper.to);
    sb.append("<-");
    sb.append(oper.from);
//    sb.append(oper.tag);
    return sb.toString();
  }



  public static void main(String[] args)
  {
    AspirationList al = new AspirationList();
    OperRecord oper = new OperRecord(1.0,1,2,TBN.tag.ADD);
    al.add(oper);

    OperRecord oper1 = new OperRecord(0.0,2,2,TBN.tag.DEL);
    al.add(oper1);
    System.out.println(al.isAspirate(oper1));
    System.out.print(al);
//    HashMap hm = new HashMap();
//    hm.put("111",1.0);
//    hm.put("111",2.0);
//    System.out.println(hm);
  }
}
